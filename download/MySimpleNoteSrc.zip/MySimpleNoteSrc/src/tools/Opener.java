package tools;
import javax.swing.*;
public class Opener {

	int L_x;
	int L_y;
	int	x;
	int y;
	public Opener(JFrame j,int L_x,int L_y,int x,int y,int ii){
		this.L_x=L_x;
		this.L_y=L_y;
		this.x=x;
		this.y=y;
		switch(ii){
		case 1:
			//�����Ƴ�
			j.setLocation(L_x,-y);
			j.setSize(x,y);
			for(int i=0;i<50;i++){
				
				
				j.setLocation(L_x,j.getY()+(L_y+y)/50);
				try {
					Thread.sleep(10);
				} catch (InterruptedException e1) {
					
				}
			}
			break;
		case 2:
			//�����Ƴ�
			j.setLocation(L_x,1200);
			j.setSize(x,y);
			for(int i=0;i<70;i++){
				
				
				j.setLocation(L_x,j.getY()-(1200-L_y)/70);
				try {
					Thread.sleep(10);
				} catch (InterruptedException e1) {
					
				}
			}
			break;
		
		case 3:
			//�����Ƴ�
			j.setLocation(-x,L_y);
			j.setSize(x,y);
			for(int i=0;i<50;i++){
				
				
				j.setLocation(j.getX()+(x+L_x)/50,L_y);
				try {
					Thread.sleep(10);
				} catch (InterruptedException e1) {
					
				}
			}
			break;
		case 4:
			//�����Ƴ�
			j.setLocation(2200,L_y);
			j.setSize(x,y);
			for(int i=0;i<70;i++){
				
				
				j.setLocation(j.getX()-(2200-L_x)/70,L_y);
				try {
					Thread.sleep(10);
				} catch (InterruptedException e1) {
					
				}
			}
			break;
		case 5:
			//�����Ƴ�չ��
			j.setLocation(2200,L_y+y/2);
			j.setSize(x,0);
			for(int i=0;i<40;i++){
				
				
				j.setLocation(j.getX()-(2200-L_x)/40,L_y+y/2);
				try {
					Thread.sleep(10);
				} catch (InterruptedException e1) {
					
				}
			}
			for(int i=0;i<40;i++){
				j.setSize(x,j.getHeight()+y/40);
				j.setLocation(L_x,j.getY()-y/80);
				try {
					Thread.sleep(10);
				} catch (InterruptedException e1) {
					
				}
			}
			break;
		case 6:
			//�����Ƴ�չ��
			j.setLocation(-x,L_y+y/2);
			j.setSize(x,0);
			for(int i=0;i<40;i++){
				
				
				j.setLocation(j.getX()+(x+L_x)/40,L_y+y/2);
				try {
					Thread.sleep(10);
				} catch (InterruptedException e1) {
					
				}
			}
			for(int i=0;i<40;i++){
				j.setSize(x,j.getHeight()+y/40);
				j.setLocation(L_x,j.getY()-y/80);
				try {
					Thread.sleep(10);
				} catch (InterruptedException e1) {
					
				}
			}
			break;
		case 7:
			//���Ŀ���
			j.setSize(0,0);
			j.setLocation(L_x+x/2,L_y+y/2);
			for(int i=0;i<51;i++){
				
				
				j.setLocation(L_x+x/2-i*x/100,L_y+y/2-i*y/100);
				j.setSize(0+i*x/50,0+i*y/50);
				try {
					Thread.sleep(10);
				} catch (InterruptedException e1) {
					
				}
			}
	}
	}

}
