package tools;

import java.awt.Color;

import javax.swing.JTextPane;
import javax.swing.text.AttributeSet;
import javax.swing.text.StyledDocument;

public class TextEncoder {

	/**
	 * @param args
	 */
	JTextPane write;
	String Message="";
	public static void main(String[] args) {

	}
	public TextEncoder(JTextPane Write){
		
		this.write=Write;
	
	}
	public String Encode(){
		
		Message=encode();
		if(Message.endsWith("*")) Message = Message.substring(0,Message.length() - 1);
		Message=Message+"#$%!";
		String s=write.getText();
		s=s.replace("#$%=", "");
		
		return s+Message;
	}
	private String encode(){
		Color color = null;
		int l=write.getText().length();
		int[] RGB={-1,-1,-1}; 
		int[] LastRGB={-1,-1,-1};
		int [] start=new int[l];
		int [] stop=new int[l];
		int counter=-1;
		boolean isBegin=true;
		String information="#$%=";
		String sub="";
		try{
			for(int i=0;i<=l;i++){
				write.setCaretPosition(i);
				StyledDocument doc=write.getStyledDocument();
				AttributeSet a=write.getCharacterAttributes();
				color=doc.getForeground(a);
				RGB[0]=color.getRed();
				RGB[1]=color.getGreen();
				RGB[2]=color.getBlue();
				if(change(LastRGB,RGB)||i==l){
					if(isBegin){
						counter+=1;
						start[counter]=i;
						isBegin=!isBegin;
						for(int k=0;k<LastRGB.length;k++) LastRGB[k]=RGB[k];
					}else{
						stop[counter]=i;
						sub=start[counter]+" "+stop[counter]+" "+stringColor(LastRGB)+"*";
						information=information+sub;
						for(int k=0;k<LastRGB.length;k++) LastRGB[k]=RGB[k];
						counter++;
						start[counter]=i;
					}
					
				}
			}
		
	        //StyledDocument style=write.getStyledDocument();
				
		}catch(Exception e){}
		return information;

	}
	private boolean change(int[] A,int[] B){
		if(A.length!=B.length) return true;
		else for(int i=0;i<A.length;i++) if(!(A[i]==B[i])) return true;
		return false;
	}
	private String stringColor(int[] A){
		String String1="";
		String s="";
		for(int i=0;i<A.length;i++){
			if(A[i]>=100) String1=A[i]+"";	
			else if(A[i]>=10) String1="0"+A[i];
			else if(A[i]>=0) String1="00"+A[i];

			s=s+String1;
		}
		return s;
	}
}
