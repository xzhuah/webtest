package tools;


import javax.swing.JFrame;

public class Closer {
	int L_x;
	int L_y;
	int	x;
	int y;
	public Closer(JFrame j,int ii){
		L_x=j.getX();
		L_y=j.getY();
		x=j.getWidth();
		y=j.getHeight();
		switch (ii){
		case 1:
			//�����Ƴ�
			for(int i=0;i<51;i++){
				
				j.setSize(x,y-(y/50)*i);
				j.setLocation(j.getX(),j.getY()+i);
				try {
					Thread.sleep(10);
				} catch (InterruptedException e1) {
					
				}
			}
			break;
		
		case 2:
			//�����Ƴ�
			for(int i=0;i<51;i++){
				
				j.setSize(x,y-(y/50)*i);
				j.setLocation(j.getX(),j.getY()-i);
				try {
					Thread.sleep(10);
				} catch (InterruptedException e1) {
					
				}
			}
			break;
		case 3:
			//�����Ƴ�
			for(int i=0;i<51;i++){
				
				j.setSize(x-(x/50)*i,y);
				j.setLocation(j.getX()-i,j.getY());
				try {
					Thread.sleep(10);
				} catch (InterruptedException e1) {
					
				}
			}
			break;
		case 4:
			//�����Ƴ�
			for(int i=0;i<51;i++){
				
				j.setSize(x-(x/50)*i,y);
				j.setLocation(j.getX()+2*i,j.getY());
				try {
					Thread.sleep(10);
				} catch (InterruptedException e1) {
					
				}
			}
			break;
		case 5:
			//���ºϲ�
			for(int i=0;i<51;i++){
				j.setSize(x,y-y/50*i);
				j.setLocation(L_x,L_y+(L_y+y)/100*i);
				try {
					Thread.sleep(5);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			break;
		case 6:
			//������
			try{
				for(int jj=0;jj<4;jj++){
					for(int i=0;i<5;i++){
						j.setLocation(L_x+7*i,L_y);
						Thread.sleep(10);
					}
					for(int i=0;i<5;i++){
						j.setLocation(L_x-7*i,L_y);
						Thread.sleep(10);
					}
				}
			}catch(Exception e){
					
				}
		default: 
			
		}
		
			
		
	}

}
