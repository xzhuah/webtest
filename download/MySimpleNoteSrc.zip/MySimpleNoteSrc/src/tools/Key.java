package tools;


import java.util.Base64;


//This class should be encrypted to make sure the security password.length>=6;
public final class Key {
final static Base64.Decoder decoder = Base64.getDecoder();
final static Base64.Encoder encoder = Base64.getEncoder();
public static void main(String[] args) {
	System.out.println(encryptio("ZHU Xinyu960911nbr"));
	
}
	public final static String encryptio(String plaintext){
		String []a=new String[20];
		for(int i=0;i<20;i++){
			String s1=plaintext.substring(0,plaintext.length()/3);
			String s2=plaintext.substring(plaintext.length()/3,2*plaintext.length()/3);
			String s3=plaintext.substring(2*plaintext.length()/3,plaintext.length());
			a[i]=s1.substring(0,2)+s2.substring(0,1)+s1+(int)(Math.random()*10000)+s3+s3.substring(0,2)+(int)(Math.random()*100000)+s2;
		}
		plaintext=a[10];
		for(int i=0;i<19;i++){
			if(a[i].length()<a[i+1].length()){
				plaintext=a[i+1];
			}
		}
		plaintext=plaintext.replace("1", "#@!012#^$");
		plaintext=plaintext.replace("3", ")(&234%^&");
		plaintext=plaintext.replace("5", "#*%456#$%");
		plaintext=plaintext.replace("7", "@#$678+&/");
		plaintext=plaintext.replace("9", "`$~890@);");
		byte[] textByte = null;
		try {
			textByte = plaintext.getBytes("UTF-8");
		} catch (Exception e) {
		}
		String encodedText = encoder.encodeToString(textByte);	
		for(int i=0;i<5;i++){
			try {
				encodedText = encoder.encodeToString(encodedText.getBytes());
				
			} catch (Exception e) {
			}
		}
		encodedText=ex(encodedText);
		encodedText = encoder.encodeToString(encodedText.getBytes());
		return encodedText;
	}
	public final static String decryption(String password){
		String plaintext = null;
		try {
			plaintext = new String(decoder.decode(password), "UTF-8");
			plaintext=dx(plaintext);
		} catch (Exception e1) {	
		}
		for(int i=0;i<6;i++){
			try {
				
				plaintext = new String(decoder.decode(plaintext), "UTF-8");
			} catch (Exception e) {
			}
		}
		try {
			plaintext=plaintext.replace("#@!012#^$", "1");
			plaintext=plaintext.replace(")(&234%^&", "3");
			plaintext=plaintext.replace("#*%456#$%", "5");
			plaintext=plaintext.replace("@#$678+&/", "7");
			plaintext=plaintext.replace("`$~890@);", "9");
			int l=plaintext.length()-14;
			int l1=l/3;
			int l2=2*l/3-l/3;
			int l3=3*l/3-2*l/3;
			String s1=plaintext.substring(3,3+l1);
			String s2=plaintext.substring(l-l2+14,l+14);
			String s3=plaintext.substring(7+l1,7+l1+l3);
			plaintext=s1+s2+s3;
		} catch (Exception e) {
			
		}
		return plaintext;
	}
	private static String ex(String a){
		String s=a;
		try{
			s=s.replace("a", "abd#segwevs!");
		}catch(Exception e){
			
		}
		try{
			s=s.replace("f", "asdiowf21/");
		}catch(Exception e){
			
		}
		try{
			s=s.replace("k", "qwsdl-pSDL");
		}catch(Exception e){
			
		}
		try{
			s=s.replace("T", "jiovlewsdf@");
		}catch(Exception e){
			
		}
		return s;
	}
	private static String dx(String a){
		String s=a;
		try{
			s=s.replace("jiovlewsdf@", "T");
		}catch(Exception e){
			
		}
		try{
			s=s.replace("qwsdl-pSDL","k" );
		}catch(Exception e){
			
		}
		try{
			s=s.replace("asdiowf21/", "f");
		}catch(Exception e){
			
		}
		try{
			s=s.replace("abd#segwevs!", "a");
		}catch(Exception e){
			
		}
		return s;
	}
}
