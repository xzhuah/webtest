package tools;

import java.io.*;   

public class HtmlReader {   
    public HtmlReader() {   
    }   
    /**  
     * @param filePath �ļ�·��  
     * @return ���html��ȫ������  
     */  
    public String readHtml(String filePath) {   
        BufferedReader br=null;   
        StringBuffer sb = new  StringBuffer();   
        try {   
            br=new BufferedReader(new InputStreamReader(new FileInputStream(filePath),  "GB2312"));            
            String temp=null;          
            while((temp=br.readLine())!=null){   
                sb.append(temp);   
            }              
        } catch (FileNotFoundException e) {   
            e.printStackTrace();   
        } catch (IOException e) {   
            e.printStackTrace();   
        }   
        return sb.toString();   
    }   
    /**  
     * @param filePath �ļ�·��  
     * @return ��õ�html�ı�����  
     */  
    public String getTextFromHtml(String filePath) {   
        //�õ�body��ǩ�е�����   
        String str= readHtml(filePath);   
        StringBuffer buff = new StringBuffer();   
        int maxindex = str.length() - 1;   
        int begin = 0;   
        int end;               
        //��ȡ>��<֮�������   
        while((begin = str.indexOf('>',begin)) < maxindex){              
            end = str.indexOf('<',begin);   
            if(end - begin > 1){   
                buff.append(str.substring(++begin, end));                  
            }              
            begin = end+1;   
        };         
        return buff.toString();   
    }   
  
}  
