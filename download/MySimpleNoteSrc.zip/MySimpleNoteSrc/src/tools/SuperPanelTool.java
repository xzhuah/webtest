package tools;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import mainPack.SuperPanel;
public class SuperPanelTool {
	@SuppressWarnings("resource")
	public static void saveSuperPanel(String path,SuperPanel sp) throws FileNotFoundException, IOException
	{
		new ObjectOutputStream(new FileOutputStream(path)).writeObject(sp);
	}
	@SuppressWarnings("resource")
	public static SuperPanel openSuperPanel(String path) throws ClassNotFoundException, FileNotFoundException, IOException {
		return (SuperPanel)(new ObjectInputStream(new FileInputStream(path)).readObject());
	}
}
