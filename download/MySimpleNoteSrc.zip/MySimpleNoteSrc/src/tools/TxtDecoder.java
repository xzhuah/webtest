package tools;

import java.awt.Color;

import javax.swing.JTextPane;
import javax.swing.text.DefaultStyledDocument;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;

public class TxtDecoder {

	JTextPane target;
	String text;
	//hello I am Zhu Xin yu
	//#$%=0 14 225000000*15 20 000225000#
	//Begin and End has considered the \n arleady as one char
	//[Begin End) will be set to the right color
	//[0,14)[15,20)will bein right color
	public static void main(String[] args) {
		new TxtDecoder(new JTextPane(),"hello I am Zhu Xin yu\n#$%=0 14 225000000*15 20 000225000#");
				
	}
	public TxtDecoder(JTextPane TextPane,String text){
		this.target=TextPane;
		this.text=text;
		TextPane.setText(text.substring(0, text.lastIndexOf("#$%=")));
		this.decode();
	}
	private void decode(){
		int begin=text.indexOf("#$%=")+4;
		int Begin;
		int End;
		int R;
		int G;
		int B;
		
		String number="";
		
		do{
			String startindex="";
			number=text.charAt(begin)+"";
			while(!number.equals(" ")){
				startindex=startindex+number;
				number=text.charAt(begin)+"";
				begin++;
			}
			startindex=startindex.replace("*", "");
			
			number="";
			String endindex="";
			while(!number.equals(" ")){
				endindex=endindex+number;
				number=text.charAt(begin)+"";
				begin++;
			}
			
			String r="";
			String g="";
			String b="";
			for(int i=0;i<3;i++){
				
				number=text.charAt(begin)+"";
				r=r+number;
				begin++;
			}
			
			for(int i=0;i<3;i++){
				
				number=text.charAt(begin)+"";
				g=g+number;
				begin++;
			}
			
			for(int i=0;i<3;i++){
				
				number=text.charAt(begin)+"";
				b=b+number;
				begin++;
			}
			
			number=text.charAt(begin)+"";
			
			Begin=Integer.parseInt(startindex);
			End=Integer.parseInt(endindex);
			R=Integer.parseInt(r);
			G=Integer.parseInt(g);
			B=Integer.parseInt(b);
			
			//Begin and End has considered the \n arleady as one char
			//[Begin End) will be set to the right color
			
			target.setSelectionStart(Begin);
			target.setSelectionEnd(End);
			
			
			DefaultStyledDocument doc=(DefaultStyledDocument)target.getDocument();
	        SimpleAttributeSet a = new SimpleAttributeSet();
	   
	        StyleConstants.setForeground(a,new Color(R,G,B));
	        try {
	        	
				doc.insertString(target.getSelectionStart(),target.getSelectedText(),a);
				
	         
	        a = new SimpleAttributeSet();
	        doc.setCharacterAttributes(target.getSelectionStart(),target.getSelectionEnd(),a,false);//����ָ����Χ��������ʽ
	        
	        target.replaceSelection("");
	        target.validate();
	        } catch (Exception e1) {}
		        
		}while(!number.equals("#"));
	}
	/*
	Hello
	I am 
	ZHU
	String.indexOf(ZHU)return 13
	StringNumber(String ZHU) return 11
	setSelectionStart(13)|U
	setSelectionStart(11)|Z
	
	*/
	public int StringNumber(String parent,String child){
		int number=0;
		number=parent.indexOf(child);
		for(int i=0;i<number;i++) if((parent.charAt(i)+"").equals("\n")) number--;
		return number;
	}
	public int realP(String parent,int position){
		for(int i=0;i<position;i++) if((parent.charAt(i)+"").equals("\n")) position--;
		return position;
	}
	
	
}