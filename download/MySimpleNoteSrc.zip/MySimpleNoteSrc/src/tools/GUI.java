package tools;

import java.awt.Toolkit;

public class GUI {

	/**
	 * @param args
	 */
	static int wi= Toolkit.getDefaultToolkit().getScreenSize().width; 
	static int hi= Toolkit.getDefaultToolkit().getScreenSize().height; 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}
	
}
