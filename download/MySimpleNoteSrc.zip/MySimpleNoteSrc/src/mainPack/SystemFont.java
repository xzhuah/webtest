package mainPack;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileOutputStream;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

import tools.TxtReader;
public class SystemFont extends JFrame implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * @param args
	 */
	JRadioButton f1,f2,f3,f4;
	JButton set;
	JPanel m;
	MainWindow M;
	ButtonGroup g;
	public static void main(String[] args) {
		new SystemFont(new MainWindow());
	}
	public SystemFont(MainWindow M){
		this.M=M;
		m=new JPanel();
		set=new JButton("Set");
		f1=new JRadioButton("Very small");
		f2=new JRadioButton("Small");
		f3=new JRadioButton("Middle");
		f4=new JRadioButton("Big");
		g=new ButtonGroup();
		f1.setFont(new Font("����",Font.PLAIN,30));
		f2.setFont(new Font("����",Font.PLAIN,30));
		f3.setFont(new Font("����",Font.PLAIN,30));
		f4.setFont(new Font("����",Font.PLAIN,30));
		set.setFont(new Font("����",Font.PLAIN,30));
		set.setActionCommand("set");
		set.addActionListener(this);
		
		g.add(f1);
		g.add(f2);
		g.add(f3);
		g.add(f4);
		m.add(f1);
		m.add(f2);
		m.add(f3);
		m.add(f4);
		this.add(m);
		this.add(set,BorderLayout.SOUTH);
		this.setTitle("Set Font");
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setLocation(nx(500),ny(400));
		this.pack();
		try{
			this.setIconImage((new ImageIcon(MainWindow.class.getResource("/Picture/g.gif")).getImage()));
		}catch(Exception e){
			this.setIconImage((new ImageIcon("Picture/g.gif")).getImage());
		}
		this.setVisible(true);
		//this.setSize(nx(1000),ny(900));
		String font="2";
		try {
			font=new TxtReader().getTextFromTxt("Resource/font.txt");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		switch(font){
		case "1":
			f1.setSelected(true);
			break;
		case "2":
			f2.setSelected(true);
			break;
		case "3":
			f3.setSelected(true);
			break;
		case "4":
			f4.setSelected(true);
			break;
		}
	}
	public int nx(int x){
		int wi= Toolkit.getDefaultToolkit().getScreenSize().width; 
		return (int)(x/(1920.0)*wi);
	}
	public int ny(int y){
		int wi= Toolkit.getDefaultToolkit().getScreenSize().height; 
		return (int)(y/(1080.0)*wi);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals("set")){
			int i=0;
			if(f1.isSelected()){
				i=1;
				M.SSmallFont();
			}else if(f2.isSelected()){
				i=2;
				M.SmallFont();
			}else if(f3.isSelected()){
				i=3;
				M.MiddleFont();
			}else if(f4.isSelected()){
				i=4;
				M.BigFont();
			}
			
		try(FileOutputStream o=new FileOutputStream("Resource/font.txt");){
			o.write((i+"").getBytes());
			o.flush();
		} catch (Exception e1) {}		
		this.dispose();
		}
	}

}
