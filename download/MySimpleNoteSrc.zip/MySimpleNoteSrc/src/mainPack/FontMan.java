package mainPack;
import tools.TxtReader;
public class FontMan {

	/**
	 * @param args
	 */
	public static int getFont(){
		TxtReader t=new TxtReader();
		String f="";
		try {
			f = t.getTextFromTxt("Resource/font.txt");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			
		}
		switch(f.charAt(0)+""){
		case "1":
			return 15;
			
		case "2":
			return 20;
			
		case "3":
			return 25;
			
		case "4":
			return 30;
		}
		return 20;
	}
}
