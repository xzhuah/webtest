package mainPack;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Event;
import java.awt.FileDialog;
import java.awt.FlowLayout;
import java.awt.Font;

import java.awt.Toolkit;
import java.awt.datatransfer.DataFlavor;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DropTargetDragEvent;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.dnd.DropTargetEvent;
import java.awt.dnd.DropTargetListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.util.List;


import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JSplitPane;
import javax.swing.JTree;
import javax.swing.KeyStroke;
import javax.swing.UIManager;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;

import main.*;




import tools.TxtReader;
//���й��ڱ���Ĳ���������������������ƣ�����ʹ�õķ���ΪconnectToFile��saveFile��SuperPanel�У�
public class MainWindow extends JFrame implements ActionListener, WindowListener,DropTargetListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JMenuBar menubar;
	JMenu file;JMenuItem newFile,save,saveAs,open,setPath,Ssave,Sopen,ShowFileTree;
	JMenu edit;JMenuItem undo,redo,SetFont;
	JMenu color;JMenuItem black,red,green,blue,yellow,otherColor,chelp;
	JMenu tools;JMenuItem SystemSet, FileEncryption,OnlineCounter,OnlineChatting,htmlcreating,game2048;
	JMenu Version;JMenuItem English, Chinese;
	SuperTab ST;
	JSplitPane split;
	TreeMaker treePane;
	JProgressBar progress;
	boolean isCounting=false;
	public static void main(String[] args) {
		
		if(args.length>0){
			new MainWindow(args[0]);
		}else{
			new MainWindow();
		}
	}

		
	
	MainWindow(){
		
		ST=new SuperTab(this);
		menubar=new JMenuBar();
		file=new JMenu("File");
			newFile=new JMenuItem("New File");
			save=new JMenuItem("Save");
			saveAs=new JMenuItem("Save as");
			open=new JMenuItem("Open");
			setPath=new JMenuItem("Path");
			Ssave=new JMenuItem("Standard Save");
			Sopen=new JMenuItem("Standard Open");
			ShowFileTree=new JMenuItem("File Tree");
		edit=new JMenu("Edit");
			undo=new JMenuItem("Undo");
			redo=new  JMenuItem("Redo");
			SetFont=new JMenuItem("Set Font");
			
		color=new JMenu("Color");
			black=new JMenuItem("Black");
			red=new JMenuItem("Red");
			green=new JMenuItem("Green");
			blue=new JMenuItem("Blue");
			yellow=new JMenuItem("Yellow");
			otherColor=new JMenuItem("Other");
			chelp=new JMenuItem("Help");
		tools=new JMenu("Tools");
			SystemSet=new JMenuItem("Set Default Font");
			FileEncryption=new JMenuItem("File Encryption");
			OnlineCounter=new JMenuItem("Network Time Counter");
			OnlineChatting=new JMenuItem("Chat with friend");
			htmlcreating=new JMenuItem("HTML coder");
			game2048=new JMenuItem("2048 Game");
		Version=new JMenu("Version");
			English=new JMenuItem("English instruction");
			Chinese=new JMenuItem("����˵��");
		progress=new JProgressBar();
		progress.setIndeterminate(true);
		progress.setForeground(Color.green);
			
			try{
				file.setIcon(new ImageIcon(MainWindow.class.getResource("/Picture/file.png")));
				newFile.setIcon(new ImageIcon(MainWindow.class.getResource("/Picture/newFile.png")));
				save.setIcon(new ImageIcon(MainWindow.class.getResource("/Picture/save1.png")));
				saveAs.setIcon(new ImageIcon(MainWindow.class.getResource("/Picture/Save-as-icon1.png")));
				open.setIcon(new ImageIcon(MainWindow.class.getResource("/Picture/open1.png")));
				setPath.setIcon(new ImageIcon(MainWindow.class.getResource("/Picture/Browser1.png")));
				Ssave.setIcon(new ImageIcon(MainWindow.class.getResource("/Picture/Folder Open1.png")));
				Sopen.setIcon(new ImageIcon(MainWindow.class.getResource("/Picture/Folder-icon1.png")));
				ShowFileTree.setIcon(new ImageIcon(MainWindow.class.getResource("/Picture/tree.png")));
			edit.setIcon(new ImageIcon(MainWindow.class.getResource("/Picture/Edit.png")));
				undo.setIcon(new ImageIcon(MainWindow.class.getResource("/Picture/undo.png")));
				redo.setIcon(new ImageIcon(MainWindow.class.getResource("/Picture/redo.png")));
				SetFont.setIcon(new ImageIcon(MainWindow.class.getResource("/Picture/SetFont1.png")));
			color.setIcon(new ImageIcon(MainWindow.class.getResource("/Picture/color.png")));
				black.setIcon(new ImageIcon(MainWindow.class.getResource("/Picture/black.png")));
				red.setIcon(new ImageIcon(MainWindow.class.getResource("/Picture/red.png")));
				green.setIcon(new ImageIcon(MainWindow.class.getResource("/Picture/green.png")));
				blue.setIcon(new ImageIcon(MainWindow.class.getResource("/Picture/blue.png")));
				yellow.setIcon(new ImageIcon(MainWindow.class.getResource("/Picture/yellow.png")));
				otherColor.setIcon(new ImageIcon(MainWindow.class.getResource("/Picture/other.png")));
				chelp.setIcon(new ImageIcon(MainWindow.class.getResource("/Picture/chelp.png")));
			tools.setIcon(new ImageIcon(MainWindow.class.getResource("/Picture/tool.png")));
				SystemSet.setIcon(new ImageIcon(MainWindow.class.getResource("/Picture/set.png")));
				FileEncryption.setIcon(new ImageIcon("Picture/set.png"));
				OnlineChatting.setIcon(new ImageIcon(MainWindow.class.getResource("/Picture/chatting1.png")));
				OnlineCounter.setIcon(new ImageIcon(MainWindow.class.getResource("/Picture/clock1.png")));
				htmlcreating.setIcon(new ImageIcon(MainWindow.class.getResource("/Picture/coder.png")));
				game2048.setIcon(new ImageIcon(MainWindow.class.getResource("/Picture/2048.png")));
			Version.setIcon(new ImageIcon(MainWindow.class.getResource("/Picture/Version.png")));
				English.setIcon(new ImageIcon(MainWindow.class.getResource("/Picture/English.png")));
				Chinese.setIcon(new ImageIcon(MainWindow.class.getResource("/Picture/Chinese.png")));
			}catch(Exception e){
				//file.setIcon(new ImageIcon(MainWindow.class.getResource("/Picture/file.png")));
				file.setIcon(new ImageIcon("Picture/file.png"));
				newFile.setIcon(new ImageIcon("Picture/newFile.png"));
				save.setIcon(new ImageIcon("Picture/save1.png"));
				saveAs.setIcon(new ImageIcon("Picture/Save-as-icon1.png"));
				open.setIcon(new ImageIcon("Picture/open1.png"));
				setPath.setIcon(new ImageIcon("Picture/Browser1.png"));
				Ssave.setIcon(new ImageIcon("Picture/Folder Open1.png"));
				Sopen.setIcon(new ImageIcon("Picture/Folder-icon1.png"));
				ShowFileTree.setIcon(new ImageIcon("Picture/tree.png"));
			edit.setIcon(new ImageIcon("Picture/Edit.png"));
				undo.setIcon(new ImageIcon("Picture/undo.png"));
				redo.setIcon(new ImageIcon("Picture/redo.png"));
				SetFont.setIcon(new ImageIcon("Picture/SetFont1.png"));
			color.setIcon(new ImageIcon("Picture/color.png"));
				black.setIcon(new ImageIcon("Picture/black.png"));
				red.setIcon(new ImageIcon("Picture/red.png"));
				green.setIcon(new ImageIcon("Picture/green.png"));
				blue.setIcon(new ImageIcon("Picture/blue.png"));
				yellow.setIcon(new ImageIcon("Picture/yellow.png"));
				otherColor.setIcon(new ImageIcon("Picture/other.png"));
				chelp.setIcon(new ImageIcon("Picture/chelp.png"));
			tools.setIcon(new ImageIcon("Picture/tool.png"));
				SystemSet.setIcon(new ImageIcon("Picture/set.png"));
				FileEncryption.setIcon(new ImageIcon("Picture/lock.png"));
				OnlineChatting.setIcon(new ImageIcon("Picture/chatting1.png"));
				OnlineCounter.setIcon(new ImageIcon("Picture/clock1.png"));
				htmlcreating.setIcon(new ImageIcon("Picture/coder.png"));
				game2048.setIcon(new ImageIcon("Picture/2048.png"));
			Version.setIcon(new ImageIcon("Picture/Version.png"));
				English.setIcon(new ImageIcon("Picture/English.png"));
				Chinese.setIcon(new ImageIcon("Picture/Chinese.png"));
			}
			
			
			
			
			
			//Accelerator
			newFile.setAccelerator(KeyStroke.getKeyStroke('N',Event.CTRL_MASK));
			save.setAccelerator(KeyStroke.getKeyStroke('S',Event.CTRL_MASK));
			open.setAccelerator(KeyStroke.getKeyStroke('O',Event.CTRL_MASK));
			setPath.setAccelerator(KeyStroke.getKeyStroke('P',Event.CTRL_MASK));
			undo.setAccelerator(KeyStroke.getKeyStroke('Z',Event.CTRL_MASK));
			//Font Color
			black.setForeground(Color.black);
			red.setForeground(Color.red);
			green.setForeground(Color.green);
			blue.setForeground(Color.blue);
			yellow.setForeground(Color.yellow);
			//Font	
			file.setFont(new Font("����",Font.PLAIN,30));
				newFile.setFont(new Font("����",Font.PLAIN,30));
				save.setFont(new Font("����",Font.PLAIN,30));
				saveAs.setFont(new Font("����",Font.PLAIN,30));
				open.setFont(new Font("����",Font.PLAIN,30));
				setPath.setFont(new Font("����",Font.PLAIN,30));
				Ssave.setFont(new Font("����",Font.PLAIN,30));
				Sopen.setFont(new Font("����",Font.PLAIN,30));
				ShowFileTree.setFont(new Font("����",Font.PLAIN,30));
			edit.setFont(new Font("����",Font.PLAIN,30));
				undo.setFont(new Font("����",Font.PLAIN,30));
				redo.setFont(new Font("����",Font.PLAIN,30));
				SetFont.setFont(new Font("����",Font.PLAIN,30));
			color.setFont(new Font("����",Font.PLAIN,30));
				black.setFont(new Font("����",Font.PLAIN,30));
				red.setFont(new Font("����",Font.PLAIN,30));
				green.setFont(new Font("����",Font.PLAIN,30));
				blue.setFont(new Font("����",Font.PLAIN,30));
				yellow.setFont(new Font("����",Font.PLAIN,30));
				otherColor.setFont(new Font("����",Font.PLAIN,30));
				chelp.setFont(new Font("����",Font.PLAIN,30));
			tools.setFont(new Font("����",Font.PLAIN,30));
				SystemSet.setFont(new Font("����",Font.PLAIN,30));
				FileEncryption.setFont(new Font("����",Font.PLAIN,30));
				OnlineCounter.setFont(new Font("����",Font.PLAIN,30));
				OnlineChatting.setFont(new Font("����",Font.PLAIN,30));
				htmlcreating.setFont(new Font("����",Font.PLAIN,30));
				game2048.setFont(new Font("����",Font.PLAIN,30));
			Version.setFont(new Font("����",Font.PLAIN,30));
				English.setFont(new Font("����",Font.PLAIN,30));
				Chinese.setFont(new Font("����",Font.PLAIN,30));
				
				
				newFile.setActionCommand("newFile");
				save.setActionCommand("save");
				saveAs.setActionCommand("saveAs");
				open.setActionCommand("open");
				setPath.setActionCommand("setPath");
				Ssave.setActionCommand("Ssave");
				Sopen.setActionCommand("Sopen");
				ShowFileTree.setActionCommand("ShowFileTree");
				
				undo.setActionCommand("undo");
				redo.setActionCommand("redo");
				SetFont.setActionCommand("SetFont");
				
				SystemSet.setActionCommand("SystemSet");
				FileEncryption.setActionCommand("FileEncryption");
				OnlineCounter.setActionCommand("OnlineCounter");
				OnlineChatting.setActionCommand("OnlineChatting");
				htmlcreating.setActionCommand("htmlcreating");
				game2048.setActionCommand("2048");
				
				black.setActionCommand("black");
				red.setActionCommand("red");
				green.setActionCommand("green");
				blue.setActionCommand("blue");
				yellow.setActionCommand("yellow");
				otherColor.setActionCommand("otherColor");
				chelp.setActionCommand("chelp");
				
				Chinese.setActionCommand("Chinese");
				English.setActionCommand("English");
				
				newFile.addActionListener(this);
				save.addActionListener(this);
				saveAs.addActionListener(this);
				open.addActionListener(this);	
				setPath.addActionListener(this);
				Ssave.addActionListener(this);
				Sopen.addActionListener(this);
				ShowFileTree.addActionListener(this);
				
				undo.addActionListener(this);
				redo.addActionListener(this);
				SetFont.addActionListener(this);
				
				black.addActionListener(this);
				red.addActionListener(this);
				green.addActionListener(this);
				blue.addActionListener(this);
				yellow.addActionListener(this);
				otherColor.addActionListener(this);
				chelp.addActionListener(this);
				
				SystemSet.addActionListener(this);
				OnlineCounter.addActionListener(this);
				OnlineChatting.addActionListener(this);	
				htmlcreating.addActionListener(this);
				game2048.addActionListener(this);
				
				English.addActionListener(this);
				Chinese.addActionListener(this);
				
				file.add(newFile);
				file.add(save);
				file.add(saveAs);
				file.add(open);
				file.add(setPath);
				file.addSeparator();
				file.add(Ssave);
				file.add(Sopen);
				file.add(ShowFileTree);
				
				edit.add(undo);
				edit.add(redo);
				edit.add(SetFont);
				
				color.add(black);
				color.add(red);
				color.add(green);
				color.add(blue);
				color.add(yellow);
				color.add(otherColor);
				color.add(chelp);
				
				tools.add(SystemSet);
				tools.add(FileEncryption);
				tools.add(OnlineCounter);
				tools.add(OnlineChatting);
				tools.add(htmlcreating);
				tools.add(game2048);
				
				Version.add(English);
				Version.add(Chinese);
				
				menubar.add(file);
				menubar.add(edit);
				menubar.add(color);
				menubar.add(tools);
				menubar.add(Version);	
				
				this.setJMenuBar(menubar);
				this.add(ST);
				//Set up the window
				this.setTitle("MySimpleNote");
				this.setPreferredSize(new Dimension(nx(1000),ny(900)));
				this.pack();
				try{
					this.setIconImage((new ImageIcon(MainWindow.class.getResource("/Picture/g.gif")).getImage()));
				}catch(Exception e){
					this.setIconImage((new ImageIcon("Picture/g.gif")).getImage());
				}
				
				
				getWorkingArea().writeArea.requestFocus();
				this.setVisible(true);
				this.setLocation(nx(400),ny(50));
				this.setSize(nx(1000),ny(900));
				this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
				this.addWindowListener(this);
				String font="2";
				try {
					font=(new TxtReader().getTextFromTxt("Resource/font.txt")).charAt(0)+"";
				} catch (Exception e) {
				}
				switch(font){
				case "1":
					this.SSmallFont();
					break;
				case "2":
					this.SmallFont();
					break;
				case "3":
					this.MiddleFont();
					break;
				case "4":
					this.BigFont();
					break;
				}
	
	}
	MainWindow(String path){
		this();
		ST.addNewTab(path);
	}
	/**
	 * 
	 * @param path The path of a file
	 * @return The fileName of path
	 */
	String getNameFromPath(String path){
		return new File(path.trim()).getName();

	}
	/**
	 * 
	 * @param x The target size of the icon
	 */
	public void setPictureSize(int x){
		try{
			//MainWindow.class.getResource("/Picture/file.png")).getImage().getScaledInstance(x, x, 1)
			file.setIcon(new ImageIcon (new ImageIcon(MainWindow.class.getResource("/Picture/file.png")).getImage().getScaledInstance(x, x, 1)));
			newFile.setIcon(new ImageIcon(new ImageIcon(MainWindow.class.getResource("/Picture/newFile.png")).getImage().getScaledInstance(x, x, 1)));
			save.setIcon(new ImageIcon(new ImageIcon(MainWindow.class.getResource("/Picture/save1.png")).getImage().getScaledInstance(x, x, 1)));
			saveAs.setIcon(new ImageIcon(new ImageIcon(MainWindow.class.getResource("/Picture/Save-as-icon1.png")).getImage().getScaledInstance(x, x, 1)));
			open.setIcon(new ImageIcon(new ImageIcon(MainWindow.class.getResource("/Picture/open1.png")).getImage().getScaledInstance(x, x, 1)));
			setPath.setIcon(new ImageIcon(new ImageIcon(MainWindow.class.getResource("/Picture/Browser1.png")).getImage().getScaledInstance(x, x, 1)));
			Ssave.setIcon(new ImageIcon(new ImageIcon(MainWindow.class.getResource("/Picture/Folder Open1.png")).getImage().getScaledInstance(x, x, 1)));
			Sopen.setIcon(new ImageIcon(new ImageIcon(MainWindow.class.getResource("/Picture/Folder-icon1.png")).getImage().getScaledInstance(x, x, 1)));
			ShowFileTree.setIcon(new ImageIcon(new ImageIcon(MainWindow.class.getResource("/Picture/tree.png")).getImage().getScaledInstance(x, x, 1)));
		edit.setIcon(new ImageIcon(new ImageIcon(MainWindow.class.getResource("/Picture/Edit.png")).getImage().getScaledInstance(x, x, 1)));
			undo.setIcon(new ImageIcon(new ImageIcon(MainWindow.class.getResource("/Picture/undo.png")).getImage().getScaledInstance(x, x, 1)));
			redo.setIcon(new ImageIcon(new ImageIcon(MainWindow.class.getResource("/Picture/redo.png")).getImage().getScaledInstance(x, x, 1)));
			SetFont.setIcon(new ImageIcon(new ImageIcon(MainWindow.class.getResource("/Picture/SetFont1.png")).getImage().getScaledInstance(x, x, 1)));
		color.setIcon(new ImageIcon(new ImageIcon(MainWindow.class.getResource("/Picture/color.png")).getImage().getScaledInstance(x, x, 1)));
			black.setIcon(new ImageIcon(new ImageIcon(MainWindow.class.getResource("/Picture/black.png")).getImage().getScaledInstance(x, x, 1)));
			red.setIcon(new ImageIcon(new ImageIcon(MainWindow.class.getResource("/Picture/red.png")).getImage().getScaledInstance(x, x, 1)));
			green.setIcon(new ImageIcon(new ImageIcon(MainWindow.class.getResource("/Picture/green.png")).getImage().getScaledInstance(x, x, 1)));
			blue.setIcon(new ImageIcon(new ImageIcon(MainWindow.class.getResource("/Picture/blue.png")).getImage().getScaledInstance(x, x, 1)));
			yellow.setIcon(new ImageIcon(new ImageIcon(MainWindow.class.getResource("/Picture/yellow.png")).getImage().getScaledInstance(x, x, 1)));
			otherColor.setIcon(new ImageIcon(new ImageIcon(MainWindow.class.getResource("/Picture/other.png")).getImage().getScaledInstance(x, x, 1)));
			chelp.setIcon(new ImageIcon(new ImageIcon(MainWindow.class.getResource("/Picture/chelp.png")).getImage().getScaledInstance(x, x, 1)));
		tools.setIcon(new ImageIcon(new ImageIcon(MainWindow.class.getResource("/Picture/tool.png")).getImage().getScaledInstance(x, x, 1)));
			SystemSet.setIcon(new ImageIcon(new ImageIcon(MainWindow.class.getResource("/Picture/set.png")).getImage().getScaledInstance(x, x, 1)));
			FileEncryption.setIcon(new ImageIcon(new ImageIcon(MainWindow.class.getResource("/Picture/lock.png")).getImage().getScaledInstance(x, x, 1)));
			OnlineChatting.setIcon(new ImageIcon(new ImageIcon(MainWindow.class.getResource("/Picture/chatting1.png")).getImage().getScaledInstance(x, x, 1)));
			OnlineCounter.setIcon(new ImageIcon(new ImageIcon(MainWindow.class.getResource("/Picture/clock1.png")).getImage().getScaledInstance(x, x, 1)));
			htmlcreating.setIcon(new ImageIcon(new ImageIcon(MainWindow.class.getResource("/Picture/coder.png")).getImage().getScaledInstance(x, x, 1)));
			game2048.setIcon(new ImageIcon(new ImageIcon(MainWindow.class.getResource("/Picture/2048.png")).getImage().getScaledInstance(x, x, 1)));
		Version.setIcon(new ImageIcon(new ImageIcon(MainWindow.class.getResource("/Picture/Version.png")).getImage().getScaledInstance(x, x, 1)));
			English.setIcon(new ImageIcon(new ImageIcon(MainWindow.class.getResource("/Picture/English.png")).getImage().getScaledInstance(x, x, 1)));
			Chinese.setIcon(new ImageIcon(new ImageIcon(MainWindow.class.getResource("/Picture/Chinese.png")).getImage().getScaledInstance(x, x, 1)));
		}catch(Exception e){
			//file.setIcon(new ImageIcon(MainWindow.class.getResource("/Picture/file.png")));
			file.setIcon(new ImageIcon (new ImageIcon("Picture/file.png").getImage().getScaledInstance(x, x, 1)));
			newFile.setIcon(new ImageIcon(new ImageIcon("Picture/newFile.png").getImage().getScaledInstance(x, x, 1)));
			save.setIcon(new ImageIcon(new ImageIcon("Picture/save1.png").getImage().getScaledInstance(x, x, 1)));
			saveAs.setIcon(new ImageIcon(new ImageIcon("Picture/Save-as-icon1.png").getImage().getScaledInstance(x, x, 1)));
			open.setIcon(new ImageIcon(new ImageIcon("Picture/open1.png").getImage().getScaledInstance(x, x, 1)));
			setPath.setIcon(new ImageIcon(new ImageIcon("Picture/Browser1.png").getImage().getScaledInstance(x, x, 1)));
			Ssave.setIcon(new ImageIcon(new ImageIcon("Picture/Folder Open1.png").getImage().getScaledInstance(x, x, 1)));
			Sopen.setIcon(new ImageIcon(new ImageIcon("Picture/Folder-icon1.png").getImage().getScaledInstance(x, x, 1)));
			ShowFileTree.setIcon(new ImageIcon(new ImageIcon("Picture/tree.png").getImage().getScaledInstance(x, x, 1)));
		edit.setIcon(new ImageIcon(new ImageIcon("Picture/Edit.png").getImage().getScaledInstance(x, x, 1)));
			undo.setIcon(new ImageIcon(new ImageIcon("Picture/undo.png").getImage().getScaledInstance(x, x, 1)));
			redo.setIcon(new ImageIcon(new ImageIcon("Picture/redo.png").getImage().getScaledInstance(x, x, 1)));
			SetFont.setIcon(new ImageIcon(new ImageIcon("Picture/SetFont1.png").getImage().getScaledInstance(x, x, 1)));
		color.setIcon(new ImageIcon(new ImageIcon("Picture/color.png").getImage().getScaledInstance(x, x, 1)));
			black.setIcon(new ImageIcon(new ImageIcon("Picture/black.png").getImage().getScaledInstance(x, x, 1)));
			red.setIcon(new ImageIcon(new ImageIcon("Picture/red.png").getImage().getScaledInstance(x, x, 1)));
			green.setIcon(new ImageIcon(new ImageIcon("Picture/green.png").getImage().getScaledInstance(x, x, 1)));
			blue.setIcon(new ImageIcon(new ImageIcon("Picture/blue.png").getImage().getScaledInstance(x, x, 1)));
			yellow.setIcon(new ImageIcon(new ImageIcon("Picture/yellow.png").getImage().getScaledInstance(x, x, 1)));
			otherColor.setIcon(new ImageIcon(new ImageIcon("Picture/other.png").getImage().getScaledInstance(x, x, 1)));
			chelp.setIcon(new ImageIcon(new ImageIcon("Picture/chelp.png").getImage().getScaledInstance(x, x, 1)));
		tools.setIcon(new ImageIcon(new ImageIcon("Picture/tool.png").getImage().getScaledInstance(x, x, 1)));
			SystemSet.setIcon(new ImageIcon(new ImageIcon("Picture/set.png").getImage().getScaledInstance(x, x, 1)));
			FileEncryption.setIcon(new ImageIcon(new ImageIcon("Picture/lock.png").getImage().getScaledInstance(x, x, 1)));
			OnlineChatting.setIcon(new ImageIcon(new ImageIcon("Picture/chatting1.png").getImage().getScaledInstance(x, x, 1)));
			OnlineCounter.setIcon(new ImageIcon(new ImageIcon("Picture/clock1.png").getImage().getScaledInstance(x, x, 1)));
			htmlcreating.setIcon(new ImageIcon(new ImageIcon("Picture/coder.png").getImage().getScaledInstance(x, x, 1)));
			game2048.setIcon(new ImageIcon(new ImageIcon("Picture/2048.png").getImage().getScaledInstance(x, x, 1)));
		Version.setIcon(new ImageIcon(new ImageIcon("Picture/Version.png").getImage().getScaledInstance(x, x, 1)));
			English.setIcon(new ImageIcon(new ImageIcon("Picture/English.png").getImage().getScaledInstance(x, x, 1)));
			Chinese.setIcon(new ImageIcon(new ImageIcon("Picture/Chinese.png").getImage().getScaledInstance(x, x, 1)));
		}
		ST.setPictureSize(x);
	}
	/**
	 * 
	 * @param i The target size of the new font
	 */
	public void setElementFont(int i){
			file.setFont(new Font("����",Font.PLAIN,i));
			newFile.setFont(new Font("����",Font.PLAIN,i));
			save.setFont(new Font("����",Font.PLAIN,i));
			saveAs.setFont(new Font("����",Font.PLAIN,i));
			open.setFont(new Font("����",Font.PLAIN,i));
			setPath.setFont(new Font("����",Font.PLAIN,i));
			Ssave.setFont(new Font("����",Font.PLAIN,i));
			Sopen.setFont(new Font("����",Font.PLAIN,i));
			ShowFileTree.setFont(new Font("����",Font.PLAIN,i));
		edit.setFont(new Font("����",Font.PLAIN,i));
			undo.setFont(new Font("����",Font.PLAIN,i));
			redo.setFont(new Font("����",Font.PLAIN,i));
			SetFont.setFont(new Font("����",Font.PLAIN,i));
		color.setFont(new Font("����",Font.PLAIN,i));
			black.setFont(new Font("����",Font.PLAIN,i));
			red.setFont(new Font("����",Font.PLAIN,i));
			green.setFont(new Font("����",Font.PLAIN,i));
			blue.setFont(new Font("����",Font.PLAIN,i));
			yellow.setFont(new Font("����",Font.PLAIN,i));
			otherColor.setFont(new Font("����",Font.PLAIN,i));
			chelp.setFont(new Font("����",Font.PLAIN,i));
		tools.setFont(new Font("����",Font.PLAIN,i));
			SystemSet.setFont(new Font("����",Font.PLAIN,i));
			FileEncryption.setFont(new Font("����",Font.PLAIN,i));
			OnlineCounter.setFont(new Font("����",Font.PLAIN,i));
			OnlineChatting.setFont(new Font("����",Font.PLAIN,i));
			htmlcreating.setFont(new Font("����",Font.PLAIN,i));
			game2048.setFont(new Font("����",Font.PLAIN,i));
		Version.setFont(new Font("����",Font.PLAIN,i));
			English.setFont(new Font("����",Font.PLAIN,i));
			Chinese.setFont(new Font("����",Font.PLAIN,i));
		try{
			treePane.setFontSize(i);
		}catch(Exception e){}
		this.setFont(new Font("����",Font.PLAIN,i));
		this.validate();
	}
	/**
	 * Set the font and icon to a large scale
	 */
	public void BigFont(){
		setElementFont(30);
		ST.setElementFont(20);
		setPictureSize(30);
	}
	/**
	 *  Set the font and icon to a middle scale
	 */
	public void MiddleFont(){
		setElementFont(25);
		ST.setElementFont(17);
		setPictureSize(25);
	}
	/**
	 *  Set the font and icon to a small scale
	 */
	public void SmallFont(){
		setElementFont(20);
		ST.setElementFont(15);
		setPictureSize(20);
	}
	/**
	 *  Set the font and icon to a very small scale
	 */
	public void SSmallFont(){
		setElementFont(15);
		ST.setElementFont(12);
		setPictureSize(15);
	}
	/**
	 * 
	 * @param x 
	 * @return The new value of width x in the local screen
	 */
	public int nx(int x){
		return (int)(x/(1920.0)*Toolkit.getDefaultToolkit().getScreenSize().width);
	}
	/**
	 * 
	 * @param y
	 * @return The new value of height y in the local screen
	 */
	public int ny(int y){
		return (int)(y/(1080.0)* Toolkit.getDefaultToolkit().getScreenSize().height);
	}
	/**
	 * 
	 * @return The current working SuperPanel object
	 */
	public SuperPanel getWorkingArea(){
		return ST.workingArea;
	}
	
	@Override
	public void windowActivated(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void windowClosed(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	/**
	 * Check whether to save the file call SuperTab to help exit all model
	 */
	@Override
	public void windowClosing(WindowEvent arg0) {
		if(ST.UnSavedFileNumber()>0){
			Font font = new Font("����",Font.PLAIN,30);
			UIManager.put("Label.font",font);
			UIManager.put("Button.font",font);
			Object[] options = {"Yes","No"}; 
			int response=JOptionPane.showOptionDialog(this, "Do you want to save all of your file?", "Save Hint ",JOptionPane.YES_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]); 
			if(response==0){
				if(ST.UnConnectedFileNumber()>0){
					if(!ST.SaveAll()){
						return;
					}
					ST.Close(isCounting);
				}else{
					for(int i=0;i<ST.tabNumber;i++){
						ST.ChangeTo(i);
						getWorkingArea().saveFile();
						if(isCounting){
							this.ST.ExitAll();
							this.dispose();
						}else{
							this.ST.ExitAll();
							System.exit(0);
						}
						
					}	
				}
			}else if(response==1){
					if(isCounting){
						this.ST.ExitAll();
						this.dispose();
					}else{
						this.ST.ExitAll();
						System.exit(0);
					}
				}
		}else{
			if(isCounting){
				this.ST.ExitAll();
				this.dispose();
			}else{
				this.ST.ExitAll();
				System.exit(0);
			}
		}
	}
	/**
	 * When lose focus and the alwaysOnTop CheckBox is selected, keep the window on the top
	 */
	@Override
	public void windowDeactivated(WindowEvent arg0) {
		// TODO Auto-generated method stub
		if(this.getWorkingArea().alwaysOnTop.isSelected()){
			this.setAlwaysOnTop(true);
		}else{
			this.setAlwaysOnTop(false);
		}
		
	}
	@Override
	public void windowDeiconified(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void windowIconified(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void windowOpened(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	/**
	 * Deal with all button event and menu item event
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		switch(e.getActionCommand()){
		case "newFile":
			ST.addNewTab();
			break;
		case "save":
			ST.save();
			break;
		case "saveAs":
			new Manager(this);
			break;
		case "open":
			new FileOpener(this);
			break;
		case "setPath":
			new SetPath();
			break;
		case "Ssave":
			FileDialog SAVE = new FileDialog(this, "����,ע����ȷ��д��׺��", FileDialog.SAVE);
			//SAVE.setIconImage((new ImageIcon("picture/Folder Open1.png")).getImage());
			SAVE.setVisible(true);
			 try {
				if(SAVE.getFile().endsWith(".txt")||SAVE.getFile().endsWith(".html")){
					 this.getWorkingArea().connectToFile(SAVE.getDirectory()+SAVE.getFile(), "save");
					 SAVE.dispose();
				}else{
					new Information("Attention","ע����ȷ��д��׺�� .txt�� .html");
				}
			 }catch(Exception ex){
					new Information("Attention","System Fail to Save");
			}
			 break;
		
		case "Sopen":
			
			FileDialog OPEN = new FileDialog(this, "��", FileDialog.LOAD);
			OPEN.setVisible(true);
			if(new ImageViewer().GenImage(OPEN.getDirectory()+OPEN.getFile())) return;
			if(new OtherFileOpener().open(OPEN.getDirectory()+OPEN.getFile())) return ;
			if(OPEN.getFile().endsWith(".txt")||OPEN.getFile().endsWith(".html")){
				try{	
					this.ST.addNewTab((OPEN.getDirectory()+OPEN.getFile()));
				}catch(Exception ex){
					new Information("Attention","System fail to open the file");	
				}
			}else{
				new Information("Attention","System Only Support txt file or html file");
			}
		
			break;
		case "ShowFileTree":
			if(this.split==null){
				new creatTree();
			}
			break;
		case "undo":
			this.getWorkingArea().undo();
			break;
			
		case "redo":
			this.getWorkingArea().redo();
			break;
			
		case "SetFont":
			new ChangeTime("Reset Font","Please input the new font below",this);
			break;
		
		//Color function haven't been finished yet,���ð�
		case "black":
			getWorkingArea().set2balck();
			break;
		case "red":
			getWorkingArea().set2red();
			break;
			
		case "green":
			getWorkingArea().set2green();
			break;
			
		case "blue":
			getWorkingArea().set2blue();
			break;
			
		case "yellow":
			getWorkingArea().set2yellow();
			break;
		case "otherColor":
			getWorkingArea().set2otherColor();
			break;
		case "chelp":
			Imformations hh=new Imformations("Color Guide","<html><body><p>First choose the target text, then choose a kind of color.\nThe text you choosed will be colored. Attention, if you \nwant to save the color, please tick the checkbox, and\nplease choose MySimpleNote as the default way to open txt file\n(�뽫MySimpleNoteԭ������Ϊtxt��Ĭ�ϴ򿪷�ʽ�Ա���ɫ�ı����ڶ�ȡ)Sometimes you\nmay find some redundant string at the end of you file after open\nit with MysimpleNote, that is because your file ends with\ntoo many empty lines, and please remove all those redundant string!</p></body><html>",600,400);
			JLabel LL=null;
			try{
				LL=new JLabel("",JLabel.CENTER);LL.setIcon(new ImageIcon(MainWindow.class.getResource("/Picture/SimpleNote.PNG")));	
			}catch(Exception ex){
				LL=new JLabel("",JLabel.CENTER);LL.setIcon(new ImageIcon("Picture/UST.png"));
			}
			
			hh.add(new JPanel().add(LL),BorderLayout.NORTH);
			hh.validate();
			break;
		case "SystemSet":
			new SystemFont(this);
			break;
		case "FileEncryption":
			
			break;
		case "OnlineCounter":
			new CounterThread();
			this.isCounting=true;
			break;
		case "OnlineChatting":
			if(this.getWorkingArea().getModel()!=SuperPanel.CHATWINDOW)
				this.getWorkingArea().setModel(SuperPanel.CHATWINDOW);
			break;
		case "htmlcreating":
			if(this.getWorkingArea().getModel()!=SuperPanel.PROGRAMMER)
				this.getWorkingArea().setModel(SuperPanel.PROGRAMMER);
			break;
			
		case "2048":
			new towZeroFourEight.MainWindow().Botton.requestFocus();
			break;
		case "Chinese":
			Imformations Icc=new Imformations("�汾��Ϣ","<html><body><hr /><h1>MySimpleNoteClient8.0</h1><p>���������������ɾͶ�����ۿƼ���ѧ��������д�� MySimpleNote�ͻ���</p><p>�汾��: 8.0</p><p>�������ڣ� 2015��7��6�� </p><p>��Ȩ�����ߣ������</p><p>Copyright/&copy[2015, July 6][ZHU Xinyu]</p></body></html>",700,500);
			Icc.setResizable(true);
			JLabel Lc=null;
			try{
				Lc=new JLabel("",JLabel.CENTER);Lc.setIcon(new ImageIcon(MainWindow.class.getResource("/Picture/SimpleNote.PNG")));
			}catch(Exception ex){
				Lc=new JLabel("",JLabel.CENTER);Lc.setIcon(new ImageIcon("Picture/SimpleNote.PNG"));
				
			}
			Icc.add(new JPanel().add(Lc),BorderLayout.NORTH);
			Icc.validate();
			break;
		case "English":
			
			Imformations Ic=new Imformations("Version Information","<html><body><hr /><h1>MySimpleNoteClient8.0</h1><p>Description:Developed by ZHU Xinyu, a full-time student in Hong Kong University of Science and Technology, this softwave is a client platform of MySimpleNote</p><p>Version code: 8.0</p><p>Publish Date: 2015, July 6</p><p>Copyright holder: ZHU Xinyu</p><p>Copyright/&copy[2015, July 6][ZHU Xinyu]</p></body></html>",700,500);
			Ic.setResizable(true);
			JLabel L=null;
			try{
				L=new JLabel("",JLabel.CENTER);L.setIcon(new ImageIcon(MainWindow.class.getResource("/Picture/SimpleNote.PNG")));
			}catch(Exception ex){
				L=new JLabel("",JLabel.CENTER);L.setIcon(new ImageIcon("Picture/SimpleNote.PNG"));
			}
			Ic.add(new JPanel().add(L),BorderLayout.NORTH);
			Ic.validate();
			break;
			
			
		
		}
	}
	@Override
	public void dragEnter(DropTargetDragEvent arg0) {
		// TODO Auto-generated method stub
	}
	@Override
	public void dragExit(DropTargetEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void dragOver(DropTargetDragEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	/*
	 * Open txt or html files when they are dragged to the area of the window
	 * (non-Javadoc)
	 * @see java.awt.dnd.DropTargetListener#drop(java.awt.dnd.DropTargetDropEvent)
	 */
	@Override
	public void drop(DropTargetDropEvent arg0) {
		// TODO Auto-generated method stub
		arg0.acceptDrop(DnDConstants.ACTION_REFERENCE);
			try {
				@SuppressWarnings("unchecked")
				List<File> list = (List<File>)  arg0.getTransferable().getTransferData(DataFlavor.javaFileListFlavor);
				for (File f : list) {
					if(new OtherFileOpener().open(f.toString())) return;
					if(new ImageViewer().GenImage(f.getAbsoluteFile().toString())) continue;
					if (f.exists() && f.isFile()&&(f.getAbsoluteFile().toString().endsWith(".txt")||f.getAbsoluteFile().toString().endsWith(".html")))
						ST.addNewTab(f.getAbsolutePath());
				}
			} catch (Exception e) {
				
			}
		
	}

	@Override
	public void dropActionChanged(DropTargetDragEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	private String[] compress(String[] s){
		int leng=0;
		for(String i:s) if(!i.equals("")) leng++;
		String[] newString=new String[leng];
		leng=0;
		for(String i:s) if(!i.equals("")) newString[leng++]=i;
		return newString;
	}
	private class treeToolBar extends JPanel{
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		JButton close,tree;
		
		treeToolBar(){
			try{
				tree=new JButton(new ImageIcon(SuperPanel.class.getResource("/Picture/treeroot.png")));
				close=new JButton(new ImageIcon(SuperPanel.class.getResource("/Picture/Close.png")));
			}catch(Exception e){
				tree=new JButton(new ImageIcon("Picture/treeroot.png"));
				close=new JButton(new ImageIcon("Picture/Close.png"));
			}
			tree.setBorderPainted(false);
			tree.setPreferredSize(new Dimension(20,20));
			tree.setToolTipText("Create new root");
			tree.addActionListener(new ActionListener(){

				@Override
				public void actionPerformed(ActionEvent arg0) {
					FileDialog OPEN = new FileDialog(MainWindow.this, "��ѡ��Ҫ�½��ĸ��ļ����µ�һ�����ļ���,���ɴ������ļ���", FileDialog.LOAD);
					OPEN.setVisible(true);
					final String[] s={OPEN.getDirectory()+OPEN.getFile()};
					new addTree(s[0]);										
				}
				
			});
			close.setBorderPainted(false);
			close.setPreferredSize(new Dimension(20,20));
			close.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				if(MainWindow.this.treePane!=null){
					MainWindow.this.setSize(MainWindow.this.getWidth()-MainWindow.this.treePane.getWidth(),MainWindow.this.getHeight());
					MainWindow.this.remove(MainWindow.this.split);
					MainWindow.this.add(MainWindow.this.ST);
					MainWindow.this.treePane=null;
					MainWindow.this.split=null;
					MainWindow.this.setTitle("MySimpleNote");
					try{
						MainWindow.this.remove(progress);
					}catch(Exception e){}
					MainWindow.this.revalidate();
				}
				
			}
			
		});
		
		this.setLayout(new FlowLayout(FlowLayout.RIGHT));
		this.add(tree);
		this.add(close);
		}
	}
	private class addTree implements Runnable{
		String path;
		addTree(String path){
			this.path=path;
			Thread t=new Thread(this);
			t.start();
		}
		@Override
		public void run() {
			if(MainWindow.this.treePane!=null){
				MainWindow.this.setTitle("MySimpleNote is making file tree...");
				MainWindow.this.add(MainWindow.this.progress,BorderLayout.SOUTH);
				String[] ss={path};
				MainWindow.this.treePane.addNewRoots(ss);
				MainWindow.this.treePane.setFontSize(20);
				MainWindow.this.remove(MainWindow.this.progress);				
				MainWindow.this.setTitle("MySimpleNote");
				MainWindow.this.validate();	
			}
			
		}
	}
		private class creatTree implements Runnable{
			creatTree(){
				Thread t=new Thread(this);
				t.start();
			}
			@Override
			public void run() {
				MainWindow.this.setTitle("MySimpleNote is making file tree...");
				MainWindow.this.add(progress,BorderLayout.SOUTH);
				String[] roots=compress(ST.getAllItemPath());
				if((roots.length==1&&roots[0].equals(""))||roots.length==0){
					String s[]={new DefaultPathManager().getPath()};
					treePane=new TreeMaker(s);
					
				}else{
					treePane=new TreeMaker(roots);
				}
				treePane.add(new treeToolBar(),BorderLayout.NORTH);
				treePane.setPreferredSize(new Dimension(nx(250),MainWindow.this.getHeight()));
				MainWindow.this.setTitle("MySimpleNote");
				MainWindow.this.validate();
				MainWindow.this.setSize(MainWindow.this.getWidth()+nx(250),MainWindow.this.getHeight());
				treePane.getFileTree().addMouseListener(new MouseListener(){
				
					@Override
					public void mouseClicked(MouseEvent e) {
						 TreePath selPath = ((JTree) e.getSource()).getPathForLocation(e.getX(), e.getY());
					        if (((JTree) e.getSource()).getRowForLocation(e.getX(), e.getY()) != -1&&
					        		e.getClickCount() == 2&&((TreeNode)selPath.getLastPathComponent()).isLeaf()){
					        	if(new OtherFileOpener().open(treePane.getDoubleClickedPath())) return;
					        	if(treePane.getDoubleClickedPath().toLowerCase().endsWith(".png")||treePane.getDoubleClickedPath().toLowerCase().endsWith(".jpeg")
					        	||treePane.getDoubleClickedPath().toLowerCase().endsWith(".gif")||treePane.getDoubleClickedPath().toLowerCase().endsWith(".jpg")
					        	||treePane.getDoubleClickedPath().toLowerCase().endsWith(".html")||
					        	treePane.getDoubleClickedPath().toLowerCase().endsWith(".txt"))
					        	{
					        	ST.addNewTab(treePane.getDoubleClickedPath());
					        	}
					        }
						
					}

					@Override
					public void mouseEntered(MouseEvent arg0) {
						// TODO Auto-generated method stub
						
					}

					@Override
					public void mouseExited(MouseEvent arg0) {
						// TODO Auto-generated method stub
						
					}

					@Override
					public void mousePressed(MouseEvent arg0) {
						// TODO Auto-generated method stub
						
					}

					@Override
					public void mouseReleased(MouseEvent arg0) {
						// TODO Auto-generated method stub
						
					}
					
				});
				split=new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,treePane,ST);
				MainWindow.this.remove(ST);
				MainWindow.this.add(split);
				MainWindow.this.remove(progress);
				MainWindow.this.validate();
			}		
		
	}

}

