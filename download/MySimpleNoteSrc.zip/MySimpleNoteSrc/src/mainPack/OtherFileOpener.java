package mainPack;

import java.io.IOException;

public class OtherFileOpener {

	/**
	 * @param args
	 */
	public boolean open(String path){
		if(path.toLowerCase().endsWith(".pdf")||path.toLowerCase().endsWith(".docx")||path.toLowerCase().endsWith(".lnk")){
			try {
				Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler "+path);
			} catch (IOException e1) {
				new Information("Error","Can't run the program");
				
			}
			return true;
		}else if((!path.toLowerCase().endsWith(".txt"))&&(!path.toLowerCase().endsWith(".html"))&&(!path.toLowerCase().endsWith(".jpg"))
				&&(!path.toLowerCase().endsWith(".jpeg"))&&(!path.toLowerCase().endsWith(".png"))&&(!path.toLowerCase().endsWith(".gif"))){
			return Sopen(path);
		}else{
			return false;
		}
	}
	public boolean Sopen(String path){
			try {
				Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler "+path);
				return true;
			} catch (IOException e1) {
				new Information("Error","Can't run the program");
				return false;
			}	
	}

}
