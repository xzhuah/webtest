package mainPack;
import java.awt.*;

import javax.swing.*;

import java.io.*;
import java.awt.event.*;
//This class is to provide the save function for the program, Connect the Tab to a file
public class Manager extends JDialog implements ActionListener,WindowListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	MainWindow w;
	JLabel path,filename;
	JTextField thepath, thename;
	JButton save,cancel;
	JPanel main,second,p1,p2;
	
	Manager(MainWindow w){
		super(w, false);
		this.w=w;
		path=new JLabel("Path");
		filename=new JLabel("filename");
		thename=new JTextField(20);
		thepath=new JTextField(40);
		save=new JButton("Save");
		cancel=new JButton("Cancel");
		main=new JPanel();
		second=new JPanel();
		p1=new JPanel();
		p2=new JPanel();
		
		path.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		filename.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		thepath.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		thename.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));	
		save.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		cancel.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		//thepath.setText("TestFile");
		thepath.setText(new DefaultPathManager().getPath());
		save.addActionListener(this);
		save.setActionCommand("save");
		cancel.setActionCommand("cancel");
		cancel.addActionListener(this);
		thename.setActionCommand("thename");
		thename.setText(w.getWorkingArea().getRN());
		thename.addActionListener(this);
		//main.setLayout(new GridLayout(4,1));
		p1.add(path);p1.add(thepath);
		p2.add(filename);p2.add(thename);
		main.setLayout(new GridLayout(2,1));
		main.add(p1);		main.add(p2);
		second.add(cancel);second.add(save);
		
		this.add(main);		this.add(second,BorderLayout.SOUTH);

		this.setTitle("Save");
		this.setVisible(true);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		try{
			this.setIconImage((new ImageIcon(MainWindow.class.getResource("/Picture/g.gif")).getImage()));
		}catch(Exception e){
			this.setIconImage((new ImageIcon("Picture/g.gif")).getImage());
		}
		this.setPreferredSize(new Dimension(nx(700),ny(200)));
		this.pack();
		this.setLocation(nx(600),ny(300));
		
		
	}
	public int nx(int x){
		int wi= Toolkit.getDefaultToolkit().getScreenSize().width; 
		return (int)(x/(1920.0)*wi);
	}
	public int ny(int y){
		int wi= Toolkit.getDefaultToolkit().getScreenSize().height; 
		return (int)(y/(1080.0)*wi);
	}
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals("save")||e.getActionCommand().equals("thename")){
			try{
				File[] files = new File(thepath.getText().toString()).listFiles();
				String name[]=new String[files.length]; 
				
				for (int i = 0; i < files.length; i++) {
				  if(!files[i].isDirectory()){
				     name[i]=files[i].getName();	     
				  }
				}
				//�����ļ�
				if(thename.getText().toString().equals("")){
					new Information("Fail to Save","Please input a filename");
					return;
				}
				//�޺�׺�ļ�
				if(!(thename.getText().endsWith(".txt")||thename.getText().endsWith(".html"))){
					new Information("Fail to Save","Please add a suffix to you filename, either .txt or .html");
					return;
				}
				//�����ļ�
				if((isIn(name,thename.getText().toString()))){
					new Information("Fail to Save","There is already a file named "+thename.getText()+" please use another name");
					return;
				}
				w.getWorkingArea().connectToFile(thepath.getText()+thename.getText(),"save");
				this.dispose();
				
			}catch(Exception ex){
				new Information("Fail to Save","We encountered problem when saving your file!");
			}
		}else if(e.getActionCommand().equals("cancel")){
			this.dispose();
		}
		
	}
	boolean isIn(String[] S,String s){
		for(int i=0;i<S.length;i++){
			if(s.equals(S[i])) return true;
		}
		return false;
		
	}
	public void windowClosing(WindowEvent arg0){
		
	}
	@Override
	public void windowOpened(WindowEvent paramWindowEvent) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void windowClosed(WindowEvent paramWindowEvent) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void windowIconified(WindowEvent paramWindowEvent) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void windowDeiconified(WindowEvent paramWindowEvent) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void windowActivated(WindowEvent paramWindowEvent) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void windowDeactivated(WindowEvent paramWindowEvent) {
		// TODO Auto-generated method stub
		
	}
	

}
