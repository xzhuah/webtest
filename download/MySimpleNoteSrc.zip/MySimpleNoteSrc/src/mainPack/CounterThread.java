package mainPack;
import main.*;
/**
 * This class start a new Thread for the network counting
 * @author Xinyu
 *
 */
public class CounterThread implements Runnable{
	@Override
	public void run() {
		try {
			new Counter();
	} catch (Exception e) {}
	}
	CounterThread(){
		new Thread(this,"Counter1").start();
	}

}
