package mainPack;

import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class FileCoder extends JFrame implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JPanel option,password,hint,process;
	JRadioButton en,de;
	ButtonGroup group;
	JLabel Password,hints;
	JTextField Passwords;
	JButton ok;
	public static void main(String[] args) {
		new FileCoder();
	}
	FileCoder(){
		option=new JPanel();password=new JPanel();hint=new JPanel();process=new JPanel();
		en=new JRadioButton("Encryption");
		de=new JRadioButton("Decryption");
		group=new ButtonGroup();group.add(en);group.add(de);
		Password=new JLabel("Password: ",JLabel.CENTER);
		hints=new JLabel("",JLabel.CENTER);
		hints.setText("<html><body><p>The password should only contain letters,\nlonger password means higher security.</p></body></html>");
		Passwords=new JTextField(20);
		ok=new JButton("Begin");
		
		en.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		de.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		Password.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		Passwords.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		hints.setFont(new Font("����",Font.PLAIN,FontMan.getFont()/2));
		ok.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		
		en.addActionListener(this);
		de.addActionListener(this);
		ok.addActionListener(this);
		
		ok.setActionCommand("ok");
		
		option.add(en);option.add(de);
		password.add(Password);password.add(Passwords);
		hint.add(hints);
		process.add(ok);
		
		this.setLayout(new GridLayout(4,1));
		this.add(option);this.add(password);this.add(hint);this.add(process);
		
		this.setTitle("Encryption/Decryption");
		this.setVisible(true);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		try{
			this.setIconImage((new ImageIcon(MainWindow.class.getResource("/Picture/g.gif")).getImage()));
		}catch(Exception e){
			this.setIconImage((new ImageIcon("Picture/g.gif")).getImage());
		}
		//this.setPreferredSize(new Dimension(nx(400),ny(300)));
		this.pack();
		this.setLocation(nx(600),ny(300));
	}
	public int nx(int x){
		int wi= Toolkit.getDefaultToolkit().getScreenSize().width; 
		return (int)(x/(1920.0)*wi);
	}
	public int ny(int y){
		int wi= Toolkit.getDefaultToolkit().getScreenSize().height; 
		return (int)(y/(1080.0)*wi);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals("ok")){
			if(en.isSelected()){
				
			}else{
				
			}
		}
		
	}
}
