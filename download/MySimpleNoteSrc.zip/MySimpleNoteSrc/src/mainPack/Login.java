package mainPack;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileOutputStream;

import javax.swing.*;

import main.Imformations;
import tools.*;
public class Login extends JFrame implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JButton name=new JButton("username");
	private JLabel password=new JLabel("password",JLabel.CENTER);;
	private JTextField Name=new JTextField(30);
	private JPasswordField word=new JPasswordField(30);
	private JButton login=new JButton("Continue");
	private JPanel pt=new JPanel();
	private JPanel pb=new JPanel();
	private JPanel pbb=new JPanel();
	private JPanel pm=new JPanel();
	private SuperPanel m;
	public static void main(String[] args) {
	
		
	}
	Login(SuperPanel m){
		this.m=m;
		name.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		password.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		Name.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		word.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		login.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		pt.add(name);pt.add(Name);
		pb.add(password);pb.add(word);
		pbb.add(login);
		pm.setLayout(new GridLayout(2,1));
		pm.add(pt);pm.add(pb);
		login.setActionCommand("login");
		login.addActionListener(this);
		name.setActionCommand("name");
		name.addActionListener(this);
		this.add(pm);this.add(pbb,BorderLayout.SOUTH);
		try{
			this.setIconImage((new ImageIcon(MainWindow.class.getResource("/Picture/lock.png")).getImage()));
		}catch(Exception e){
			this.setIconImage((new ImageIcon("Picture/lock.png")).getImage());
		}
		this.setTitle("Login");
		try{
			new TxtReader().getTextFromTxt("Resource/ciphertext.password");
		}catch(Exception e){
			this.change();
		}
		this.setLocation(nx(500),ny(300));
		this.setPreferredSize(new Dimension(nx(900),ny(300)));
		this.pack();
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.Name.requestFocus();
		this.setVisible(true);
	}
	public void change(){
		this.login.setActionCommand("reset");
		this.setTitle("Set username(will be used in your Chatting!) and password");
	}
	private int nx(int x){
		int wi= Toolkit.getDefaultToolkit().getScreenSize().width; 
		return (int)(x/(1920.0)*wi);
	}
	private int ny(int y){
		int wi= Toolkit.getDefaultToolkit().getScreenSize().height; 
		return (int)(y/(1080.0)*wi);
	}
	@SuppressWarnings("deprecation")
	@Override
	public void actionPerformed(ActionEvent e) {

		if(e.getActionCommand().equals("login")){
			try {
				if((Name.getText()+word.getText()).equals(Key.decryption(new TxtReader().getTextFromTxt("Resource/ciphertext.password").replace("\r\n", "")))){
					this.dispose();
					m.userName=Name.getText();
					//TODO Begin Connect to Server
					//ServerConnecter SC=new ServerConnecter(this.m);
				}else{
					new Information("Error","Wrong Password");
					this.word.setText("");
					this.word.requestFocus();
				}
			} catch (Exception e1) {
				new Information("Error","Can't find your password file");
			}
		}
		if(e.getActionCommand().equals("reset")){
			if(word.getPassword().toString().length()<6){
				new Information("Sorry","The length of your password must be longer then 5");
				return;
			}
			try(FileOutputStream o=new FileOutputStream("Resource/ciphertext.password");) {
				o.write(Key.encryptio(Name.getText()+word.getText()).getBytes());
				o.flush();
				new Information("Success","Set Password Successfully!");
				this.dispose();
				m.userName=Name.getText();
				//TODO Begin Connect to Server
				//ServerConnecter SC=new ServerConnecter(this.m);
			} catch (Exception e1) {}
			
		}
		if(e.getActionCommand().equals("name")){
			new Imformations("User Name","<html><body><p>���ε�½ʱ�������������κ�����Ҫ���û���������Ϊ���ģ������룬��������ڱ�ĵ�����ʹ�����칦������Ҫ�����Լ���Resource�ļ����е�password�ļ�����ĵ����϶�Ӧ��password�ļ��滻Ȼ���¼���û����������칦��������ʶ�����ݵģ�������ѡ���û���</p></body></html>",500,400);
		}
	}
}
