package mainPack;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JTabbedPane;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class SuperTab extends JTabbedPane implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	boolean needSave;
	int tabNumber;
	SuperPanel workingArea;
	MainWindow father;
	int ImageSize=30;

	SuperTab(MainWindow father){
		super();
		this.father=father;
		this.setFont(new Font("����",Font.PLAIN,20));
		workingArea=new SuperPanel(this);
		try{
			this.addTab(workingArea.name,new ImageIcon(new ImageIcon(MainWindow.class.getResource("/Picture/txticon.png")).getImage().getScaledInstance(ImageSize, ImageSize, 1)), workingArea);
		}catch(Exception e){
			this.addTab(workingArea.name,new ImageIcon(new ImageIcon("Picture/txticon.png").getImage().getScaledInstance(ImageSize, ImageSize, 1)), workingArea);		
		}
		tabNumber=1;
		this.addChangeListener(new ChangeListener(){
			   public void stateChanged(ChangeEvent e){
				   workingArea.isMain=false;
				    JTabbedPane tabbedPane = (JTabbedPane)e.getSource();
				    int selectedIndex = tabbedPane.getSelectedIndex();
				    workingArea=(SuperPanel) tabbedPane.getComponentAt(selectedIndex);
				    workingArea.isMain=true;
				    workingArea.writeArea.requestFocus();
			   }
			});
		
	}
	/*
	 Get name of a file based on its path name
	 */
	private String getNameFromPath(String path){
        return new File(path.trim()).getName();
	}
	
	//Open New is open, Use save is save //Untitled.txt will never be connected to Hardware others will always
	//���µ�ѡ� ��Ҫ��������� Ĭ��txtͼ�꣬ѡ�����
	boolean addNewTab(){
		try{
			workingArea.isMain=false;
		}catch(Exception e){
			
		}
		try{
			workingArea=new SuperPanel(this);
			try{
				this.addTab(workingArea.name,new ImageIcon(new ImageIcon(MainWindow.class.getResource("/Picture/txticon.png")).getImage().getScaledInstance(ImageSize, ImageSize, 1)), workingArea);
			}catch(Exception e){
				this.addTab(workingArea.name,new ImageIcon(new ImageIcon("Picture/txticon.png").getImage().getScaledInstance(ImageSize, ImageSize, 1)), workingArea);		
			}
			this.setSelectedIndex(tabNumber);
		}catch(Exception e){
			return false;
		}
		tabNumber+=1;
		workingArea.writeArea.requestFocus();
		return true;
		
	}
	//ֱ�Ӳ˵��򿪣���Ҫ�ṩ·���� ������ͼ�꣬ѡ�����
	boolean addNewTab(final String path){
		//����ͼƬ
		if(new ImageViewer().GenImage(path)) return true;
		//����txt html�� ֱ�Ӵ�
		//����Ƿ��Ѿ�������ͬ�ļ�
		if(isContain(path,getAllItemPath())!=-1){
			ChangeTo(isContain(path,getAllItemPath()));
			return true;
		}
		String Name=getNameFromPath(path);
		try{
			workingArea.isMain=false;
		}catch(Exception e){}
		try{
			workingArea=new SuperPanel(this);
			workingArea.setFileName(Name);//Also set type
			if(workingArea.type.equals("txt")){
				try{
					this.addTab(workingArea.name,new ImageIcon(new ImageIcon(MainWindow.class.getResource("/Picture/txticon.png")).getImage().getScaledInstance(ImageSize, ImageSize, 1)), workingArea);
				}catch(Exception e){
					this.addTab(workingArea.name,new ImageIcon(new ImageIcon("Picture/txticon.png").getImage().getScaledInstance(ImageSize, ImageSize, 1)), workingArea);		
				}
			}else if(workingArea.type.equals("html")){
				try{
					this.addTab(workingArea.name,new ImageIcon(new ImageIcon(MainWindow.class.getResource("/Picture/htmlIcon.png")).getImage().getScaledInstance(ImageSize, ImageSize, 1)), workingArea);
				}catch(Exception e){
					this.addTab(workingArea.name,new ImageIcon(new ImageIcon("Picture/htmlIcon.png").getImage().getScaledInstance(ImageSize, ImageSize, 1)), workingArea);		
				}
			}
			
			
			
			this.setSelectedIndex(tabNumber);
			tabNumber+=1;	
			workingArea.connectToFile(path, "open");
			new addTree(path);
		}catch(Exception e){
			return false;
		}
		return true;
	}
	boolean addNewTab(SuperPanel sp){
		if(isContain(sp.path,getAllItemPath())!=-1){
			ChangeTo(isContain(sp.path,getAllItemPath()));
			return true;
		}else{
			try{
				workingArea.isMain=false;
			}catch(Exception e){return false;}
			try{
				workingArea=sp;
				this.addTab(workingArea.name,new ImageIcon(new ImageIcon(MainWindow.class.getResource("/Picture/txticon.png")).getImage().getScaledInstance(ImageSize, ImageSize, 1)), workingArea);
				this.setSelectedIndex(tabNumber);
				tabNumber+=1;	
				new addTree(sp.path);
			}catch(Exception e){return false;}
		}
		return true;
		
	}
	/*
	 * Save the current file return true if succeed
	 */
	boolean save(){
		return workingArea.saveFile();
	}
	/*
	 * return all Files' path currently opened in a string array. May contain the same one or the null
	 */
	String[] getAllItemPath(){
		String[] paths=new String[tabNumber];
		int ci=this.getSelectedIndex();
		for(int i=0;i<tabNumber;i++){
			try{
				this.ChangeTo(i);
				paths[i]=this.workingArea.path;
			}catch(Exception e){paths[i]="";}
			
		}
		this.ChangeTo(ci);
		return paths;
	}
	/*
	 * return all Files' name currently opened in a string array
	 */
	String[] getAllItemName(){
		String[] names=new String[tabNumber];
		for(int i=0;i<tabNumber;i++){
			names[i]=this.getTitleAt(i);
		}
		return names;
	}
	/*
	 * return the number of unconnectedFile
	 */
	int UnConnectedFileNumber(){
		int sum=0;
		for(int i=0;i<tabNumber;i++){	
			if(!((SuperPanel)this.getComponentAt(i)).HaveConnectedToFile) sum+=1;
		} 
		return sum;
	}
	/*
	 *  return the number of files need to be saved
	 */
	int UnSavedFileNumber(){
		int sum=0;
		for(int i=0;i<tabNumber;i++){	
			if(((SuperPanel)this.getComponentAt(i)).name.startsWith("*")) sum+=1;
		} 
		return sum;
	}
	/*
	 * Change to the ith tab directly(isMain index is set)
	 */
	void ChangeTo(int i){
		workingArea.isMain=false;
		this.setSelectedIndex(i);
		((SuperPanel)this.getComponentAt(i)).isMain=true;
	}
		
	//Close all(press close on mainWindow) do removeTab until remain One
	//remove the current tab, if only one left, close the window
	void removeTab(Boolean whetherForce){
		if(whetherForce){
			if(tabNumber>1){
				workingArea.isMain=false;
				this.removeTabAt(this.getSelectedIndex());
				this.tabNumber-=1;
				workingArea=(SuperPanel)this.getComponentAt(this.getSelectedIndex());
				workingArea.isMain=true;
			}else{
				if(workingArea.needSave()){
					new AskSave(father,workingArea.getRN());
					return;
				}
				if(!father.isCounting){
					ExitAll();
					System.exit(0);
				}else{
					ExitAll();
					father.dispose();
				}
				
			}
		}else{
			if(tabNumber>1){
				if(workingArea.needSave()){
					new AskSave(father,workingArea.getRN());
					return;
				}
			workingArea.isMain=false;
			this.removeTabAt(this.getSelectedIndex());
			this.tabNumber-=1;
			workingArea=(SuperPanel)this.getComponentAt(this.getSelectedIndex());
			workingArea.isMain=true;
			}else{
				if(workingArea.needSave()){
					new AskSave(father,workingArea.getRN());
					return;
				}
				if(!father.isCounting){
					ExitAll();
					System.exit(0);
				}else{
					ExitAll();
					father.dispose();
				}
				
			}
		}
	}
	//Exit model for all tab
	void ExitAll(){
		int k=this.getSelectedIndex();
		for(int i=0;i<tabNumber;i++){
			ChangeTo(i);
			workingArea.exitModel();
		}
		ChangeTo(k);
	}
	/*
	 * save all files
	 */
	boolean SaveAll(){
		//If things in Untitled then ask
		int k=this.getSelectedIndex();
		int sum=0;
		for(int i=0;i<tabNumber;i++){
			ChangeTo(i);
			if(workingArea.name.startsWith("*")){
				sum+=1;
				if(workingArea.HaveConnectedToFile) {
					workingArea.saveFile();
				}else{
					workingArea.connectToFile(new DefaultPathManager().getPath()+workingArea.getRN(), "save");
				}
			}
		}
		ChangeTo(k);
		if(sum>0){
			new Information("ע��","֮ǰδ�������Untitled.txt�ļ��ѱ��浽Ĭ��·����(���ж�������Զ�����),�������ı��ļ�����\nλ�û�ϣ���ļ�������,�����ڹر�ʹ��'Save As'��'Standerd Save'���ܱ��棬�������ٴ��˳�����");
			return false;
		}
		return true;
	}
	//Only when saveAll return true , Close can be called in MainWindow
	void Close(boolean isCounting){
		ExitAll();
			if(isCounting){
				father.dispose();
				return;
			}else System.exit(0);			
	}
	
	public void setElementFont(int i){
		this.setFont(new Font("����",Font.PLAIN,i));
	}
	public void setPictureSize(int x){
		for(int i=0;i<this.tabNumber;i++){
			this.setIconAt(i, new ImageIcon(((ImageIcon) this.getIconAt(i)).getImage().getScaledInstance(x, x, 1)));
		}
		ImageSize=x;
	}
	//Close the curren tab
	@Override
	public void actionPerformed(ActionEvent e) {
		switch(e.getActionCommand()){
		case "close":
			removeTab(false);
			break;
		
		}
		
	}
	//Check whether s1 is in string[]
	private int isContain(String s1,String[] s){
		for(int i=0;i<s.length;i++) if(s1.replace("\\", "/").equals(s[i].replace("\\", "/"))) return i;
		
		return -1;
	}
	/**
	 * 
	 * @param x 
	 * @return The new value of width x in the local screen
	 */
	public static int nx(int x){
		return (int)(x/(1920.0)*Toolkit.getDefaultToolkit().getScreenSize().width);
	}
	/**
	 * 
	 * @param y
	 * @return The new value of height y in the local screen
	 */
	public static int ny(int y){
		return (int)(y/(1080.0)* Toolkit.getDefaultToolkit().getScreenSize().height);
	}
	private class addTree implements Runnable{
		String path;
		addTree(String path){
			this.path=path;
			Thread t=new Thread(this);
			t.start();
		}
		@Override
		public void run() {
			if(father.treePane!=null){		
				String[] ss={path};
				for(int i=0;i<father.treePane.getRoots().length;i++)
					if(path.contains(getNameFromPath(father.treePane.getRoots()[i].toString().replace("\\", "/")))) return;
				father.setTitle("MySimpleNote is making file tree...");
				father.add(father.progress,BorderLayout.SOUTH);
				father.treePane.addNewRoots(ss);
				father.treePane.setFontSize(20);
				father.remove(father.progress);				
				father.setTitle("MySimpleNote");
				father.validate();	
			}
			
		}
		
	}
	
	

}
