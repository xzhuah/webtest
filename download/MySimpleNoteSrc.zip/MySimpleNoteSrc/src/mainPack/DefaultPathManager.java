package mainPack;

import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
//This class can be used to get/set Default Path
public class DefaultPathManager {
	String path;
	DefaultPathManager(){
		try(FileReader O = new FileReader("Resource/path.txt");){
			int aa=O.read();
			path="";			
			while(aa!=-1){		
				path+=(char)aa;	
				aa=O.read();			
			}
		}catch (IOException e){}
	}
	String getPath(){
		return path.replace("\\", "/");
	}
	void setPath(String p) throws IOException{
		this.path=p;
		try(FileOutputStream O=new FileOutputStream("Resource/path.txt");){
			O.write(path.getBytes());
		}catch(Exception e){}
		
		
	}
}
