package mainPack;
/**
 * 
 */
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.FileFilter;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;

/**
* This class generate an object of a JPanel containing a file tree built on a root file
* @author Xinyu ZHU
* @version 1.0
* @since JDK1.7

*/
public class TreeMaker extends JPanel{
	private static final long serialVersionUID = 1L;
	private File root;
	private File[] roots;
	private JScrollPane scroll;
	private JTree fileTree;
	private DefaultMutableTreeNode wholeTree;
	private String DoubleClickedPath;
	
	
	
	/**
	 * 
	 * @param directory The path of the root folder
	 */
	public TreeMaker(String directory){
		this(new File(directory));
	}
	
	/**
	 * 
	 * @param directory The File object representing the root folder
	 */
	public TreeMaker(File directory){
		root=directory.isDirectory()? directory:new File(directory.getParent());
		wholeTree=getFullTree(root);
		System.out.println(root);
		fileTree=new JTree(wholeTree);
		scroll=new JScrollPane(fileTree);
		fileTree.addMouseListener(new TreeDoubleClickListener());
		this.setLayout(new BorderLayout());
		this.add(scroll);
		this.setFontSize(20);
	}
	public TreeMaker(String[] directories){
		this(String2File(directories));
	}
	public TreeMaker(File[] directories){
		File[] nroots=new File[directories.length];
		for(int i=0;i<nroots.length;i++) nroots[i]=directories[i].isDirectory()? directories[i]:new File(directories[i].getParent());	
		roots=FileCompress(nroots);
		DefaultMutableTreeNode root =  new DefaultMutableTreeNode(""); 
		for(int i=0;i<roots.length;i++) {
			root.add(getFullTree(roots[i]));
		}
		wholeTree=root;
		fileTree=new JTree(root);
		fileTree.setRootVisible(false);
		scroll=new JScrollPane(fileTree);
		fileTree.addMouseListener(new TreeDoubleClickListener());
		this.setLayout(new BorderLayout());
		this.add(scroll);
		this.setFontSize(20);
	}
	
	/**
	 * 
	 * @param filepath the path of the root folder
	 * @return An array of DefaultMutableTreeNode containing all child files in filepath
	 */
	public DefaultMutableTreeNode[] getSubFilesGroup(String filepath){
		return getSubFilesGroup(new File(filepath));
	}
	/**
	 * 
	 * @param file The File object of the root folder
	 * @return An array of DefaultMutableTreeNode containing all child files in file
	 */
	public DefaultMutableTreeNode[] getSubFilesGroup(File file){
		if(file.isDirectory()){
			int FolderNum=GetFolders(file.listFiles()).length;
			int FileNum=GetNotFolders(file.listFiles()).length;
			DefaultMutableTreeNode[] subFilesGroup=new DefaultMutableTreeNode[FolderNum+FileNum];
			for(int i=0;i<FolderNum;i++) subFilesGroup[i]=new DefaultMutableTreeNode(GetFolders(file.listFiles())[i].toString());
			for(int j=0;j<FileNum;j++) subFilesGroup[j+FolderNum]=new DefaultMutableTreeNode(GetNotFolders(file.listFiles())[j].toString());
			return subFilesGroup;
		}else return null;

	}
	/**
	 * 
	 * @param file The File object representing the root folder
	 * @return a DefaultMutableTreeNode object of the sub tree rooted in file
	 */
	public DefaultMutableTreeNode getSubTree(File file){
		DefaultMutableTreeNode subTree=new DefaultMutableTreeNode(file.toString());
		if(file.isDirectory()) for(File childFile:file.listFiles()) subTree.add(new DefaultMutableTreeNode(childFile.toString()));
		else return subTree;
		return subTree;
	}
	/**
	 * 
	 * @param file The File object representing the root folder
	 * @return a DefaultMutableTreeNode object of the whole tree rooted in file
	 */
	public DefaultMutableTreeNode getFullTree(File file){
		DefaultMutableTreeNode fullTree=new DefaultMutableTreeNode(file.getName().toString());
		if(!file.isDirectory()) return fullTree;
		else {
			try{
				for(File f:GetFolders(file.listFiles())) fullTree.add(getFullTree(f));	
			}
			catch(Exception e){}
			try{
				for(File f:GetNotFolders(file.listFiles())) fullTree.add(getFullTree(f));
			}catch(Exception e){}
		}
		return fullTree;
	}
	public void addNewRoots(String[] s){
		this.addNewRoots(String2File(s));
	}
	public void addNewRoots(File[] f){
		//TODO
		for(int i=0;i<f.length;i++) f[i]=f[i].isDirectory()?f[i]:f[i].getParentFile();
		File ff[]=new File[roots.length+f.length];
		for(int i=0;i<roots.length;i++) ff[i]=roots[i];
		for(int i=0;i<f.length;i++) ff[i+roots.length]=f[i];
		File nf[]=FileCompress(ff);
		if(roots.length!=nf.length){
			roots=new File[nf.length];
			for(int i=0;i<roots.length;i++) roots[i]=nf[i];
			DefaultMutableTreeNode root =  new DefaultMutableTreeNode(""); 
			for(int i=0;i<roots.length;i++) {
				root.add(getFullTree(roots[i]));
			}
			wholeTree=root;
			MouseListener[] m=fileTree.getMouseListeners();
			fileTree=new JTree(root);
			fileTree.setRootVisible(false);
			this.remove(scroll);
			scroll=new JScrollPane(fileTree);
			for(MouseListener mm:m) fileTree.addMouseListener(mm);
			this.add(scroll);
			this.validate();
		}
	}
	class TreeDoubleClickListener implements MouseListener{
		public void mousePressed(MouseEvent e) {
	
       
	}
		@Override
		public void mouseClicked(MouseEvent e){
			// TODO Auto-generated method stub
	        TreePath selPath = ((JTree) e.getSource()).getPathForLocation(e.getX(), e.getY());
	        if (((JTree) e.getSource()).getRowForLocation(e.getX(), e.getY()) != -1&&
	        		e.getClickCount() == 2&&((TreeNode)selPath.getLastPathComponent()).isLeaf()){
	        	DoubleClickedPath=StringPathGen(selPath.toString());
	        	System.out.println(DoubleClickedPath);	
	        }
	          
	            	
	            
	        
		}

		@Override
		public void mouseReleased(MouseEvent paramMouseEvent) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseEntered(MouseEvent paramMouseEvent) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseExited(MouseEvent paramMouseEvent) {
			// TODO Auto-generated method stub
			
		}
}
	
	
	/**
	 * 
	 * @param fontSize The preferred font size of the tree
	 */
	public void setFontSize(int fontSize){
		fileTree.setFont(new Font("����",Font.PLAIN,fontSize));
	}
	
	/**
	 * 
	 * @return The JTree object of the instance of TreeMaker
	 */
	public JTree getFileTree(){
		return fileTree;
	}
	
	
	/**
	 * 
	 * @return The JScrollPane object containing the tree
	 */
	public JScrollPane getScrollPane(){
		return scroll;
	}
	/**
	 * 
	 * @return The DefaultMutableTreeNode object representing the whole tree
	 */
	public DefaultMutableTreeNode getWholeTree(){
		return wholeTree;
	}
	public File getRoot(){
		return root;
	}
	public File[] getRoots(){
		return roots;
	}
	public String getDoubleClickedPath(){
		return DoubleClickedPath;
	}
	
	
	@Override
	public String toString(){
		return "The root file: "+root.toString();
	}
	private File[] GetFolders(File[] files){
		if (files!=null)return new File(files[0].getParent()).listFiles(new FileFilter(){
			@Override
			public boolean accept(File paramFile) {
				if (paramFile.isDirectory()) return true;
				else return false;
			}
		});
		else return null;
	}
	
	private File[] GetNotFolders(File[] files){
		if (files!=null)return new File(files[0].getParent()).listFiles(new FileFilter(){
			@Override
			public boolean accept(File paramFile) {
				if (paramFile.isDirectory()) return false;
				else return true;
			}	
		});
		else return null;
	}
	private String StringPathGen(String s){
		String path = "";
		s=s.replace("[", "");
		s=s.replace("]", "");
		if(s.startsWith(", ")) s=s.substring(2,s.length());
		if(root!=null){
			path=root.toString();
			path=path.replace("\\", "/");
		}else{
			String test=s.substring(0,s.indexOf(", "));
			for(int i=0;i<roots.length;i++){
				if(roots[i].toString().endsWith(test)) path=roots[i].toString().replace("\\", "/");
			}
		}
		int i=s.indexOf(", ");
		do{
			s=(String) s.subSequence(i+2, s.length());
			i=s.indexOf(", ")==-1?s.length():s.indexOf(", ");
			path=path+"/"+s.substring(0, i);
		}while(s.indexOf(", ")!=-1);
		return path;
		
	}
	private static File[] String2File(String[] s){
		File[] f=new File[s.length];
		for(int i=0;i<f.length;i++) f[i]=new File(s[i]);
		return f;
	}
	private File[] FileCompress(File[] f){
		File[] nf=f;
		for(int i=0;i<f.length-1;i++){
			for(int j=i+1;j<f.length;j++){
				try{
				if(f[i].toString().equals(f[j].toString())){
					nf[i]=null;break;
				}
				}catch(Exception e){};
			}
		}
		int len=0;
		for(int i=0;i<nf.length;i++) if(nf[i]!=null) len++;
		File nnf[]=new File[len];
		len=0;
		for(int i=0;i<nf.length;i++) if(nf[i]!=null) nnf[len++]=nf[i];
		return nnf;
	}
}

