package mainPack;

import java.awt.Font;

import javax.swing.JOptionPane;
import javax.swing.UIManager;
/**
 * This Class generate a dialog asking whether to save the current file
 * @author Xinyu
 *
 */
public class AskSave {

	AskSave(MainWindow MW,String filename){
		UIManager.put("Label.font",new Font("����",Font.PLAIN,FontMan.getFont()));
		UIManager.put("Button.font",new Font("����",Font.PLAIN,FontMan.getFont()));
		Object[] options = {"Yes","No"}; 
		int response=JOptionPane.showOptionDialog(MW, "Do you want to save "+filename+"?", "Save Hint ",JOptionPane.YES_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]); 
		if(response==0) MW.getWorkingArea().saveFile();			
		else if(response==1){
			if(MW.ST.tabNumber==1){
				if(MW.isCounting){
					MW.ST.ExitAll();
					MW.dispose();
				}else{
					MW.ST.ExitAll();
					System.exit(0);
				}
			}else MW.ST.removeTab(true);
		}
	}
	
	
}
