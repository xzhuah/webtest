package mainPack;

import javax.swing.*;

import tools.Closer;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
public class SetPath extends JFrame implements ActionListener{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JLabel hint1,hint2;
	JTextField path;
	JPanel botton;
	JButton browser,save,help;
	DefaultPathManager I=new DefaultPathManager();
	
	SetPath(){
		
		hint1=new JLabel("Please input the new default path below",JLabel.CENTER);
		hint2=new JLabel("Save Path:");
		path=new JTextField(30);
		save=new JButton("Save");
		browser=new JButton("Broswer");
		help=new JButton("What is default path?");
		
		botton=new JPanel();
		
		save.addActionListener(this);
		save.setActionCommand("save");
		browser.addActionListener(this);
		browser.setActionCommand("browser");
		help.addActionListener(this);
		help.setActionCommand("help");
		
		path.setText(I.getPath());
		
		browser.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		save.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		path.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		hint1.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		hint2.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		help.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		botton.add(hint2);botton.add(path);botton.add(browser);botton.add(save);
		this.add(hint1);
		this.add(botton,BorderLayout.SOUTH);
		this.add(help,BorderLayout.NORTH);
		
		this.setTitle("Set Default Save Path");
		this.setVisible(true);
		try{
			this.setIconImage((new ImageIcon(MainWindow.class.getResource("/Picture/g.gif")).getImage()));
		}catch(Exception e){
			this.setIconImage((new ImageIcon("Picture/g.gif")).getImage());
		}
		this.setPreferredSize(new Dimension(nx(900),ny(250)));
		this.setLocation(nx(700),ny(300));
		this.pack();
		
	}
	public int nx(int x){
		int wi= Toolkit.getDefaultToolkit().getScreenSize().width; 
		return (int)(x/(1920.0)*wi);
	}
	public int ny(int y){
		int wi= Toolkit.getDefaultToolkit().getScreenSize().height; 
		return (int)(y/(1080.0)*wi);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getActionCommand().equals("save")){
				try{
					String Newpath=path.getText().toString();
					File file=new File(Newpath);
					if(!file.exists()){
						file.mkdir();
					}
					if(!path.getText().endsWith("/")){
						new Information("Attention","Default path must end with '/'");
					}
					I.setPath(Newpath);
					this.dispose();
				}catch(Exception ex){
					new Closer(this,6);	
				}
				
				
		}else if(e.getActionCommand().equals("browser")){
			FileDialog SAVE = new FileDialog(this, "���,����д�ļ�������", FileDialog.SAVE);
			SAVE.setVisible(true);
			try {
				
				this.path.setText(SAVE.getDirectory().replace("\\", "/")+SAVE.getFile().toString()+"/");
				
					
			}catch(Exception ex){
				new Closer(this,6);
			}
			SAVE.dispose();
		}else if(e.getActionCommand().equals("help")){
			new Information("Default Path","Default Path is a file Path that MySimpleNote use to help you\nwork. When you press on 'save' in the menu MySimpleNote will\nset the default path as your first choice to save file, when\nyou press 'open' in the function, MySimpleNote will also use\nthe default path to find your documents and list them out\nfor you to choose from When you quit the system, if there are\nsome files that MySimpleNote don't know where to save, the\ndefault path will be used.All in all, just set the path that\nyou use most frequently as the default path. Pay attention\nthat the default must end with '/'");
		}
	
	
	
	}
}
