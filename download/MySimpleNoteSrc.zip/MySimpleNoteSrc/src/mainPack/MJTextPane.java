package mainPack;

import java.io.Serializable;
import javax.swing.JTextPane;
public class MJTextPane extends JTextPane implements Serializable{
	private static final long serialVersionUID = 1L;

}
