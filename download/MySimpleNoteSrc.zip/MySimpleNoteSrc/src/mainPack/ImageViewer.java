package mainPack;

import java.awt.BorderLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import java.io.File;
import java.awt.event.KeyListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class ImageViewer extends JFrame{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * @param args
	 */
	String path;
	JLabel label;
	JScrollPane scroll;
	ImageIcon img,theimg;
	JPanel pane;
	JButton large,small,back;
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	public ImageViewer(){
		
	}
	public ImageViewer(final String path){
		if(path.toLowerCase().endsWith(".jpg")||path.toLowerCase().endsWith(".gif")||path.toLowerCase().endsWith(".png")||path.toLowerCase().endsWith(".jpeg")){
			this.path=path;
			this.img=new ImageIcon(path);
			theimg=img;
			this.label=new JLabel(img,JLabel.CENTER);
			this.scroll=new JScrollPane(label);
			pane=new JPanel();small=new JButton("Zoom out");large=new JButton("Zoom in");
			small.addActionListener(new ActionListener(){

				@Override
				public void actionPerformed(ActionEvent paramActionEvent) {
					lessen();
					
				}
				
			});
			large.addActionListener(new ActionListener(){

				@Override
				public void actionPerformed(ActionEvent paramActionEvent) {
					enlarge();
					
				}
				
			});
			this.back=new JButton("Standard Open");
			back.addActionListener(new ActionListener(){

				@Override
				public void actionPerformed(ActionEvent paramActionEvent) {
					// TODO Auto-generated method stub
					if(new OtherFileOpener().Sopen(path)) ImageViewer.this.dispose();
				}
				
			});
			pane.add(small);
			pane.add(back);
			pane.add(large);
			this.add(pane,BorderLayout.SOUTH);
			this.add(scroll);
			label.addKeyListener(new ml());
			pane.addKeyListener(new ml());
			this.setLocation(nx(200),ny(200));
			this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			this.setTitle(getNameFromPath(path)+" - MySimpleNote Image Viewer");
			this.pack();
			try{
				this.setIconImage((new ImageIcon(MainWindow.class.getResource("/Picture/g.gif")).getImage()));
			}catch(Exception e){
				this.setIconImage((new ImageIcon("Picture/g.gif")).getImage());
			}
			this.setVisible(true);
			pane.requestFocus();
		}
	}
	public boolean GenImage(final String path){
		if(path.toLowerCase().endsWith(".jpg")||path.toLowerCase().endsWith(".gif")||path.toLowerCase().endsWith(".png")||path.toLowerCase().endsWith(".jpeg")){
			this.path=path;
			this.img=new ImageIcon(path);
			theimg=img;
			this.label=new JLabel(img,JLabel.CENTER);
			this.scroll=new JScrollPane(label);
			pane=new JPanel();small=new JButton("Zoom out");large=new JButton("Zoom in");
			small.addActionListener(new ActionListener(){

				@Override
				public void actionPerformed(ActionEvent paramActionEvent) {
					lessen();
					
				}
				
			});
			large.addActionListener(new ActionListener(){

				@Override
				public void actionPerformed(ActionEvent paramActionEvent) {
					enlarge();
					
				}
				
			});
			this.back=new JButton("Standard Open");
			back.addActionListener(new ActionListener(){

				@Override
				public void actionPerformed(ActionEvent paramActionEvent) {
					// TODO Auto-generated method stub
					if(new OtherFileOpener().Sopen(path)) ImageViewer.this.dispose();
					
				}
				
			});
			pane.add(small);
			pane.add(back);
			pane.add(large);
			this.add(pane,BorderLayout.SOUTH);
			this.add(scroll);
			label.addKeyListener(new ml());
			pane.addKeyListener(new ml());
			this.setLocation(nx(200),ny(200));
			this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			this.setTitle(getNameFromPath(path)+" - MySimpleNote Image Viewer");
			
			this.pack();
			try{
				this.setIconImage((new ImageIcon(MainWindow.class.getResource("/Picture/g.gif")).getImage()));
			}catch(Exception e){
				this.setIconImage((new ImageIcon("Picture/g.gif")).getImage());
			}
			this.setVisible(true);
			pane.requestFocus();
			return true;
		}else return false;
	}

		/**
		 * 
		 * @param x 
		 * @return The new value of width x in the local screen
		 */
		public static int nx(int x){
			return (int)(x/(1920.0)*Toolkit.getDefaultToolkit().getScreenSize().width);
		}
		/**
		 * 
		 * @param y
		 * @return The new value of height y in the local screen
		 */
		public static int ny(int y){
			return (int)(y/(1080.0)* Toolkit.getDefaultToolkit().getScreenSize().height);
		}
		
		private String getNameFromPath(String path){
			File tempFile =new File(path.trim());
	        String fileName = tempFile.getName();
	        return fileName;

		}
		private void enlarge(){
			this.remove(scroll);
			img=getImageIcon(img, img.getIconWidth()+10);
			img=getImageIcon(theimg,img.getIconWidth());
			label=new JLabel(img,JLabel.CENTER);
			scroll=new JScrollPane(label);
			this.add(scroll);
			this.validate();
			pane.requestFocus();
			
		}
		private void lessen(){
			this.remove(scroll);
			img=getImageIcon(img, img.getIconWidth()-10);
			img=getImageIcon(theimg,img.getIconWidth());
			label=new JLabel(img,JLabel.CENTER);
			scroll=new JScrollPane(label);
			this.add(scroll);
			this.validate();
			pane.requestFocus();
			
		}
		private ImageIcon getImageIcon(ImageIcon ooicon, int width) {
			ImageIcon oicon=ooicon;
			double rate=(1.0*oicon.getIconHeight())/oicon.getIconWidth();
			  if (width == 0) {
			   return oicon;
			  }
			  ImageIcon icon = oicon;
			  icon.setImage(oicon.getImage().getScaledInstance(width, (int)(rate*width),
			    Image.SCALE_DEFAULT));
			  return icon;
			 }
		private class ml implements KeyListener{

			@Override
			public void keyTyped(KeyEvent paramKeyEvent) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyChar()=='-') lessen();
				else if(e.getKeyChar()=='+'||e.getKeyChar()=='=') enlarge();
				
			}

			@Override
			public void keyReleased(KeyEvent e) {
				
			}
			
		}
		

}
