package mainPack;

import java.awt.Font;

import javax.swing.JOptionPane;
import javax.swing.UIManager;

public class Information {

	/**
	 * @param args
	 */
	Information(String Title, String Message){
		Font font = new Font("����",Font.PLAIN,FontMan.getFont());
		UIManager.put("Label.font",font);
		UIManager.put("Button.font",font);
		JOptionPane.showMessageDialog(null, Message, Title, JOptionPane.ERROR_MESSAGE);
	}

}
