package mainPack;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;


public class FileOpener extends JDialog implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	MainWindow w;
	JLabel path,filename;
	JTextField thepath;
	JComboBox<String> thename;
	JButton open,plush,delet,fresh;
	JPanel main,second,p1,p2;
	FileOpener(MainWindow w){
		super(w,false);
		this.w=w;
		
		path=new JLabel("Path");
		filename=new JLabel("filename");
		thepath=new JTextField(20);
		plush=new JButton("Close");
		open=new JButton("open");
		delet=new JButton("Delet");
		fresh=new JButton("Refresh");
		p1=new JPanel();
		p2=new JPanel();
		
		path.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		filename.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		thepath.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));	
		open.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		plush.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		delet.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		fresh.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		open.addActionListener(this);	open.setActionCommand("open");
		plush.addActionListener(this);	plush.setActionCommand("close");
		delet.addActionListener(this);	delet.setActionCommand("delet");
		fresh.addActionListener(this);	fresh.setActionCommand("fresh");	
		//thepath.setText("TestFile");
		thepath.setText(new DefaultPathManager().getPath());
		
		File[] files = new File(thepath.getText().toString()).listFiles();
		String name[]=new String[files.length]; 
		
		for (int i = 0; i < files.length; i++) {
		  if(!files[i].isDirectory()){
		    name[i]=files[i].getName();	     
		  }
		}
		
		thename=new JComboBox<String>(name);
		thename.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		
		main=new JPanel();	second=new JPanel();

		p1.add(path);		p1.add(thepath);
		p2.add(filename);	p2.add(thename);
		main.setLayout(new GridLayout(3,1));
		main.add(p1);main.add(p2);
		second.add(fresh)	;second.add(delet);second.add(open);
		
		this.add(main);		this.add(second,BorderLayout.SOUTH);
		
		this.setTitle("open");
		this.setVisible(true);
		try{
			this.setIconImage((new ImageIcon(MainWindow.class.getResource("/Picture/g.gif")).getImage()));
		}catch(Exception e){
			this.setIconImage((new ImageIcon("Picture/g.gif")).getImage());
		}
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setPreferredSize(new Dimension(nx(500),ny(400)));
		this.pack();
		this.setLocation(nx(600),ny(300));
	}
	public int nx(int x){
		int wi= Toolkit.getDefaultToolkit().getScreenSize().width; 
		return (int)(x/(1920.0)*wi);
	}
	public int ny(int y){
		int wi= Toolkit.getDefaultToolkit().getScreenSize().height; 
		return (int)(y/(1080.0)*wi);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getActionCommand().equals("open")){
			try{	
				String n=(String)thename.getSelectedItem();
				if(new OtherFileOpener().open(thepath.getText()+n)) return;
				w.ST.addNewTab(thepath.getText()+n);
				this.dispose();
			}catch(Exception ex){
				new Information("Attention","System fail to open this file");	
			}
		}
		if(e.getActionCommand().equals("close")){
			this.dispose();
		}
		if(e.getActionCommand().equals("fresh")){
			try{
				File[] files = new File(thepath.getText().toString()).listFiles();
				String name[]=new String[files.length]; 
				
				for (int i = 0; i < files.length; i++) {
				  if(!files[i].isDirectory()){
				     name[i]=files[i].getName();	     
				  }
				}
				
				main.remove(p2);
				p2.remove(thename);
				thename=new JComboBox<String>(name);
				thename.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
				
				this.remove(main);
				p2.add(thename);
				main.add(p2);
				this.add(main);
				
				this.validate();
				this.setVisible(false); 
				this.setVisible(true);
			
			}catch(Exception ex){}
		}
		if(e.getActionCommand().equals("delet")){
			try{
				File file=new File(thepath.getText().toString()+(String)thename.getSelectedItem());		
				file.delete();
				this.validate();
				
				
			}catch(Exception ex){
				new Information("Fail to delet","Sorry, we encounter problem while deleting your file.");
			}
			try{
				File[] files = new File(thepath.getText().toString()).listFiles();
				String name[]=new String[files.length]; 
				
				for (int i = 0; i < files.length; i++) {
				  if(!files[i].isDirectory()){
				     name[i]=files[i].getName();	     
				  }
				}
				
				main.remove(p2);
				p2.remove(thename);
				thename=new JComboBox<String>(name);
				thename.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
				
				this.remove(main);
				p2.add(thename);
				main.add(p2);
				this.add(main);
				
				this.validate();
				this.setVisible(false); 
				this.setVisible(true);
			
			}catch(Exception ex){}

		}
		
	}

}
