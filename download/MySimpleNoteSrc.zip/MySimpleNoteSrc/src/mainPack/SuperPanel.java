package mainPack;

import java.awt.*;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DropTarget;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import javax.swing.*;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultStyledDocument;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;
import javax.swing.text.html.HTMLEditorKit;
import javax.swing.undo.UndoManager;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import com.inet.jortho.FileUserDictionary;
import com.inet.jortho.PopupListener;
import com.inet.jortho.SpellChecker;
import com.inet.jortho.SpellCheckerOptions;






import tools.TextEncoder;
import tools.TxtDecoder;
import tools.TxtReader;

public class SuperPanel extends JPanel implements ActionListener,KeyListener,ChangeListener,Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//Still need an IO Stream to sent message and receive
	static final int NOTEBOOK=1;
	static final int PROGRAMMER=2;
	static final int CHATWINDOW=3;
	private int model;
	String name;
	String type;
	JPanel body,head,headBody,idle;
	JPanel tail;
	JSplitPane splite;
	JButton close,exit;
	JScrollPane scoll,scoll2;
	JCheckBox imgSave,colorSave,alwaysOnTop,checkSpell;
	JTextPane writeArea;
	JButton addComment,save,run;
	JPanel TalkPane;JButton sent,option;JTextPane message;
	UndoManager undomg;
	HTMLEditorKit kit;
	private SuperTab father;
	private FileOutputStream output;
	boolean HaveConnectedToFile=false;
	boolean isMain;
	String path="";
	String userName="";
	PopupListener ThePopupListener;
	
	SuperPanel(SuperTab father){
		super();
		this.father=father;
		kit = new HTMLEditorKit();
		undomg = new UndoManager();
		
		
		this.model=NOTEBOOK;
		this.name="Untitled.txt";
		this.type="txt";
		this.isMain=true;
		body=new JPanel();
		head=new JPanel();
		headBody=new JPanel();
		idle=new JPanel();
		splite=new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,idle,headBody);
		try{
			exit=new JButton(new ImageIcon(SuperPanel.class.getResource("/Picture/switch.png")));
			close=new JButton(new ImageIcon(SuperPanel.class.getResource("/Picture/Close.png")));
		}catch(Exception e){
			exit=new JButton(new ImageIcon("Picture/switch.png"));
			close=new JButton(new ImageIcon("Picture/Close.png"));
		}
		imgSave=new JCheckBox("����ͼƬ");
		colorSave=new JCheckBox("������ɫ",true);
		checkSpell=new JCheckBox("ƴд���",true);
		alwaysOnTop=new JCheckBox("�����ö�");
		writeArea=new JTextPane();
		scoll=new JScrollPane(writeArea);
		
		tail=new JPanel();
		addComment=new JButton("Comment");
		save=new JButton("Save");
		run=new JButton("Run");
		message=new JTextPane();
		TalkPane=new JPanel();
		TalkPane.setLayout(new GridLayout(2,1));
		scoll2=new JScrollPane(message);
		message.setAutoscrolls(true);
		
		try{
			sent=new JButton(new ImageIcon(SuperPanel.class.getResource("/Picture/sent.png")));
			option=new JButton(new ImageIcon(SuperPanel.class.getResource("/Picture/option.png")));
		}
		catch(Exception e){
			sent=new JButton(new ImageIcon("Picture/sent.png"));
			option=new JButton(new ImageIcon("Picture/option.png"));
		}
		TalkPane.add(option);
		TalkPane.add(sent);
		splite.setOneTouchExpandable(true);
		
		
		kit.install(writeArea);
		exit.setActionCommand("exit");
		close.setActionCommand("close");
		addComment.setActionCommand("addComment");
		save.setActionCommand("save");
		run.setActionCommand("run");
		sent.setActionCommand("sent");
		option.setActionCommand("option");
		exit.addActionListener(this);
		close.addActionListener(father);
		addComment.addActionListener(this);
		save.addActionListener(this);
		run.addActionListener(this);
		sent.addActionListener(this);
		option.addActionListener(this);
		writeArea.getDocument().addUndoableEditListener(undomg);
		
		exit.setPreferredSize(new Dimension(26,26));
		close.setPreferredSize(new Dimension(26,26));
		exit.setBackground(new Color(200,221,242));
		close.setBackground(new Color(200,221,242));
		close.setBorderPainted(false); 
		exit.setBorderPainted(false); 
		exit.setToolTipText("�˳���ǰģʽ");
		sent.setPreferredSize(new Dimension(215,70));
		option.setPreferredSize(new Dimension(215,87));
		writeArea.setFont(new Font("����",Font.PLAIN,30));
		addComment.setFont(new Font("����",Font.PLAIN,30));
		save.setFont(new Font("����",Font.PLAIN,30));
		run.setFont(new Font("����",Font.PLAIN,30));
		message.setFont(new Font("����",Font.PLAIN,30));
		sent.setFont(new Font("����",Font.PLAIN,30));
		option.setFont(new Font("����",Font.PLAIN,30));
		imgSave.setFont(new Font("����",Font.PLAIN,15));
		imgSave.setPreferredSize(new Dimension(100,15));
		imgSave.setBackground(new Color(200,221,242));
		colorSave.setFont(new Font("����",Font.PLAIN,15));
		colorSave.setPreferredSize(new Dimension(100,15));
		colorSave.setBackground(new Color(200,221,242));
		checkSpell.setFont(new Font("����",Font.PLAIN,15));
		checkSpell.setBackground(new Color(200,221,242));
		checkSpell.setPreferredSize(new Dimension(100,15));
		alwaysOnTop.setFont(new Font("����",Font.PLAIN,15));
		alwaysOnTop.setPreferredSize(new Dimension(100,15));
		alwaysOnTop.setBackground(new Color(200,221,242));
		checkSpell.addChangeListener(this);
		checkSpell.setActionCommand("checkSpell");
		
		imgSave.addChangeListener(new ChangeListener(){

			@Override
			public void stateChanged(ChangeEvent arg0) {
				if(imgSave.isSelected()){
					colorSave.setSelected(true);
					colorSave.setEnabled(false);
				}else{
					colorSave.setEnabled(true);
				}
				
			}
			
		});
		
		body.setLayout(new BorderLayout());
		head.setLayout(new BorderLayout());
		this.setLayout(new BorderLayout());
		//head.add(new JButton());
		head.setBackground(new Color(200,221,242));
		headBody.setBackground(new Color(200,221,242));
		idle.setBackground(new Color(200,221,242));
		headBody.setLayout(new FlowLayout(FlowLayout.RIGHT));
		headBody.add(alwaysOnTop);
		headBody.add(checkSpell);
		headBody.add(colorSave);
		//headBody.add(imgSave);
		head.add(close,BorderLayout.EAST);
		head.add(headBody);
		body.add(scoll);
		this.add(head,BorderLayout.NORTH);
		this.add(body);
		
		
		this.writeArea.setDropTarget(new DropTarget(this, DnDConstants.ACTION_REFERENCE,
				father.father, true));
		
		writeArea.addKeyListener(this);
		try{
			SpellChecker.setUserDictionaryProvider(new FileUserDictionary()); 
			
			SpellChecker.registerDictionaries(SuperPanel.class.getResource("/dictionary/"), "en,zh");
			
			SpellChecker.register(writeArea);
			
			}catch(Exception e){
				
			}
		SpellCheckerOptions sco = new SpellCheckerOptions();
		sco.setCaseSensitive(false);
		sco.setSuggestionsLimitMenu(10);
		sco.setLanguageDisableVisible(false);
		sco.setIgnoreAllCapsWords(true);
		sco.setIgnoreWordsWithNumbers(true);
		JPopupMenu popup = SpellChecker.createCheckerPopup(sco);
		ThePopupListener=new PopupListener(popup);
		writeArea.addMouseListener(ThePopupListener);
		writeArea.requestFocus();
		
	}
	//Undo Menu Item
	void undo(){
		if(this.model!=SuperPanel.CHATWINDOW&&this.isMain&&undomg.canUndo())
		undomg.undo(); 	
	}
	//Redo Menu Item
	void redo(){
		if(this.model!=SuperPanel.CHATWINDOW&&this.isMain&&undomg.canRedo())
		undomg.redo();  
	}
	
	//Set Font Menu Item
	public void setNewFont(int i){
		if(this.isMain) this.writeArea.setFont(new Font("����",Font.PLAIN,i));
	}

	// Exit Button and Tool Menu Exit the current model
	void exitModel(){
		switch(this.model){
		case NOTEBOOK:
			break;
		case PROGRAMMER:
			head.remove(exit);
			this.remove(tail);
			break;
		case CHATWINDOW:
			//Exit functionally To be Done
			
			//Exit GUI
			head.remove(exit);
			this.remove(tail);
			writeArea.setEditable(true);
			break;
		}
		writeArea.requestFocus();
		this.validate();
	}
	//Tool menu return the current model
	int getModel(){
		return model;
	}
	//Enter a certain model CUI and Index
	void setModel(int newmodel){
		exitModel();
		if(newmodel==NOTEBOOK){
			this.validate();
		}else if(newmodel==PROGRAMMER){
			tail=new JPanel();
			tail.add(addComment);
			tail.add(save);
			tail.add(run);
			this.add(tail,BorderLayout.SOUTH);
			head.add(exit,BorderLayout.WEST);
			this.validate();
		}else if(newmodel==CHATWINDOW){
			//Change Functionnally to be done
			
			//////////////////////
			tail=new JPanel();
			tail.setLayout(new BorderLayout());
			tail.add(scoll2);
			tail.add(TalkPane,BorderLayout.EAST);
			this.add(tail,BorderLayout.SOUTH);
			head.add(exit,BorderLayout.WEST);
			writeArea.setEditable(false);
			this.validate();
			//Login Log=new Login(this);
		}
		this.model=newmodel;
		writeArea.requestFocus();
	}
	
	
	//Untitled.txt-->save-->setPath and filename-->use connectToFile(save)-->setFileName-->use saveFile()to save
	//Untitled.txt-->open-->setPath and choose filename-->use connectToFile(open)-->setFileName-->use saveFile to save
	//Set current fileName
	void setFileName(String name){
		if(name.endsWith(".txt")){
			this.name=name;
			this.type="txt";
			
		}else if(name.endsWith(".html")){
			this.name=name;
			this.type="html";
		}
		
	}
	//�˵�save as ���� open ���� standard save ���� standard open ���� �Լ��򿪷�ʽ
	boolean connectToFile(String path,String saveoropen){
		this.path=path;
		this.name=getNameFromPath(path);
		try {
			if(saveoropen.equals("open")){
				this.setText(new TxtReader().getTextFromTxt(path));
				new TxtDecoder(this.writeArea,this.writeArea.getText());
			}
		} catch (Exception e) {
			
		}
		try {
			output=new FileOutputStream(this.path);
			if(getWhetherSaveColor()==true){
				String fileText=new TextEncoder(this.writeArea).Encode();
				output.write(fileText.getBytes());
			}else output.write(writeArea.getText().getBytes());
			output.flush();
			output.close();
		} catch (Exception e) {
			return false;
		}
		
		HaveConnectedToFile=true;
		father.setTitleAt(father.getSelectedIndex(), this.name);
		if(name.endsWith(".html")) {
			try{
				father.setIconAt(father.getSelectedIndex(),new ImageIcon(MainWindow.class.getResource("/Picture/htmlIcon.png")));
			}catch(Exception ex){
				father.setIconAt(father.getSelectedIndex(),new ImageIcon("Picture/htmlIcon.png"));
			}
			//this.imgSave.setSelected(false);
			this.colorSave.setSelected(false);
			//this.imgSave.setEnabled(false);
			this.colorSave.setEnabled(false);
			
		}else if(name.endsWith(".txt")) {
			try{
				father.setIconAt(father.getSelectedIndex(),new ImageIcon(MainWindow.class.getResource("/Picture/txticon.png")));
			}catch(Exception ex){
				father.setIconAt(father.getSelectedIndex(),new ImageIcon("Picture/txticon.png"));
			}
			
		}
		return true;
	}
	//�˵� save ���� 
	boolean saveFile(){
		if(HaveConnectedToFile){
			this.name=getRN();
			father.setTitleAt(father.getSelectedIndex(), this.name);
			try {
				output=new FileOutputStream(this.path);
				if(getWhetherSaveColor()==true){
					int value=scoll.getVerticalScrollBar().getValue();
					int value2=writeArea.getCaretPosition();
					String fileText=new TextEncoder(this.writeArea).Encode();
					scoll.getVerticalScrollBar().setValue(value);
					writeArea.setCaretPosition(value2);
					output.write(fileText.getBytes());
				}else{
					output.write(writeArea.getText().getBytes());
				}
				output.flush();
				output.close();
			} catch (IOException e) {
				return false;			
			}
			return true;	
		}else{		
				//Ask for path to connect ����  ��connect ����������˽�FIle��ִ�б�������Ctrl+S �����˵�SAVE
				new Manager(father.father);
				return false;
		}
	}
		
	private String getNameFromPath(String path){
		File tempFile =new File(path.trim());
        String fileName = tempFile.getName();
        return fileName;

	}
	

	
	//Set text color
	void set2balck(){
		if(this.model!=SuperPanel.CHATWINDOW){
			DefaultStyledDocument doc=(DefaultStyledDocument)writeArea.getDocument();
	        SimpleAttributeSet a = new SimpleAttributeSet();
	   
	        StyleConstants.setForeground(a,Color.black);
	        try {
	        	
				doc.insertString(writeArea.getSelectionStart(),writeArea.getSelectedText(),a);
				
	         
	        a = new SimpleAttributeSet();
	        doc.setCharacterAttributes(writeArea.getSelectionStart(),writeArea.getSelectionEnd(),a,false);//����ָ����Χ��������ʽ
	        writeArea.replaceSelection("");
	        if(isMain&&(!this.name.startsWith("*"))){
				this.setFileName("*"+this.name);
				father.setTitleAt(father.getSelectedIndex(), this.name);
			}
	        this.validate();
	        } catch (Exception e1) {}
				
				
			
		}
	}
	void set2red(){
		if(this.model!=SuperPanel.CHATWINDOW){
			DefaultStyledDocument doc=(DefaultStyledDocument)writeArea.getDocument();
	        SimpleAttributeSet a = new SimpleAttributeSet();
	        System.out.println(a+"");
	        StyleConstants.setForeground(a,Color.RED);
	        try {
	        	
				doc.insertString(writeArea.getSelectionStart(),writeArea.getSelectedText(),a);
				
	         
			a = new SimpleAttributeSet();
	        doc.setCharacterAttributes(writeArea.getSelectionStart(),writeArea.getSelectionEnd(),a,false);//����ָ����Χ��������ʽ
	        writeArea.replaceSelection("");
	        if(isMain&&(!this.name.startsWith("*"))){
				this.setFileName("*"+this.name);
				father.setTitleAt(father.getSelectedIndex(), this.name);
			}
	        this.validate();
	        } catch (Exception e1) {}
		}
	}
	void set2green(){
		if(this.model!=SuperPanel.CHATWINDOW){
			DefaultStyledDocument doc=(DefaultStyledDocument)writeArea.getDocument();
	        SimpleAttributeSet a = new SimpleAttributeSet();
	    
	        StyleConstants.setForeground(a,Color.green);
	        try {
	        	
				doc.insertString(writeArea.getSelectionStart(),writeArea.getSelectedText(),a);
				
	         
			a = new SimpleAttributeSet();
	        doc.setCharacterAttributes(writeArea.getSelectionStart(),writeArea.getSelectionEnd(),a,false);//����ָ����Χ��������ʽ
	        writeArea.replaceSelection("");
	        if(isMain&&(!this.name.startsWith("*"))){
				this.setFileName("*"+this.name);
				father.setTitleAt(father.getSelectedIndex(), this.name);
			}
	        this.validate();
	        }catch (Exception e1) {}
		}
	}
	void set2blue(){
		if(this.model!=SuperPanel.CHATWINDOW){
			DefaultStyledDocument doc=(DefaultStyledDocument)writeArea.getDocument();
	        SimpleAttributeSet a = new SimpleAttributeSet();
	       
	        StyleConstants.setForeground(a,Color.blue);
	        try {
	        	
				doc.insertString(writeArea.getSelectionStart(),writeArea.getSelectedText(),a);
				
	         
	        a = new SimpleAttributeSet();
	        doc.setCharacterAttributes(writeArea.getSelectionStart(),writeArea.getSelectionEnd(),a,false);//����ָ����Χ��������ʽ
	        writeArea.replaceSelection("");
	        if(isMain&&(!this.name.startsWith("*"))){
				this.setFileName("*"+this.name);
				father.setTitleAt(father.getSelectedIndex(), this.name);
			}
	        this.validate();
	        } catch (Exception e1) {}
		}
	}
	void set2yellow(){
		if(this.model!=SuperPanel.CHATWINDOW){
			DefaultStyledDocument doc=(DefaultStyledDocument)writeArea.getDocument();
	        SimpleAttributeSet a = new SimpleAttributeSet();
	       
	        StyleConstants.setForeground(a,Color.yellow);
	        try {
	        	
				doc.insertString(writeArea.getSelectionStart(),writeArea.getSelectedText(),a);
				
	         
	        a = new SimpleAttributeSet();
	        doc.setCharacterAttributes(writeArea.getSelectionStart(),writeArea.getSelectionEnd(),a,false);//����ָ����Χ��������ʽ
	        writeArea.replaceSelection("");
	        if(isMain&&(!this.name.startsWith("*"))){
				this.setFileName("*"+this.name);
				father.setTitleAt(father.getSelectedIndex(), this.name);
			}
	        this.validate();
	        } catch (Exception e1) {}
		}
	}
	void set2otherColor(){
		Color color;
		Font font = new Font("����",Font.PLAIN,30);
		
		  UIManager.put("MenuBar.font", font);
	      UIManager.put("MenuItem.font", font);
	      UIManager.put("Menu.font", font);
	      UIManager.put("PopupMenu.font", font);
	      UIManager.put("ToolBar.font", font);
	      UIManager.put("ToolTip.font", font);
	      UIManager.put("TabbedPane.font", font);
	      UIManager.put("Label.font", font);
	      UIManager.put("List.font", font);
	      UIManager.put("ComboBox.font", font);
	      UIManager.put("Button.font", font);
	      UIManager.put("Table.font", font);
	      UIManager.put("TableHeader.font", font);
	      UIManager.put("Tree.font", font);
	      UIManager.put("TextField.font", font);
	      UIManager.put("TextArea.font", font);
	      UIManager.put("TitledBorder.font", font);
	      UIManager.put("OptionPane.font", font);
	      UIManager.put("RadioButton.font", font);
	      UIManager.put("CheckBox.font", font);
	      UIManager.put("ToggleButton.font", font);
	      UIManager.put("Dialog.font", font);
	      UIManager.put("Panel.font", font);
		color=JColorChooser.showDialog(this,"Choose Color",Color.black); 
		if(this.model!=SuperPanel.CHATWINDOW){
			DefaultStyledDocument doc=(DefaultStyledDocument)writeArea.getDocument();
	        SimpleAttributeSet a = new SimpleAttributeSet();
	       
	        StyleConstants.setForeground(a,color);
	        try {
	        	
				doc.insertString(writeArea.getSelectionStart(),writeArea.getSelectedText(),a);
				
	         
	        a = new SimpleAttributeSet();
	        doc.setCharacterAttributes(writeArea.getSelectionStart(),writeArea.getSelectionEnd(),a,false);//����ָ����Χ��������ʽ
	        writeArea.replaceSelection("");
	        if(isMain&&(!this.name.startsWith("*"))){
				this.setFileName("*"+this.name);
				father.setTitleAt(father.getSelectedIndex(), this.name);
			}
	        this.validate();
	        } catch (Exception e1) {}
		}
	}
	
	//Get Real name of the file without a *
	String getRN(){
		String Rname=this.name;
		try{
			Rname=Rname.replace("*", "");
		}catch(Exception e){
			
		}
		return Rname;
	}
	//Get Text of the TextPane
	String getText(){
		return writeArea.getText();
	}
	//Set Text of the TextPane
	void setText(String text){
		writeArea.setText(text);
	}
	//Append Text to the TextPane
	void append(String text){
		writeArea.setText(writeArea.getText()+text);
	}
	//Apend Text with a new Line to the TextPane
	void appendln(String text){
		writeArea.setText(writeArea.getText()+"\n"+text);
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		switch(e.getActionCommand()){
		case "close":
			break;
		case "exit":
		
			this.exitModel();
			this.model=SuperPanel.NOTEBOOK;
			writeArea.requestFocus();
			break;
		case "addComment":
			
		
			try {
				writeArea.getDocument().insertString(writeArea.getCaretPosition(), "<!-- -->", null);
			} catch (BadLocationException e2) {
				
			}
			
			break;
		case "save":
			if(!this.HaveConnectedToFile){
				new Manager(father.father);
			}else{
				if(this.type.equals("txt")){
					this.connectToFile(path.replace(".txt", ".html"), "save");
					this.connectToFile(path.replace(".html", ".txt"), "save");
					
				}else if(this.type.equals("html")){
					this.connectToFile(path.replace(".html", ".txt"), "save");
					this.connectToFile(path.replace(".txt", ".html"), "save");
					
				}
			}
			
			break;
		case "run":
			if(!this.HaveConnectedToFile){
				new Manager(father.father);
			}else{
				if(this.type.equals("txt")){
					
					this.connectToFile(path.replace(".txt", ".html"), "save");
					
					this.connectToFile(path.replace(".html", ".txt"), "save");
					try {
						Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler "+this.path.replace(".txt", ".html"));
					} catch (IOException e1) {
						new Information("Error","Can't run the program");
						
					}
				}else if(this.type.equals("html")){
					this.connectToFile(path.replace(".html", ".txt"), "save");
					this.connectToFile(path.replace(".txt", ".html"), "save");
					try {
						Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler "+this.path);
					} catch (IOException e1) {
						new Information("Error","Can't run the program");
						
					}
				}
			}
			break;
		case "sent":
			
			break;
		case "option":
			
			break;
		}
		
		
	}
	/**
	 * 
	 * @return whether the file is need to be saved
	 */
	boolean needSave(){
		if(this.name.startsWith("*")){
			return true;
		}else{
			return false;
		}
	}
	/**
	 * 
	 * @return whether the color of the file is need to be saved
	 */
	boolean getWhetherSaveColor(){
		if(this.name.endsWith(".html")) return false;
		else if(colorSave.isSelected()) return true;	
		else return false;	
	}
	//return the File object of the file
	public static File getRealPath() {
		 String realPath = SuperPanel.class.getClassLoader().getResource("").getFile();
		 java.io.File file = new java.io.File(realPath);
		 realPath = file.getAbsolutePath();
		 try {
		 realPath = java.net.URLDecoder.decode(realPath, "utf-8");
		 } catch (Exception e) {}
		 return file;
		 }
	/**
	 * When a key is hint, add a * in the front of the filename	
	 */
	@Override
	public void keyPressed(KeyEvent arg0) {
		if(isMain&&(!this.name.startsWith("*"))){
			this.setFileName("*"+this.name);
			father.setTitleAt(father.getSelectedIndex(), this.name);
		}
		
	}
	@Override
	public void keyReleased(KeyEvent arg0) {
		
		
	}
	@Override
	public void keyTyped(KeyEvent arg0) {
		
		
	}
	/**
	 * Control the spellChecker
	 */
	@Override
	public void stateChanged(ChangeEvent e) {
		if(checkSpell.isSelected()){
			SpellChecker.register(writeArea);
			writeArea.addMouseListener(ThePopupListener);
		}else{
			SpellChecker.unregister(writeArea);
			writeArea.removeMouseListener(ThePopupListener);
		}
		
	}
	 public boolean saveAsObj(File writeF) {

			try {
				
				if (!writeF.exists()) {
					writeF.createNewFile();
				}
				StyledDocument doc = (StyledDocument) writeArea.getDocument();
				FileOutputStream fos = new FileOutputStream(writeF);
				ObjectOutputStream oos = new ObjectOutputStream(fos);
				oos.writeObject(doc);
				oos.flush();
				oos.close();
				return true;
			} catch (IOException e) {
				return false;
			}
		}

		public boolean readFromObj(File writeF) {
			try {
				
				if (!writeF.exists()) {
					return false;
				}
				FileInputStream fis = new FileInputStream(writeF);
				ObjectInputStream ois = new ObjectInputStream(fis);
				StyledDocument doc = (StyledDocument) ois.readObject();
				ois.close();
				writeArea.setStyledDocument(doc);
				this.validate();
				father.father.validate();
				return true;
			} catch (Exception e) {
				return false;
			}

		}
}