package towZeroFourEight;
import java.awt.*;

import javax.swing.*;
import java.awt.event.*;
public class MainWindow extends JFrame implements ActionListener, KeyListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JButton NewGame , Close;
	public JPanel Botton;
	Elements Loser;
	int target=2048;
	public Elements[][] E=new Elements[5][5];
	public MainWindow(){
		NewGame=new JButton("New Game");
		Close=new JButton("Close");
		Botton=new JPanel();
		
		NewGame.setFont(new Font("����",Font.PLAIN,30));
		NewGame.setActionCommand("NewGame");
		NewGame.addActionListener(this);
		
		Close.setFont(new Font("����",Font.PLAIN,30));
		Close.setActionCommand("Close");
		Close.addActionListener(this);
		
		Botton.add(NewGame);
		Botton.add(Close);
		Botton.addKeyListener(this);
		this.add(Botton);
		this.setUndecorated(true);
		this.setVisible(true);
		this.setSize(nx(800),ny(50));
		this.setLocation(nx(500),ny(850));
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setAlwaysOnTop(true);
		
		for(int i=1;i<=4;i++){
			for(int j=1;j<=4;j++){
				E[i][j]=new Elements(this,i,j);
				E[i][j].setAlwaysOnTop(true);
				
			}
		}
		int x1=(int)(4* Math.random()+1);
		int y1=(int)(4* Math.random()+1);
		int x2=(int)(4* Math.random()+1);
		int y2=(int)(4* Math.random()+1);
		while(x1==x2&&y1==y2){
			x1=(int)(4* Math.random()+1);
			y1=(int)(4* Math.random()+1);
			x2=(int)(4* Math.random()+1);
			y2=(int)(4* Math.random()+1);
		}
		E[x1][y1].setNumber(2);
		E[x2][y2].setNumber(2);
		
		
		this.setVisible(true);
		Botton.requestFocus();
		
		
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals("Close")){
			for(int i=1;i<=4;i++){
				for(int j=1;j<=4;j++){
					E[i][j].dispose();
				}
			}
			this.dispose();
			try{
				Loser.dispose();
			}catch(Exception ee){
				
			}
		}if(e.getActionCommand().equals("NewGame")){
			try{
				Loser.dispose();
			}catch(Exception ee){
				
			}
			for(int i=1;i<=4;i++){
				for(int j=1;j<=4;j++){
					E[i][j].setNumber(0);
					
				}
			}
			int x1=(int)(4* Math.random()+1);
			int y1=(int)(4* Math.random()+1);
			int x2=(int)(4* Math.random()+1);
			int y2=(int)(4* Math.random()+1);
			while(x1==x2&&y1==y2){
				x1=(int)(4* Math.random()+1);
				y1=(int)(4* Math.random()+1);
				x2=(int)(4* Math.random()+1);
				y2=(int)(4* Math.random()+1);
			}
			E[x1][y1].setNumber(2);
			E[x2][y2].setNumber(2);
			Botton.removeKeyListener(this);
			Botton.addKeyListener(this);
			
			this.setVisible(true);
			Botton.requestFocus();
		}
		
	}
	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
	
	}
	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		if(e.getKeyCode()==KeyEvent.VK_UP||e.getKeyChar()=='w'){
			Botton.removeKeyListener(this);
			int changeTime=0;
			for(int i=1;i<=4;i++){
				//E[1][i];E[2][i];E[3][i];E[4][i];
				if(E[3][i].number==0){
					if(E[4][i].number!=0) changeTime++;
					E[3][i].setNumber(E[4][i].number);
					E[4][i].setNumber(0);
					
					
					
				}
				if(E[2][i].number==0){
					if(E[4][i].number!=0||E[3][i].number!=0) changeTime++;
					E[2][i].setNumber(E[3][i].number);
					E[3][i].setNumber(E[4][i].number);
					E[4][i].setNumber(0);
					
				}
				if(E[1][i].number==0){
					if(E[4][i].number!=0||E[3][i].number!=0||E[2][i].number!=0) changeTime++;
					E[1][i].setNumber(E[2][i].number);
					E[2][i].setNumber(E[3][i].number);
					E[3][i].setNumber(E[4][i].number);
					E[4][i].setNumber(0);
					
				}
				if(E[1][i].number==E[2][i].number&&E[1][i].number!=0){
					if(E[3][i].number==E[4][i].number){
						E[1][i].setNumber(2*E[1][i].number);
						E[2][i].setNumber(2*E[3][i].number);
						E[3][i].setNumber(0);
						E[4][i].setNumber(0);
						changeTime++;
					}else{
						E[1][i].setNumber(2*E[1][i].number);
						E[2][i].setNumber(E[3][i].number);
						E[3][i].setNumber(E[4][i].number);
						E[4][i].setNumber(0);
						changeTime++;
					}
				}else if(E[2][i].number==E[3][i].number&&E[2][i].number!=0){
					E[1][i].setNumber(E[1][i].number);
					E[2][i].setNumber(2*E[2][i].number);
					E[3][i].setNumber(E[4][i].number);
					E[4][i].setNumber(0);
					changeTime++;
				}else if(E[3][i].number==E[4][i].number&&E[3][i].number!=0){
					E[1][i].setNumber(E[1][i].number);
					E[2][i].setNumber(E[2][i].number);
					E[3][i].setNumber(2*E[3][i].number);
					E[4][i].setNumber(0);
					changeTime++;
				}else{
					E[1][i].setNumber(E[1][i].number);
					E[2][i].setNumber(E[2][i].number);
					E[3][i].setNumber(E[3][i].number);
					E[4][i].setNumber(E[4][i].number);
				}
				
			}
			for(int i=1;i<=4;i++){
				for(int j=1;j<=4;j++){
					E[i][j].validate();
					
				}
			}
			if(changeTime==0) {
				Botton.addKeyListener(this);
				return;
				
			}
			addNumber();
			
			Botton.addKeyListener(this);
			
		}
		if(e.getKeyCode()==KeyEvent.VK_DOWN||e.getKeyChar()=='s'){
			Botton.removeKeyListener(this);
			int changeTime=0;
			for(int i=1;i<=4;i++){
				//E[1][i];E[2][i];E[3][i];E[4][i];
				if(E[2][i].number==0){
					if(E[1][i].number!=0) changeTime++;
					E[2][i].setNumber(E[1][i].number);
					E[1][i].setNumber(0);
					
				}
				if(E[3][i].number==0){
					if(E[1][i].number!=0||E[2][i].number!=0) changeTime++;
					E[3][i].setNumber(E[2][i].number);
					E[2][i].setNumber(E[1][i].number);
					E[1][i].setNumber(0);
					
				}
				if(E[4][i].number==0){
					if(E[1][i].number!=0||E[2][i].number!=0||E[3][i].number!=0) changeTime++;
					E[4][i].setNumber(E[3][i].number);
					E[3][i].setNumber(E[2][i].number);
					E[2][i].setNumber(E[1][i].number);
					E[1][i].setNumber(0);
					
				}
				if(E[3][i].number==E[4][i].number&&E[3][i].number!=0){
					if(E[1][i].number==E[2][i].number){
						E[3][i].setNumber(2*E[2][i].number);
						E[1][i].setNumber(0);
						E[2][i].setNumber(0);	
						E[4][i].setNumber(2*E[4][i].number);
						changeTime++;
					}else{
						E[3][i].setNumber(E[2][i].number);
						E[2][i].setNumber(E[1][i].number);
						E[1][i].setNumber(0);					
						E[4][i].setNumber(2*E[4][i].number);
						changeTime++;
					}
				}else if(E[2][i].number==E[3][i].number&&E[3][i].number!=0){
					E[2][i].setNumber(E[1][i].number);
					E[1][i].setNumber(0);
					E[3][i].setNumber(2*E[3][i].number);
					E[4][i].setNumber(E[4][i].number);
					changeTime++;
				}else if(E[1][i].number==E[2][i].number&&E[1][i].number!=0){
					E[1][i].setNumber(0);
					E[2][i].setNumber(2*E[2][i].number);
					E[3][i].setNumber(E[3][i].number);
					E[4][i].setNumber(E[4][i].number);
					changeTime++;
				}else{
					E[1][i].setNumber(E[1][i].number);
					E[2][i].setNumber(E[2][i].number);
					E[3][i].setNumber(E[3][i].number);
					E[4][i].setNumber(E[4][i].number);
				}
				
			}
			for(int i=1;i<=4;i++){
				for(int j=1;j<=4;j++){
					E[i][j].validate();
					
				}
			}
			if(changeTime==0) {
				Botton.addKeyListener(this);
				return;
				
			}
			if(changeTime!=0) addNumber();
			Botton.addKeyListener(this);
			
		}
		
		if(e.getKeyCode()==KeyEvent.VK_LEFT||e.getKeyChar()=='a'){
			Botton.removeKeyListener(this);
			int changeTime=0;
			for(int i=1;i<=4;i++){
				//E[i][1];E[i][2];E[i][3];E[i][4];
				if(E[i][3].number==0){
					if(E[i][4].number!=0) changeTime++;
					E[i][3].setNumber(E[i][4].number);
					E[i][4].setNumber(0);
					
				}
				if(E[i][2].number==0){
					if(E[i][4].number!=0||E[i][3].number!=0) changeTime++;
					E[i][2].setNumber(E[i][3].number);
					E[i][3].setNumber(E[i][4].number);
					E[i][4].setNumber(0);
					
				}
				if(E[i][1].number==0){
					if(E[i][4].number!=0||E[i][3].number!=0||E[i][2].number!=0) changeTime++;
					E[i][1].setNumber(E[i][2].number);
					E[i][2].setNumber(E[i][3].number);
					E[i][3].setNumber(E[i][4].number);
					E[i][4].setNumber(0);
					
				}
				if(E[i][1].number==E[i][2].number&&E[i][1].number!=0){
					if(E[i][3].number==E[i][4].number){
						E[i][1].setNumber(2*E[i][1].number);
						E[i][2].setNumber(2*E[i][3].number);
						E[i][3].setNumber(0);
						E[i][4].setNumber(0);
						changeTime++;
					}else{
						E[i][1].setNumber(2*E[i][1].number);
						E[i][2].setNumber(E[i][3].number);
						E[i][3].setNumber(E[i][4].number);
						E[i][4].setNumber(0);
						changeTime++;
					}
				}else if(E[i][2].number==E[i][3].number&&E[i][2].number!=0){
					E[i][1].setNumber(E[i][1].number);
					E[i][2].setNumber(2*E[i][2].number);
					E[i][3].setNumber(E[i][4].number);
					E[i][4].setNumber(0);
					changeTime++;
				}else if(E[i][3].number==E[i][4].number&&E[i][3].number!=0){
					E[i][1].setNumber(E[i][1].number);
					E[i][2].setNumber(E[i][2].number);
					E[i][3].setNumber(2*E[i][3].number);
					E[i][4].setNumber(0);
					changeTime++;
				}else{
					E[i][1].setNumber(E[i][1].number);
					E[i][2].setNumber(E[i][2].number);
					E[i][3].setNumber(E[i][3].number);
					E[i][4].setNumber(E[i][4].number);
				}
				
			}
			for(int i=1;i<=4;i++){
				for(int j=1;j<=4;j++){
					E[i][j].validate();
					
				}
			}
			if(changeTime==0) {
				Botton.addKeyListener(this);
				return;
				
			}
			if(changeTime!=0) addNumber();
			Botton.addKeyListener(this);
			
		}
		if(e.getKeyCode()==KeyEvent.VK_RIGHT||e.getKeyChar()=='d'){
			Botton.removeKeyListener(this);
			int changeTime=0;
			for(int i=1;i<=4;i++){
				//E[i][1];E[i][2];E[i][3];E[i][4];
				if(E[i][2].number==0){
					if(E[i][1].number!=0) changeTime++;
					E[i][2].setNumber(E[i][1].number);
					E[i][1].setNumber(0);
					
				}
				if(E[i][3].number==0){
					if(E[i][1].number!=0||E[i][2].number!=0) changeTime++;
					E[i][3].setNumber(E[i][2].number);
					E[i][2].setNumber(E[i][1].number);
					E[i][1].setNumber(0);
					
				}
				if(E[i][4].number==0){
					if(E[i][1].number!=0||E[i][2].number!=0||E[i][3].number!=0) changeTime++;
					E[i][4].setNumber(E[i][3].number);
					E[i][3].setNumber(E[i][2].number);
					E[i][2].setNumber(E[i][1].number);
					E[i][1].setNumber(0);
					
				}
				if(E[i][3].number==E[i][4].number&&E[i][3].number!=0){
					if(E[i][1].number==E[i][2].number){
						E[i][3].setNumber(2*E[i][2].number);
						E[i][1].setNumber(0);
						E[i][2].setNumber(0);
						E[i][4].setNumber(2*E[i][4].number);
						changeTime++;
					}else{
						E[i][3].setNumber(E[i][2].number);
						E[i][2].setNumber(E[i][1].number);
						E[i][1].setNumber(0);						
						E[i][4].setNumber(2*E[i][4].number);
						changeTime++;
					}
				}else if(E[i][2].number==E[i][3].number&&E[i][3].number!=0){
					E[i][2].setNumber(E[i][1].number);
					E[i][1].setNumber(0);
					E[i][3].setNumber(2*E[i][3].number);
					E[i][4].setNumber(E[i][4].number);
					changeTime++;
				}else if(E[i][1].number==E[i][2].number&&E[i][1].number!=0){
					E[i][1].setNumber(0);
					E[i][2].setNumber(2*E[i][2].number);
					E[i][3].setNumber(E[i][3].number);
					E[i][4].setNumber(E[i][4].number);
					changeTime++;
				}else{
					E[i][1].setNumber(E[i][1].number);
					E[i][2].setNumber(E[i][2].number);
					E[i][3].setNumber(E[i][3].number);
					E[i][4].setNumber(E[i][4].number);
				}
				
			}
			for(int i=1;i<=4;i++){
				for(int j=1;j<=4;j++){
					E[i][j].validate();
					
				}
			}
			if(changeTime==0) {
				Botton.addKeyListener(this);
				return;
				
			}
			if(changeTime!=0) addNumber();
			Botton.addKeyListener(this);
			
		}
	}
	void addNumber(){
		
		for(int i=1;i<=4;i++){
			for(int j=1;j<=4;j++){
				if(E[i][j].number==target){
					win();
					return;
				}
				
			}
		}
		int x1=(int)(4* Math.random()+1);
		int y1=(int)(4* Math.random()+1);
		
		while(E[x1][y1].hasNumber){
			x1=(int)(4* Math.random()+1);
			y1=(int)(4* Math.random()+1);	
		}
		/*Elements hh=new Elements(this,x1,y1);
		for(int i=1;i<=10;i++){
			E[x1][y1].setSize(E[x1][y1].width,E[x1][y1].width-i*E[x1][y1].width/10);
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				
			}
		}*/
		//hh.dispose();
		//Botton.requestFocus();
		if(((int)(Math.random()*10)+1)==10){
			E[x1][y1].setNumber(4);
		}else{
			E[x1][y1].setNumber(2);
		}
		E[x1][y1].setSize(E[x1][y1].width,E[x1][y1].width);
		if(isLose()){
			gameover();
		}
		
	}
	private void win() {
		// TODO Auto-generated method stub
		Botton.removeKeyListener(this);
		Loser=new Elements(this,"You get "+target+"!");
		Loser.setAlwaysOnTop(true);
	}
	private void gameover() {
		// TODO Auto-generated method stub
		Botton.removeKeyListener(this);
		for(int i=1;i<=4;i++){
			for(int j=1;j<=4;j++){
				E[i][j].validate();
				
			}
		}
		/*try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			
		}*/
		Loser=new Elements(this,"Game Over!");
		Loser.setAlwaysOnTop(true);
		/*for(int i=0;i<3;i++){
			Loser.setVisible(false);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Loser.setVisible(true);
		}*/
		
	}
	@Override
	public void keyTyped(KeyEvent e) {
		
		
		
	}
	public void moveTo(Elements e1,Elements e2){
		Elements E1=new Elements(this,e1.location[0],e1.location[1]);
		int dx=e1.actualLocation[0]-e2.actualLocation[0];
		for(int i=1;i<=25;i++){
			e1.Label.setBackground(Color.blue);
			e1.validate();
			e1.setLocation(e1.actualLocation[0]-i*dx/25,e1.actualLocation[1]-i*dx/25);
			//e1.setLocation(i*25,i*25);
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {}
		}
		e1.setLocation(e1.actualLocation[0],e1.actualLocation[1]);
		E1.dispose();
		Botton.requestFocus();
	}
	public boolean isLose(){
		int changeTime=0;
		for(int i=1;i<=4;i++){
			if(E[3][i].number==0){
				if(E[4][i].number!=0) changeTime++;				
			}
			if(E[2][i].number==0){
				if(E[4][i].number!=0||E[3][i].number!=0) changeTime++;
			}
			if(E[1][i].number==0){				
				if(E[4][i].number!=0||E[3][i].number!=0||E[2][i].number!=0) changeTime++;
			}
			if(E[1][i].number==E[2][i].number){
				if(E[3][i].number==E[4][i].number){				
					changeTime++;
				}else{			
					changeTime++;
				}
			}else if(E[2][i].number==E[3][i].number){				
				changeTime++;
			}else if(E[3][i].number==E[4][i].number){			
				changeTime++;
			}
			if(E[2][i].number==0){
			
				if(E[1][i].number!=0) changeTime++;
			}
			if(E[3][i].number==0){
			
				if(E[1][i].number!=0||E[2][i].number!=0) changeTime++;
			}
			if(E[4][i].number==0){
			
				if(E[1][i].number!=0||E[2][i].number!=0||E[3][i].number!=0) changeTime++;
			}
			if(E[3][i].number==E[4][i].number){
				if(E[1][i].number==E[2][i].number){
					changeTime++;
				}else{
					
					changeTime++;
				}
			}else if(E[2][i].number==E[3][i].number){
				
				changeTime++;
			}else if(E[1][i].number==E[2][i].number){
				
				changeTime++;
			}
			if(E[i][3].number==0){
				
				if(E[i][4].number!=0) changeTime++;	
			}
			if(E[i][2].number==0){
				
				if(E[i][4].number!=0||E[i][3].number!=0) changeTime++;
			}
			if(E[i][1].number==0){
				
				if(E[i][4].number!=0||E[i][3].number!=0||E[i][2].number!=0) changeTime++;
			}
			if(E[i][1].number==E[i][2].number){
				if(E[i][3].number==E[i][4].number){
					
					changeTime++;
				}else{
					
					changeTime++;
				}
			}else if(E[i][2].number==E[i][3].number){
				
				changeTime++;
			}else if(E[i][3].number==E[i][4].number){
				
				changeTime++;
			}
			if(E[i][2].number==0){
				
				if(E[i][1].number!=0) changeTime++;
			}
			if(E[i][3].number==0){
			
				if(E[i][1].number!=0||E[i][2].number!=0) changeTime++;
			}
			if(E[i][4].number==0){
				
				if(E[i][1].number!=0||E[i][2].number!=0||E[i][3].number!=0) changeTime++;
			}
			if(E[i][3].number==E[i][4].number){
				if(E[i][1].number==E[i][2].number){
					
					changeTime++;
				}else{
					
					changeTime++;
				}
			}else if(E[i][2].number==E[i][3].number){
				
				changeTime++;
			}else if(E[i][1].number==E[i][2].number){
				
				changeTime++;
			}
			
		}
		if(changeTime==0) return true;	
		else return false;
	}
	public int nx(int x){
		return (int)(x/(1920.0)*Toolkit.getDefaultToolkit().getScreenSize().width);
	}
	public int ny(int y){
		return (int)(y/(1080.0)*Toolkit.getDefaultToolkit().getScreenSize().height);
	}

}
