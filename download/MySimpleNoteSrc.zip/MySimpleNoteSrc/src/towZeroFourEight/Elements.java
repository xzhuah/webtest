package towZeroFourEight;
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
public class Elements extends JFrame implements ActionListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	boolean hasNumber=false;
	int[] location=new int[2];
	int[] actualLocation=new int[2];
	int number;
	int width;
	MainWindow M;
	JLabel Label;
	JPanel Panel;
	JButton goon;
	Elements(MainWindow M,int x,int y){
		this.M=M;
		width=M.getWidth()/4;
		int X=M.getX();
		int Y=M.getY();
		this.hasNumber=false;
		location[0]=x;location[1]=y;
		actualLocation[0]=X+(location[1]-1)*width;
		actualLocation[1]=Y-(5-location[0])*width;
		
		Label=new JLabel("",JLabel.CENTER);
		Panel=new JPanel();
		
		Label.setFont(new Font("����",Font.PLAIN,150));
		Panel.setLayout(new BorderLayout());
		Panel.add(Label);
		
		this.add(Panel);
		this.setUndecorated(true);
		this.setSize(width,width);
		this.setLocation(actualLocation[0],actualLocation[1]);
		this.setVisible(true);
		
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	}
	Elements(MainWindow M,String S){
		goon=new JButton("Go on");
		goon.setFont(new Font("����",Font.PLAIN,30));
		this.M=M;
		width=M.getWidth();
		int X=M.getX();
		int Y=M.getY();
		
		goon.setActionCommand("goon");
		goon.addActionListener(this);
		Label=new JLabel(S,JLabel.CENTER);
		Panel=new JPanel();
		
		Label.setFont(new Font("����",Font.PLAIN,100));
		Label.setForeground(Color.red);
		
		Panel.setLayout(new BorderLayout());
		Panel.add(Label);
		Panel.add(goon,BorderLayout.SOUTH);
		Panel.setBackground(Color.green);
		Label.setBackground(Color.green);
		
		this.add(Panel);
		//com.sun.awt.AWTUtilities.setWindowOpacity(this, (float) 0.6);   
		this.setUndecorated(true);
		this.setSize(width,width);
		this.setLocation(X,Y-width);
		this.setVisible(true);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		/*for(int i=1;i<=50;i++){
			this.setSize(width,i*width/50);
			try {
				Thread.sleep(20);
				this.validate();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				
			}
		}*/
	}
	public static void main(String[] args) {
		new Elements(new MainWindow(),"dd");
		
	}
	void renew(){
		
	}
	void moveTo(int x,int y){
		location[0]=x;location[1]=y;
		int X=M.getX();
		int Y=M.getY();
		actualLocation[0]=X+(location[1]-1)*width;
		actualLocation[1]=Y-(5-location[0])*width;
		this.setLocation(actualLocation[0],actualLocation[1]);
	}
	void ChangeNumber(int number){
		if(number!=0){
			this.number=number;
			this.Label.setText(""+number);
			this.validate();
			this.hasNumber=true;
		}else{
			this.Label.setText("");
			this.validate();
			this.hasNumber=false;
		}
	}
	boolean canMoveUp(){
		if(location[0]==1){
			return false;
		}else{
			if((!(M.E[location[0]-1][location[1]].hasNumber))||(M.E[location[0]-1][location[1]].number==this.number)){
				return true;
			}
		}
		return false;
		
	}
	boolean canMoveDown(){
		if(location[0]==4){
			return false;
		}else{
			if((!(M.E[location[0]+1][location[1]].hasNumber))||(M.E[location[0]+1][location[1]].number==this.number)){
				return true;
			}
		}
		return false;
	}
	boolean canMoveRight(){
		if(location[1]==4){
			return false;
		}else{
			if((!(M.E[location[0]][location[1]+1].hasNumber))||(M.E[location[0]][location[1]+1].number==this.number)){
				return true;
			}
		}
		return false;
	}
	boolean canMoveLeft(){
		if(location[1]==1){
			return false;
		}else{
			if((!(M.E[location[0]][location[1]-1].hasNumber))||(M.E[location[0]][location[1]-1].number==this.number)){
				return true;
			}
		}
		return false;
	}
	void MoveUp(){
		if((!M.E[location[0]-1][location[1]].hasNumber)){
			this.moveTo(location[0]-1,location[1]);
			M.E[location[0]-1][location[1]].moveTo(location[0]+1, location[1]);
			M.E[location[0]][location[1]]=M.E[location[0]-1][location[1]];
			M.E[location[0]-1][location[1]]=this;
		}
		if((M.E[location[0]+1][location[1]].number==this.number)){
			this.moveTo(location[0]-1,location[1]);
			M.E[location[0]-1][location[1]].moveTo(location[0]+1, location[1]);
			M.E[location[0]-1][location[1]].number=0;
			M.E[location[0]-1][location[1]].hasNumber=false;
			this.number*=2;
			M.E[location[0]][location[1]]=M.E[location[0]-1][location[1]];
			M.E[location[0]-1][location[1]]=this;
		}
		this.validate();
		M.E[location[0]][location[1]].validate();
		M.validate();
	}
	void MoveDown(){
		if((!(M.E[location[0]+1][location[1]].hasNumber))){
			
		}
		if((M.E[location[0]+1][location[1]].number==this.number)){
			
		}
	}
	void MoveLeft(){
		if((!(M.E[location[0]][location[1]-1].hasNumber))){
			
		}
		if((M.E[location[0]][location[1]-1].number==this.number)){
			
		}
	}
	void MoveRight(){
		if((!(M.E[location[0]][location[1]+1].hasNumber))){
			
		}
		if((M.E[location[0]][location[1]+1].number==this.number)){
			
		}
	}
	void setNumber(int i){
		this.number=i;
		if(i==0){
			this.hasNumber=false;
			this.Label.setText("");
		}else{
			this.hasNumber=true;
			this.Label.setText(""+i);
		}
		if(i<100) Label.setFont(new Font("����",Font.PLAIN,120));
		if(i>=100) Label.setFont(new Font("����",Font.PLAIN,90));
		if(i>=1000) Label.setFont(new Font("����",Font.PLAIN,60));
		//Color color=new Color(0,0,0,0);;
		switch(i){
			case 2:
				//color=new Color(192,192,192);
				this.Panel.setBackground(Color.lightGray);
				this.Label.setForeground(Color.black);
				break;
			case 4:
				this.Panel.setBackground(Color.pink);
				this.Label.setForeground(Color.black);
				//color=new Color(255,175,175);
				break;
			case 8:
				this.Panel.setBackground(Color.orange);
				this.Label.setForeground(Color.black);
				//color=new Color(255,200,0);
				break;
			case 16:
				this.Panel.setBackground(Color.yellow);
				this.Label.setForeground(Color.black);
				//color=new Color(255,255,0);
				break;
			case 32:
				this.Panel.setBackground(Color.red);
				this.Label.setForeground(Color.black);
				//color=new Color(255,0,0);
				break;
			case 64:
				this.Panel.setBackground(Color.magenta);
				this.Label.setForeground(Color.black);
				//color=new Color(0,0,255);
				break;
			case 128:
				this.Panel.setBackground(Color.blue);
				this.Label.setForeground(Color.black);
				//color=new Color(0,255,0);
				break;
			case 256:
				this.Panel.setBackground(Color.green);
				this.Label.setForeground(Color.black);
				//color=new Color(255,0,255);
				break;
			case 512:
				this.Panel.setBackground(Color.cyan);
				this.Label.setForeground(Color.red);
				//color=new Color(0,255,255);
				break;
			case 1024:
				this.Panel.setBackground(Color.darkGray);
				this.Label.setForeground(Color.yellow);
				//color=new Color(64,64,64);
				break;
			case 2048:
				this.Panel.setBackground(Color.gray);
				this.Label.setForeground(Color.yellow);
				//color=new Color(255,255,64);
				break;
			default:
				//color=new Color(0,0,0,0);
				this.Panel.setBackground(null);
		}
		//this.Label.setBackground(color);
		
		this.validate();
	
	}
	public int nx(int x){
		int wi= Toolkit.getDefaultToolkit().getScreenSize().width; 
		return (int)(x/(1920.0)*wi);
	}
	public int ny(int y){
		int wi= Toolkit.getDefaultToolkit().getScreenSize().height; 
		return (int)(y/(1080.0)*wi);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getActionCommand().equals("goon")){
			for(int i=1;i<=50;i++){
				this.setSize(width,width-i*width/50);
				try {
					Thread.sleep(20);
					this.validate();
				} catch (InterruptedException ex) {
					// TODO Auto-generated catch block
					
				}
			}
			this.dispose();
			M.target*=2;
			M.Botton.requestFocus();
		}
	}
	

}
