package main;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import mainPack.FontMan;
import mainPack.MainWindow;


public class Reminder extends JFrame implements ActionListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JLabel i;
	JButton ok;
	JPanel J;
	
	Reminder(){
		i=new JLabel("�����������ѳ���20Сʱ�����Ͻ������������",JLabel.CENTER);
		J=new JPanel();
		ok=new JButton("��֪����");
		
		i.setFont(new Font("����",Font.PLAIN,20));
		ok.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		
		
		ok.addActionListener(this);
		ok.setActionCommand("OK");
		
		J.add(ok);
		
		this.add(i);
		this.add(J,BorderLayout.SOUTH);
		try{
			this.setIconImage((new ImageIcon(MainWindow.class.getResource("/Picture/g.gif")).getImage()));
		}catch(Exception e){
			this.setIconImage((new ImageIcon("Picture/g.gif")).getImage());
		}
		
		this.setTitle("��ʱ����");
		this.setVisible(true);	
		//Opener OO=new Opener(this,900, 500, 550, 200, (int)(Math.random()*4)+1);
		this.setSize(nx(550),ny(200));
		this.setLocation(nx(900),ny(500));
		this.setResizable(false);
		
	}
	public int nx(int x){
		return (int)(x/(1920.0)*Toolkit.getDefaultToolkit().getScreenSize().width);
	}
	public int ny(int y){
		return (int)(y/(1080.0)*Toolkit.getDefaultToolkit().getScreenSize().height);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals("OK")) this.dispose();
			
	}
}
