package main;

import java.awt.event.*;
import java.awt.*;

import javax.swing.*;

import javax.swing.JFrame;

import mainPack.FontMan;
import mainPack.MainWindow;


public class Imformations extends JFrame implements ActionListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected JButton ok;
	protected JLabel hint;
	protected JPanel botton;
	
	public static void main(String[] args) {
		new Imformations("Windows","Look at me!");
	}
	
	public Imformations(String Title,String information){
		ok=new JButton("OK");
		hint=new JLabel(information,JLabel.CENTER);
		botton=new JPanel();
		
		ok.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		hint.setFont(new Font("����",Font.PLAIN,20));
		
		ok.addActionListener(this);
		ok.setActionCommand("ok");
		
		botton.add(ok);
		
		this.add(hint);
		this.add(botton,BorderLayout.SOUTH);
		
		this.setTitle(Title);
		this.setVisible(true);
		try{
			this.setIconImage((new ImageIcon(MainWindow.class.getResource("/Picture/g.gif")).getImage()));
		}catch(Exception e){
			this.setIconImage((new ImageIcon("Picture/g.gif")).getImage());
		}
		this.setSize(nx(700), ny(300));
		this.setLocation(nx(300),ny(300));
		this.setResizable(false);
		
		
		
	}
	public Imformations(String Title,String information,int width,int height){
		ok=new JButton("OK");
		hint=new JLabel(information,JLabel.CENTER);
		botton=new JPanel();
		
		ok.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		hint.setFont(new Font("����",Font.PLAIN,20));
		
		ok.addActionListener(this);
		ok.setActionCommand("ok");
		
		botton.add(ok);
		
		this.add(hint);
		this.add(botton,BorderLayout.SOUTH);
		
		this.setTitle(Title);
		this.setVisible(true);
		try{
			this.setIconImage((new ImageIcon(MainWindow.class.getResource("/Picture/g.gif")).getImage()));
		}catch(Exception e){
			this.setIconImage((new ImageIcon("Picture/g.gif")).getImage());
		}
		//Opener O=new Opener(this,300, 300, width, height, (int)(Math.random()*4)+1);
		this.setSize(nx(width), ny(height));
		this.setLocation(nx(300),ny(300));
		this.setResizable(false);
	
		
		
	}
	public Imformations(String Title,String information,String button){
		ok=new JButton(button);
		hint=new JLabel(information,JLabel.CENTER);
		botton=new JPanel();
		
		ok.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		hint.setFont(new Font("����",Font.PLAIN,20));
		
		ok.addActionListener(this);
		ok.setActionCommand("ok");
		
		botton.add(ok);
		
		this.add(hint);
		this.add(botton,BorderLayout.SOUTH);
		
		this.setTitle(Title);
		this.setVisible(true);
		try{
			this.setIconImage((new ImageIcon(MainWindow.class.getResource("/Picture/g.gif")).getImage()));
		}catch(Exception e){
			this.setIconImage((new ImageIcon("Picture/g.gif")).getImage());
		}
		//Opener O=new Opener(this,300, 300, 700, 300, (int)(Math.random()*4)+1);
		this.setSize(nx(700), ny(300));
		this.setLocation(nx(700), ny(300));
		this.setResizable(false);
		
		
		
	}
	public Imformations(String Title,String information,String button,int width,int height){
		ok=new JButton(button);
		hint=new JLabel(information,JLabel.CENTER);
		botton=new JPanel();
		
		ok.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		hint.setFont(new Font("����",Font.PLAIN,20));
		
		ok.addActionListener(this);
		ok.setActionCommand("ok");
		
		botton.add(ok);
		
		this.add(hint);
		this.add(botton,BorderLayout.SOUTH);
		
		this.setTitle(Title);
		this.setVisible(true);
		try{
			this.setIconImage((new ImageIcon(MainWindow.class.getResource("/Picture/g.gif")).getImage()));
		}catch(Exception e){
			this.setIconImage((new ImageIcon("Picture/g.gif")).getImage());
		}
		//Opener O=new Opener(this,300, 300, width, height, (int)(Math.random()*4)+1);
		this.setSize(nx(width), ny(height));
		this.setLocation(nx(300), ny(300));
		this.setResizable(false);
	
		
		
	}
	public Imformations(String Title,String information,String button,int width,int height,boolean whether){
		//This constructor can choose whether to build a window or not based on the user's order
		ok=new JButton(button);
		hint=new JLabel(information,JLabel.CENTER);
		botton=new JPanel();
		
		ok.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		hint.setFont(new Font("����",Font.PLAIN,20));
		
		ok.addActionListener(this);
		ok.setActionCommand("ok");
		
		botton.add(ok);
		
		this.add(hint);
		this.add(botton,BorderLayout.SOUTH);
		
		this.setTitle(Title);
		this.setVisible(true);
		try{
			this.setIconImage((new ImageIcon(MainWindow.class.getResource("/Picture/g.gif")).getImage()));
		}catch(Exception e){
			this.setIconImage((new ImageIcon("Picture/g.gif")).getImage());
		}
		//Opener O=new Opener(this,300, 300, width, height, (int)(Math.random()*4)+1);
		this.setSize(nx(width), ny(height));
		this.setLocation(nx(300),ny(300));
		this.setResizable(false);
		
		
		
	}
	
	public int nx(int x){
		return (int)(x/(1920.0)*Toolkit.getDefaultToolkit().getScreenSize().width);
	}
	public int ny(int y){ 
		return (int)(y/(1080.0)*Toolkit.getDefaultToolkit().getScreenSize().height);
	}
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals("ok")){
			this.dispose();
		}
		
	}

}
