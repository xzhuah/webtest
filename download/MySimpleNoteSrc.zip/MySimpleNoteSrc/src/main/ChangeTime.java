package main;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.FileOutputStream;
import java.util.Calendar;

import javax.swing.JTextField;

import mainPack.FontMan;
import mainPack.MainWindow;

import tools.Closer;

//This class is used to change the Online time
public class ChangeTime extends Imformations implements WindowListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * @param args
	 */

	JTextField g;
	MainWindow w;
	public static void main(String[] args) {
		new ChangeTime();

	}
	public ChangeTime(String Title,String thehint,final MainWindow w){
		super(Title,thehint,750,200);
		this.w=w;
		botton.remove(ok);
		g=new JTextField(20);
		g.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent paramActionEvent) {
				try{
					w.getWorkingArea().setNewFont(Integer.parseInt(g.getText()));
					g.setText("");
				}catch(Exception ex){
					new Closer(w,6);
				}
				
			}
			
		});
		botton.add(g);
		ok.setActionCommand("set");
		ok.setText("Set");
		botton.add(ok);
		hint.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		g.setFont(new Font("����",Font.PLAIN,35));
		this.pack();
		this.setVisible(false);
		this.setVisible(true);
	}
	public ChangeTime(){
		super("�޸ĳ�ʼʱ��","�뽫ʱ�仯Ϊ�벢�������¿���",450,200);
		botton.remove(ok);
		g=new JTextField(20);
		botton.add(g);
		botton.add(ok);
		hint.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		g.setFont(new Font("����",Font.PLAIN,35));
		this.setVisible(false);
		this.setVisible(true);
	}
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals("ok")){
			try(FileOutputStream O=new FileOutputStream("Time/TimeRecord.txt");){
				Calendar c=Calendar.getInstance();
				int ThisMonth=c.get(Calendar.MONTH)+1;
				O.write((ThisMonth+"").getBytes());
				O.write(" ".getBytes());
				O.write(g.getText().getBytes());
				O.write(".".getBytes());
				O.flush();
				this.dispose();
			}catch(Exception ex){
				new Closer(this,6);
			}
			
		}
		if(e.getActionCommand().equals("set")){
			try{
				w.getWorkingArea().setNewFont(Integer.parseInt(g.getText()));
				g.setText("");
			}catch(Exception ex){
				new Closer(this,6);
			}
		}
		
	}
	@Override
	public void windowActivated(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void windowClosed(WindowEvent arg0) {
		// TODO Auto-generated method stub
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.dispose();
	}
	@Override
	public void windowClosing(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void windowDeactivated(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void windowDeiconified(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void windowIconified(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void windowOpened(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
