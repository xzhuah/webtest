package main;
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

import mainPack.FontMan;
import mainPack.MainWindow;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Calendar;
public class Counter extends JFrame implements ActionListener,WindowListener{
	/**
	 * ϣ����ʵ����С������
	 */
	private static final long serialVersionUID = 1L;
	JLabel hint,hint1;
	JPanel Panel,Panel1,panel2;
	JButton Begin,check,change;
	int TotalTime,time,ThisMonth,OldMonth;
	String Month,oldMonth;
	FileOutputStream O;
	FileReader I;
	boolean haveReminded=false;
	boolean cansee=true;
	boolean ischanging=false;
	
	
	
	
	
	public static void main(String[] args) throws Exception {
		try {
				new Counter();
			
		} catch (FileNotFoundException e) {
			
		}

	}
	public Counter() throws Exception{
		oldMonth="";
		String tt="";
		I=new FileReader("Time/TimeRecord.txt");
		
		char n=(char)I.read();
		oldMonth+=n;
		while((int)n!=32){
			n=(char)I.read();
			oldMonth+=n;
		}
		
		String hh="";
		for(int i=0;i<oldMonth.length()-1;i++){
			hh+=oldMonth.charAt(i);
		}
		OldMonth=Integer.parseInt(hh);
		char m=(char)I.read();
		tt+=m;
		while(!((m+"").equals("."))){
			m=(char)I.read();
			tt+=m;
		}
		String t="";
		for(int i=0;i<tt.length()-1;i++){
			t+=tt.charAt(i);
		}
		TotalTime=Integer.parseInt(t);
		I.close();
		
		//We get int OldMonth and int TotalTime(s) here
		
		time=0;
		ThisMonth=0;
		Calendar c=Calendar.getInstance();//
		ThisMonth=c.get(Calendar.MONTH)+1;
		Month=ThisMonth+"";
		//we get all data here OldMonth TotalTime ThisMonth Time
		if(ThisMonth!=OldMonth){
			O=new FileOutputStream("Time/TimeRecord.txt");
			O.write(Month.getBytes());
			O.write(" ".getBytes());
			O.write("0".getBytes());
			O.write(".".getBytes());
			O.close();
			TotalTime=0;
		}
		
		
		//Data Ready!
		
		this.setLayout(new GridLayout(3,1));
		
		int hour=(int)(TotalTime/3600);	
		int minute=(int)((TotalTime-hour*3600)/60);
		int second=TotalTime-3600*hour-60*minute;
		int hour1=(int)(time/3600);
		int minute1=(int)((time-hour1*3600)/60);
		int second1=time-3600*hour1-60*minute1;
		
		hint=new JLabel(Month+"�·�������"+hour+"Сʱ"+minute+"����"+second+"��",JLabel.CENTER);
		hint.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		hint1=new JLabel("����������"+hour1+"Сʱ"+minute1+"����"+second1+"��",JLabel.CENTER);
		hint1.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		//Begin=new JButton("��С����������");
		//check=new JButton("�鿴��������ʱ��");
		//Panel=new JPanel();
		//Panel1=new JPanel();
		
		
		//Begin.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		//check.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		
		//Begin.addActionListener(this);
		//Begin.setActionCommand("Begin");
		
		
		//Panel.add(check);
		//Panel1.add(hint);
		//this.add(Panel1);
		//this.add(Panel,BorderLayout.SOUTH);
		panel2=new JPanel();
		change=new JButton("�޸�ʱ��");
		change.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		panel2.add(change);

		change.addActionListener(this);
		change.setActionCommand("change");
		
		this.add(hint);this.add(hint1);this.add(panel2);
		this.setTitle("�����ʱ��");
		try{
			this.setIconImage((new ImageIcon(MainWindow.class.getResource("/Picture/g.gif")).getImage()));
		}catch(Exception e){
			this.setIconImage((new ImageIcon("Picture/g.gif")).getImage());
		}
		this.setVisible(true);	
		//Opener OO=new Opener(this,600, 300, 550, 200, (int)(Math.random()*4)+1);
		this.setSize(600,250);
		this.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
		this.setLocation(600,400);
		this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		this.addWindowListener(this);
		
		while(!ischanging){
			if(isConnect()){
				try {
					if(TotalTime>=20*3600&&!haveReminded){
						new Reminder();
						haveReminded=true;
					}
					Thread.sleep(1000);
					this.remove(hint);
					this.remove(hint1);
					this.remove(panel2);
					TotalTime+=1;
					time+=1;
					O=new FileOutputStream("Time/TimeRecord.txt");
					O.write((Month+" "+TotalTime+".").getBytes());
					O.close();
					hour=(int)(TotalTime/3600);
					minute=(int)((TotalTime-hour*3600)/60);
					second=TotalTime-3600*hour-60*minute;
					hour1=(int)(time/3600);
					minute1=(int)((time-hour1*3600)/60);
					second1=time-3600*hour1-60*minute1;
					hint=new JLabel(Month+"�·�������"+hour+"Сʱ"+minute+"����"+second+"��",JLabel.CENTER);
					hint.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
					hint1=new JLabel("����������"+hour1+"Сʱ"+minute1+"����"+second1+"��",JLabel.CENTER);
					hint1.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
					this.add(hint);
					this.add(hint1);
					this.add(panel2);
					/*this.setVisible(false);
					if(cansee){
						this.setVisible(true);
					}*/
					validate();
				} catch (Exception e1) {
					
					
				}
				
			}else{
				time=0;
				if(haveReminded==true){
					haveReminded=false;
				}
				
				hour1=(int)(time/3600);
				minute1=(int)((time-hour1*3600)/60);
				second1=time-3600*hour1-60*minute1;
				Thread.sleep(1000);
				this.remove(hint);
				this.remove(hint1);
				this.remove(panel2);
				hint=new JLabel(Month+"�·�������"+hour+"Сʱ"+minute+"����"+second+"��",JLabel.CENTER);
				hint.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
				hint1=new JLabel("����������"+hour1+"Сʱ"+minute1+"����"+second1+"��",JLabel.CENTER);
				hint1.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
				this.add(hint);
				this.add(hint1);
				this.add(panel2);
				/*
				this.setVisible(false);
				if(cansee){
					this.setVisible(true);
				
				}*/
			validate();
			}
		}
	}
	boolean isConnect(){
		 URL url = null;  
	        try {  
	            url = new URL("http://baidu.com");  
	            try {  
	                InputStream in = url.openStream();  
	                in.close();  
	                return true;
	            } catch (IOException e) {  
	                return false;
	            }  
	        } catch (MalformedURLException e) {  
	            
	        } 
	    return false;
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals("change")){
			ischanging=true;
			this.dispose();
			new ChangeTime();
			
			//this.setVisible(false);
			/*while(true){
				if(isConnect()){
					try {
						Thread.sleep(1000);
						TotalTime+=1;
						time+=1;
						O=new FileOutputStream("Time/TimeRecord.txt");
						O.write((Month+" "+TotalTime+".").getBytes());
						O.close();
					} catch (Exception e1) {
						
						
					}
					
				}else{
					
				}
			}*/
			 
		}/*else if(e.getActionCommand().equals("check")){
			this.remove(Panel1);
			Panel1.remove(hint);
			int hour=(int)(TotalTime/3600);
			int minute=(int)((TotalTime-hour*3600)/60);
			int second=TotalTime-3600*hour-60*minute;
			int hour1=(int)(time/3600);
			int minute1=(int)((time-hour*3600)/60);
			int second1=time-3600*hour-60*minute;
			hint=new JLabel(Month+"�·�������"+hour+"Сʱ"+minute+"����"+second+"��",JLabel.CENTER);
			hint.setFont(new Font("����",Font.PLAIN,FontMan.getFont()));
			Panel1.add(hint);
			this.add(Panel1);
			this.setVisible(false);
			this.setVisible(true);
		}*/
		
	}
	@Override
	public void windowActivated(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void windowClosed(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void windowClosing(WindowEvent e) {
		if(!ischanging){
			this.setVisible(false);
			cansee=false;
			int i=0;
			FileInputStream O;
			
				try {
					O = new FileInputStream("Time/WhetherShow.txt");
					i=O.read();
					
					O.close();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					
				}
				
			if(i==49) {
				new MyInformation("����","������ʱ���������ر��������ں�̨������������������",550,200);
			}
		}else{
			this.dispose();
		}
	}
	@Override
	public void windowDeactivated(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void windowDeiconified(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void windowIconified(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void windowOpened(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	


}
