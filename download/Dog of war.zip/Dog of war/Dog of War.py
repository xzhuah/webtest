'''
ZHU Xinyu
ID Number:20256148
COMP 1021  L2 LA3
Note : I add a lot of features in the game because I am very interested in it.
       In my game the leading role dog can have more than one life so it may not die when
       it touch the enermy but it will lose one of its lives.
       Pay attention that after the borders have reach the minimum width
       the channel will begin to move up and down when you get more than 10000 scores.
       The more scores you get the faster it will move! This may change the number of enermy
       you can see but it won't decrese the difficuty.
       For more details you can refer to the description inside my game.

'''


import turtle
import random
###import pygame
import time
"""
    Constants and variables
"""
# Part 1
# Set up constants and variables
###pygame.mixer.init()
###pygame.init()
# Window size
window_height = 600
window_width = 600
###sound1 = pygame.mixer.Sound('000.wav')
###sound2 = pygame.mixer.Sound('111.wav')
###sound3 = pygame.mixer.Sound('02.Rock House Jail.wav')
###sound4 = pygame.mixer.Sound('003.wav')
###sound_apple=pygame.mixer.Sound('apple.wav')
###skill_sound=pygame.mixer.Sound('dog.wav')
###skill_sound1=pygame.mixer.Sound('dog1.wav')
###skill_sound2=pygame.mixer.Sound('dog2.wav')
###sound1.play(-1)
# The screen update interval
update_interval = 25

# Parameters for controlling the width of the river
river_width = 300
minimum_river_width = 100

# Border parameters
border_height = 600

# Parameters for gradually decreasing river width
river_width_update = 0.5

# How far should we stay away from the borders
safe_distance_from_border = border_height / 2
target=10000
times=15
times+=1
score=0

score_turtle=turtle.Turtle()
score_turtle.hideturtle()
score_turtle.up()
score_turtle.goto(0,275)
score_turtle.color('white')
# Parameters for crocodiles
croc_number =16
crocs = []
croc_speeds = []
croc_width = 150
croc_height = 40
croc_speed_min, croc_speed_max = 1,16
x1,x2,x3=0,0,0
x4,x5,x6=0,0,0
live=1
x7=0
shape_number=1
bank_check=1

# How far should we stay away from the crocodiles
safe_distance_from_croc = 15
safe_distance_from_pirate = 20
turtle.addshape("dog.gif")
turtle.addshape("000.gif")
turtle.addshape("apple.gif")
turtle.addshape("cd.gif")
turtle.addshape("1234.gif")
turtle.addshape('tiger.gif')
turtle.addshape('dog1.gif')
turtle.addshape('dog2.gif')
"""
    Helper function and event handler functions
"""
 
    
# Part 6
# Show a message when the game end

def gameover(msg):
    turtle.onkeypress(None,'x')
    turtle.onkeypress(None,'z')
    turtle.ondrag(None)
    ###sound3.stop()
    x=turtle.xcor()
    y=turtle.ycor()
    turtle.home()
    turtle.color('green')
    ###sound2.play()
    time.sleep(0.5)
    ###sound4.play(-1)
    turtle.color("GreenYellow")
    turtle.goto(x,y)
    score_turtle.clear()
    score_turtle.write('Score:'+str(score),align="center", font=("Arial", 15, "normal"))
    score_turtle.goto(0,255)
    score_turtle.write('lives: 0',align="center", font=("Arial", 15, "normal"))
    hh=70

    file=open('scores.txt','r')
    
    lines=[]
    for line in file:
        line=line.rstrip()
        lines.append(line)
    file.close()
    file=open('scores.txt','wt')
    for i in range(len(lines)):
        one_line=lines[i]
        file.write(one_line+'\n')
    one_line=playername+'\t'+str(score)+'\n'
    file.write(one_line)
    file.close()
    lines=[]
    file=open('scores.txt','r')
    l=0
    
    for line in file:
        line=line.rstrip()
        line=line.split('\t')
        line[1]=int(line[1])
        
        lines.append(line)
        l+=1
    file.close()
    for i in range(len(lines)):
        for k in range(i,len(lines)):
            if lines[i][1]<lines[k][1]:
                kkk=lines[i]
                lines[i]=lines[k]
                lines[k]=kkk
    time.sleep(1)
    while True:        
        for i in range(-3500,(350+70*(12+len(lines)))*10,15):
            i=i/10
            turtle.clear()
            turtle.goto(0,i)
            turtle.write(msg, align="center", font=("Arial", 24, "normal"))
            turtle.goto(0,i-hh)
            turtle.write("You get "+str(score)+' scores' , align="center", font=("Arial", 24, "normal"))
            turtle.goto(0,i-hh*2)
            turtle.write("You have avoided "+str(x1)+" tigers" , align="center", font=("Arial", 24, "normal"))
            turtle.goto(0,i-hh*3)
            turtle.write("You have avoided "+str(x2)+" dinosaurs" , align="center", font=("Arial", 24, "normal"))
            turtle.goto(0,i-hh*4)
            turtle.write("You have avoided "+str(x3)+" pirates" , align="center", font=("Arial", 24, "normal"))
            turtle.goto(0,i-hh*5)
            turtle.write("You have killed "+str(x4)+" tigers" , align="center", font=("Arial", 24, "normal"))
            turtle.goto(0,i-hh*6)
            turtle.write("You have killed "+str(x5)+" dinosaurs" , align="center", font=("Arial", 24, "normal"))
            turtle.goto(0,i-hh*7)
            turtle.write("You have killed "+str(x6)+" pirates" , align="center", font=("Arial", 24, "normal"))
            turtle.goto(0,i-hh*8)
            turtle.write("You have eaten "+str(x7)+" apples" , align="center", font=("Arial", 24, "normal"))          
            turtle.goto(0,i-hh*9)
            turtle.write("Made by ZHU Xinyu" , align="center", font=("Arial", 24, "normal"))
            turtle.goto(0,i-hh*10)
            turtle.write("COMP1021 Python 3" , align="center", font=("Arial", 24, "normal"))
            turtle.goto(0,i-hh*11)
            turtle.write("Thank you for playing this game!" , align="center", font=("Arial", 24, "normal"))
            turtle.goto(0,i-hh*12)
            turtle.write("These are the previous scores:" , align="center", font=("Arial", 24, "normal"))
            for h in range(len(lines)):
                turtle.goto(0,i-hh*(13+h))
                turtle.write(lines[h][0]+'  '+str(lines[h][1])+' points', align="center", font=("Arial", 24, "normal"))
            turtle.goto(x,y)
            time.sleep(0.03)
            turtle.update()
def choose_shape(x,y):
    global shape_number
    ###skill_sound.play()
    turtle.shape('dog.gif')
    turtle.update()
    shape_number=1
def choose1_shape(x,y):
    global shape_number
    ###skill_sound1.play()
    turtle.shape('dog1.gif')
    turtle.update()
    shape_number=3
def choose2_shape(x,y):
    global shape_number
    ###skill_sound2.play()
    turtle.shape('dog2.gif')
    turtle.update()
    shape_number=2
def skill():  
        global live,score,x4,x5,x6
        
        if shape_number%3==1 and live>2:
            ###skill_sound.play()
            for i in range(croc_number+1):
                x = (window_width+croc_width)
                y = random.uniform(down, up)
                crocs[i].goto(x, y)
                croc_speeds[i] = random.uniform(croc_speed_min, croc_speed_max)
                if i==0:
                    x6+=1
                elif i%2==1:
                    x5+=1
                else:
                    x4+=1
            score+=1000
            live-=2
        elif shape_number%3==0 and live>1:
            ###skill_sound1.play()
            for i in range(croc_number+1):
                croc_speeds[i]=1
            live-=1
        elif shape_number%3==2 and score>2000:
           ###skill_sound2.play()
            live+=1
            score-=2000
def change_image():
    global shape_number
    shape_number+=1
    if shape_number%3==1:
        turtle.shape('dog.gif')        
    elif shape_number%3==0:
        turtle.shape('dog1.gif')      
    elif shape_number%3==2:
        turtle.shape('dog2.gif')
# Part 2 (2 of 2)
# 2.2 Event handler for the turtle.ondrag() event
def moveplayerturtle(x, y):
    turtle.ondrag(None)
    # Allow the turtle to move within the window only
    if x > -window_width / 2 and x < window_width / 2:    
        turtle.goto(x, y)
    turtle.update()

   # You should delete this line of code after
                    # you finish the updatescreen function
    turtle.ondrag(moveplayerturtle)
def decrease_speed(x,y):
    global croc_speed_max
    if croc_speed_max > 4:
        
        croc_speed_max-=1
        speed_text.clear()
        speed_text.write(str(croc_speed_max), align="center",font=("Arial", 11, "normal"))
        turtle.update()
def increase_speed(x,y):
    global croc_speed_max
    if croc_speed_max <44 :        
        croc_speed_max+=1
        speed_text.clear()
        speed_text.write(str(croc_speed_max), align="center",font=("Arial", 11, "normal"))
        turtle.update()
def increase_number(x,y):
    global croc_number
    if croc_number<44:
        croc_number+=1
        number_text.clear()
        number_text.write(str(croc_number), align="center",font=("Arial", 11, "normal"))

def decrease_number(x,y):
    global croc_number
    if croc_number>4:
        croc_number-=1
        number_text.clear()
        number_text.write(str(croc_number), align="center",font=("Arial", 11, "normal"))
    
def press(x,y):
    ###sound1.stop()
    ###sound3.play(-1)
    left_arrow.hideturtle()
    right_arrow.hideturtle()
    
    label_turtle.clear()
    speed_text.clear()
    left_arrow1.hideturtle()
    right_arrow1.hideturtle()
    number_text.clear()

    dog.clear()
    dog1.clear()
    dog2.clear()
    dog.hideturtle()
    dog1.hideturtle()
    dog2.hideturtle()
    dog.onclick(None)
    dog1.onclick(None)
    dog2.onclick(None)
    start_button.goto(-35, -50)
    start_button.color("green")
    start_button.begin_fill()
    for _ in range(2):
        start_button.forward(80)
        start_button.left(90)
        start_button.forward(25)
        start_button.left(90)
    start_button.end_fill()
    start_button.color("white")
    start_button.goto(5, -50)
    start_button.write("Loading...", font=("Arial", 12, "bold"), align="center")
    start_button.goto(5, -37)
    start_button.shape("square")
    start_button.shapesize(1.25,4)
    start_button.color("")

def start_game(x,y):
    start_button.onclick(None)
    start_button.onrelease(None)
    turtle_hint.clear()
    turtle.ondrag(moveplayerturtle)
    turtle1=turtle.Turtle()
    turtle1.hideturtle()
    turtle1.color('red')
    turtle1.up()
    turtle1.goto(0,200)
    turtle1.write("3",align="center", font=("Arial", 50, "normal"))
    turtle.update()
    turtle.ontimer(None,1000)
    turtle1.clear()
    turtle1.write("2",align="center", font=("Arial", 50, "normal"))
    turtle.update()
    turtle.ontimer(None,1000)
    turtle1.clear()
    turtle1.write("1",align="center", font=("Arial", 50, "normal"))
    turtle.update()
    turtle.ontimer(None,1000)
    turtle.clear()
    turtle1.clear()
    start_button.clear()
    turtle.onkeypress(change_image,'z')
    turtle.onkeypress(skill,'x')
    turtle.ontimer(updatescreen,update_interval)

# Event handler for the turtle.ontimer() event
def updatescreen():
    """
        This function does:
            1. Decrease the width of the river
            2. Check if the player has won the game
            3. Check if the player has hit the borders
            4. Move the crocodiles
            5. Check if the player has collided with a crocodile
            6. Update the screen
            7. Schedule the next update
    """
    
    # Global variables that will be changed in the function
    global river_width,score,x1,x2,x3,live,x4,x5,x6,x7,up,down,bank_check
    start_button.clear()
    for _ in range(croc_number+1):
        croc_speeds.append(random.uniform(croc_speed_min, croc_speed_max))
    apple_speed=random.uniform(35, 48)    
    score_turtle.clear()
    score_turtle.goto(0,255)
    score_turtle.write('lives:'+str(live),align="center", font=("Arial", 15, "normal"))
    score_turtle.goto(0,275)
    score_turtle.write('Score:'+str(score),align="center", font=("Arial", 15, "normal"))

    up=upper_river_border.ycor()-border_height / 2
    down=lower_river_border.ycor()+border_height / 2

    # Part 4.2
    # Decrease the width of the river by river_width_update
    if river_width>=minimum_river_width:
        river_width=river_width-river_width_update*2
        upper_river_border.sety(upper_river_border.ycor() - river_width_update)
        lower_river_border.sety(lower_river_border.ycor() + river_width_update)
        river_number=0
    else :
        river_number=1
    
    # Part 4.3
    # 4.3.1 Check if the player has won the game
    
    # If the player survives until the river gets to its narrowest 
    # width, he/she will win the game

    # 4.3.2 Check if the player has hit the borders
    if upper_river_border.ycor() - turtle.ycor()< safe_distance_from_border or turtle.ycor()-lower_river_border.ycor()  < safe_distance_from_border:
        '''
        score+=(live*2000)
        gameover("You lose! You touched the bank!")
        turtle.ondrag(None)
        return
        '''
        
        if live>=2:
            live-=1
            score+=200
        elif live<=1:
            live-=1
            score+=200
            gameover("You lose! You touched the bank!")
            turtle.ondrag(None)
            return
          
        # 5.2.1. Move the crocodile to the left
    for i in range(croc_number+1):
        crocs[i].forward(croc_speeds[i])
    apple.forward(apple_speed)
    background.forward(1)
        # 5.2.2. If the crocodile moves out of the screen, move it 
        #    to the right hand side and generate its speed and 
        #    position randomly
    for i in range(croc_number+1):
        
        if crocs[i].xcor() < -(window_width+croc_width)/2:
            if i==0:
                x3+=1
                score+=((int(croc_speeds[i]))*2+croc_number*2)*5
            elif i%2==0 and i!=0:
                x2+=1
                score+=((int(croc_speeds[i]))*2+croc_number*2)*2
            elif i%2==1:
                x1+=1
                score+=((int(croc_speeds[i]))*2+croc_number*2)
            
                         
                
            x = (window_width+croc_width)/2
            y = random.uniform(down, up)
            crocs[i].goto(x, y)
            croc_speeds[i] = random.uniform(croc_speed_min, croc_speed_max)
    if background.xcor()>=130 or background.xcor()<=-130:
        background.left(180)
    if apple.xcor()<-(window_width+croc_width)/2:
        x = (window_width+croc_width)/2
        y = random.uniform(down, up)
        apple.goto(x,y)
        
    if turtle.distance(apple)<=15:
        ###sound_apple.play()
        score+=300
        x = (window_width+croc_width)/2
        y = random.uniform(down, up)
        apple.goto(x,y)
        live+=1
        x7+=1
        # Part 5.3
        # Check collision
    for i in range(1,times):
        if score>=target*i and river_number==1:
            river_width_update1=i*river_width_update
    if score>=target:    
        if bank_check%2==1 and river_number==1:
            upper_river_border.sety(upper_river_border.ycor() + river_width_update1)
            lower_river_border.sety(lower_river_border.ycor() + river_width_update1)
        elif bank_check%2==0 and river_number==1:
            upper_river_border.sety(upper_river_border.ycor() - river_width_update1)
            lower_river_border.sety(lower_river_border.ycor() - river_width_update1)
    if (upper_river_border.ycor()+lower_river_border.ycor())/2+minimum_river_width/2>=250:
        bank_check+=1
    if (upper_river_border.ycor()+lower_river_border.ycor())/2-minimum_river_width/2<=-250:
        bank_check+=1
            
    
    for i in range(croc_number+1):
        if turtle.distance(crocs[i] )<safe_distance_from_croc and i%2==0 and i!=0:
            if live>1:
                live-=1
                x = (window_width+croc_width)/2
                y = random.uniform(-(river_width-croc_height)/2, (river_width-croc_height)/2)
                crocs[i].goto(x, y)
                croc_speeds[i] = random.uniform(croc_speed_min, croc_speed_max)
                score+=100
                x4+=1
            else:
                gameover("Dinosaur attack!! Game over!!!")
                turtle.ondrag(None)
                live-=1
                return
        elif turtle.distance(crocs[i] )<safe_distance_from_croc and i%2==1:
            if live>1:
                live-=1
                x = (window_width+croc_width)/2
                y = random.uniform(-(river_width-croc_height)/2, (river_width-croc_height)/2)
                crocs[i].goto(x, y)
                croc_speeds[i] = random.uniform(croc_speed_min, croc_speed_max)
                score+=50
                x5+=1
            else:
                gameover("Tiger attack!! Game over!!!")
                turtle.ondrag(None)
                live-=1
                return
        elif turtle.distance(crocs[i] )<safe_distance_from_pirate and i==0:
            if live>1:
                live-=1
                x = (window_width+croc_width)/2
                y = random.uniform(down, up)
                crocs[i].goto(x, y)
                croc_speeds[i] = random.uniform(croc_speed_min, croc_speed_max)
                score+=200
                x6+=1
            else:
                gameover("Hahaha! Pirate attack!! Game over!!!")
                turtle.ondrag(None)
                live-=1
                return
    # Part 3 (3-4 of 4)
    # 3.3. Update the screen
    # 3.4. Schedule an update in 'update_interval' milliseconds
    
    turtle.update()
    turtle.ontimer(updatescreen,update_interval)

"""
    Here is the entry point of the game
    
    First of all, we create turtles for each component
    in the game with turtle.Turtle().
    The components are:
        1. The player turtle
        2. Two big boxes used as borders of the river
        3. Ten crocodiles
    
    Then we set up the event handlers for:
        1. The ondrag handler to handle the player's control
        2. The ontimer handler to handle timer event for 
           regular screen update

    After all the components are ready, start the game
"""

# Part 1
turtle.setup(window_width, window_height) # Set the window size
turtle.title("Dog of War")
# Part 3 (1 of 4)
# 3.1. Turn off the tracer here
turtle.tracer(False)
# Part 5.1
# Add the crocodile image to the pool of shapes



background=turtle.Turtle()

background.shape("1234.gif")
background.up()
#turtle2.shapesize(600,600)
# Create ten crocodiles

    # 5.1.2. Generate a random speed and store it in 'croc_speeds'
croc0=turtle.Turtle()
croc0.shape("000.gif")
croc0.left(180)
    
# d. Place the crocodile in the right hand side randomly
croc0.up()
x =(window_width+croc_width)/2
y = random.uniform(-(river_width-croc_height)/2, (river_width-croc_height)/2)
croc0.goto(x, y)
crocs.append(croc0)
# e. Add the new crocodile to the list 'crocs'
crocs.append(croc0)
apple=turtle.Turtle()
apple.shape("apple.gif")
apple.left(180)
apple.up()
x = (window_width+croc_width)/2
y = random.uniform(-(river_width-croc_height)/2, (river_width-croc_height)/2)
apple.goto(x, y)
for _ in range(1,25):
    croc1 = turtle.Turtle()
    croc1.shape("cd.gif")
    croc1.left(180)
    croc1.up()
    x = (window_width+croc_width)/2
    y = random.uniform(-(river_width-croc_height)/2, (river_width-croc_height)/2)
    croc1.goto(x, y)

    # e. Add the new crocodile to the list 'crocs'
    crocs.append(croc1)   
    # a. Create a new turtle instance which is facing left
    croc2 = turtle.Turtle()
    
    # b. Set the shape
    croc2.shape("tiger.gif")

    # c. Rotate the crocodile
    croc2.left(180)
    
    # d. Place the crocodile in the right hand side randomly
    croc2.up()
    x = (window_width+croc_width)/2
    y = random.uniform(-(river_width-croc_height)/2, (river_width-croc_height)/2)
    croc2.goto(x, y)

    # e. Add the new crocodile to the list 'crocs'
    crocs.append(croc2)   

# Part 4.1
# 4.1.1. Create the big boxes for upper border and lower border
upper_river_border = turtle.Turtle()
upper_river_border.up()
lower_river_border = turtle.Turtle()
lower_river_border.up()

# 4.1.2. Set the shape of the borders to "square"
turtle.addshape("upper_river_border.gif")
upper_river_border.shape("upper_river_border.gif")
turtle.addshape("lower_river_border.gif")
lower_river_border.shape("lower_river_border.gif")
# 4.1.3. Set the colour of the borders to "DarkOrange4"
upper_river_border.color("DarkOrange4")
lower_river_border.color("DarkOrange4")

# 4.1.4. Set the size of the borders
upper_river_border.shapesize(30, 40)
lower_river_border.shapesize(30, 40)

# 4.1.5. Set the initial y position of the borders
upper_river_border.sety((border_height + river_width) / 2)
lower_river_border.sety(-(border_height + river_width) / 2)



playername=turtle.textinput("Welcome Player","Please input you name\n(Do Not Includ any Tab!) :")
if playername=='':
    playername='Player'
# Prepare the player turtle
turtle.shape("dog.gif")
turtle.color("GreenYellow")
turtle.up()

# Part 2 (1 of 2)
# 2.1 Set up event handlers
#    The event handler for turtle.ondrag

# Part 3 (2 of 4)
# The event handler for turtle.ontimer
# 3.2. Schedule the first update
#    It starts the main loop and starts the game

    # e. Add the new crocodile to the list 'crocs'
   
# Start the main loop, start the game
k=70
speed_text=turtle.Turtle()
speed_text.hideturtle()
speed_text.pencolor("darkgreen")
speed_text.up()
speed_text.goto(-70,-k)
speed_text.write(str(croc_speed_max), align="center", font=("Arial", 11, "normal"))

label_turtle=turtle.Turtle()
label_turtle.hideturtle()
label_turtle.up()
label_turtle.pencolor("darkgreen")
label_turtle.goto(-275,-k)
label_turtle.write("Maximum Speed of Enermy:", font=("Arial", 10, "normal"))

#left_arrow for speed
left_arrow=turtle.Turtle()
left_arrow.shape("arrow")
left_arrow.left(180)
left_arrow.up()
left_arrow.shapesize(0.5,1)
left_arrow.color("darkgreen")
left_arrow.goto(-90,-k+8)

#right_arrow for speed
right_arrow=turtle.Turtle()
right_arrow.shape("arrow")
right_arrow.up()
right_arrow.shapesize(0.5,1)
right_arrow.color("darkgreen")
right_arrow.goto(-50,-k+8)


#left_arrow for number
left_arrow1=turtle.Turtle()
left_arrow1.shape("arrow")
left_arrow1.left(180)
left_arrow1.up()
left_arrow1.shapesize(0.5,1)
left_arrow1.color("darkgreen")
left_arrow1.goto(210,-k+8)

#right_arrow for number
right_arrow1=turtle.Turtle()
right_arrow1.shape("arrow")
right_arrow1.up()
right_arrow1.shapesize(0.5,1)
right_arrow1.color("darkgreen")
right_arrow1.goto(250,-k+8)

label_turtle.goto(-10,-k)
label_turtle.write("The Maximum Number of Enermy: ", font=("Arial", 10 ,"normal"))


number_text=turtle.Turtle()
number_text.hideturtle()
number_text.pencolor("darkgreen")
number_text.up()
number_text.goto(230,-k)
number_text.write(str(croc_number), align="center", font=("Arial", 11, "normal"))

turtle_hint=turtle.Turtle()
turtle_hint.hideturtle()
turtle_hint.color('skyblue')
turtle_hint.up()
hhh=240
h=25
turtle_hint.goto(0,240)
turtle_hint.write('Dog of War!',align="center", font=("Arial", 25, "normal"))
turtle_hint.goto(0,hhh-h*1)
turtle_hint.write('Please choose the number and max speed of your enermies.',align="center", font=("Arial", 14, "normal"))
turtle_hint.goto(0,hhh-h*2)
turtle_hint.write('To start the game, press the "Start" button.',align="center", font=("Arial", 14, "normal"))
turtle_hint.goto(0,hhh-h*3)
turtle_hint.write('You need to drag the dog with you mouse.',align="center", font=("Arial", 14, "normal"))
turtle_hint.goto(0,hhh-h*4)
turtle_hint.write('The dog will die as long as it touches the bank.',align="center", font=("Arial", 14, "normal"))
turtle_hint.goto(0,hhh-h*5)
turtle_hint.write('The dog will lose one live when it kills a dinosaur,a tiger or a pirate by touching them.',align="center", font=("Arial", 10, "bold"))
turtle_hint.goto(0,hhh-h*6)
turtle_hint.write('The dog will also die when its lives become zero.',align="center", font=("Arial", 14, "normal"))
turtle_hint.goto(0,hhh-h*7)
turtle_hint.write('There will be some apples in the game,',align="center", font=("Arial", 14, "normal"))
turtle_hint.goto(0,hhh-h*8)
turtle_hint.write('When you eat them, your lives will increase.',align="center", font=("Arial", 14, "normal"))
turtle_hint.goto(0,hhh-h*9)
turtle_hint.write('You can earn scores by eating apples, avoiding enermies and killing enermies.',align="center", font=("Arial", 11, "normal"))
turtle_hint.goto(0,-100)
turtle_hint.color("blue")
turtle_hint.write('There are three kinds of dog, you can change your dog by pressing "z" after the game begin',align="center", font=("Arial", 10, "normal"))
turtle_hint.goto(0,-125)
turtle_hint.write('Different dog has different skill, you can use the skill by pressing "x"',align="center", font=("Arial", 11, "normal"))

dog=turtle.Turtle()
dog1=turtle.Turtle()
dog2=turtle.Turtle()
dog.shape('dog.gif')
dog1.shape('dog1.gif')
dog2.shape('dog2.gif')
dog.up()
dog.color('blue')
dog1.up()
dog1.color('blue')
dog2.up()
dog2.color('blue')
dog.goto(-210,-200)
dog.write('My skill is killing all enermies\nBut it will cost 2 lives\nClick on me!',align="center",font=("Arial", 10, "normal"))
dog.goto(-230,-220)

dog1.goto(0,-200)
dog1.write('My skill is slowing down all enermies\nBut it will cost 1 life\nClick on me!',align="center",font=("Arial",10, "normal"))
dog1.goto(0,-220)

dog2.goto(180,-230)
dog2.write('My skill is adding one life for me\nBut it will cost 2000 scores each time\nClick on me!',align="center",font=("Arial", 10, "normal"))
dog2.goto(180,-250)

start_button = turtle.Turtle()
start_button.up()
start_button.goto(-35, -50)
start_button.color("black")
start_button.begin_fill()
for _ in range(2):
    start_button.forward(80)
    start_button.left(90)
    start_button.forward(25)
    start_button.left(90)
start_button.end_fill()
start_button.color("white")
start_button.goto(5, -50)
start_button.write("Start", font=("Arial", 12, "bold"), align="center")
start_button.goto(5, -37)
start_button.shape("square")
start_button.shapesize(1.25,4)
start_button.color("")


turtle.update()

left_arrow.onclick(decrease_speed)
right_arrow.onclick(increase_speed)
left_arrow1.onclick(decrease_number)
right_arrow1.onclick(increase_number)
start_button.onclick(press)
start_button.onrelease(start_game)
dog.onclick(choose_shape)
dog1.onclick(choose1_shape)
dog2.onclick(choose2_shape)

turtle.listen()
turtle.done()
