'''
 To control your units and win the game, you need to know the following things:
    1)Choose your units:
        click on the screen and a little turtle which can't be seen will goto that
        point, then you click and drag it, you will see a rectangle which I am sure you
        know how to use.
    2)Move your units:
        After choosing some units(They will become red), you can click on any point of the
        screen, the red unit will go to that area. You can deselect your units by right-click
        on you mouse
    3)Win and lose:
        When you have no unit and no enough money to buy a unit, you lose
        When you kill all your enermies(once the number of enermy become zero) you win.
        Kill you enermies by asking your units to approach them.
    4)Control:
        a-choose all your units
        x-order your choosed units to disperse
        
e-set the rally point(when you generate your units they will goto the rally point first)
        w-show the health value of all your units(This function has a little bug, don't use it frequently!)
        s-ask your units to stop
        z-choose all the same kind units
        1-generate plane
        2-generate turtle tank
        3-generate circle killer
        You can click on the base to generate,too
    5)introduce to units:
        plane:          speed:10 price:50 attack:5 health:100
        turtle tank:    speed:5 price:100 attack:5 health:2000
        circle killer:  speed:7 price:300 attack:100 health:500
        *the speed of enermy is 5
    6)Money:
        When you kill your enermy you will get some money base on which kind of enermy you have killed
        WHEN You lose your unit you can also get some money
    7)Strategies：
        Your enermy will choose different strategies according to the number of units of both sides
        If your force trebles enermies, they will begin to run away! You must stop them, otherwise
        they will go out of your screen. But they will come back when their force increase.
        
    8)GUARD TOWER：
    
   	There is a guard tower(The big triangle), you can move it in a certain area.
'''

import turtle,math,random
turtle.reset()
###pygame.mixer.init()
###pygame.init()
turtle.setup(800,700)
turtle.title("The war of turtle")
turtle.fillcolor("white")
turtle.shape("circle")
turtle.shapesize(0.01,0.01)
turtle.width(3)
turtle.up()
turtle.tracer(False)

###sound = pygame.mixer.Sound('003.wav')
###sound1=pygame.mixer.Sound("02.Rock House Jail.wav")
###sound2=pygame.mixer.Sound("1.wav")

control=10
original_number=30
original_enermy=20
money=5000

earn1=[0,50,100,150,500] #kill enermy then get:
earn2=[0,25,50,75] #lose unit then get: depending on the unit's kind
health=100
base_size=3
enermy_base_size=3
kill_range=15
generate_speed1=500
generate_speed2=1000
generate_speed3=1500
max_enermy_number=100
defend_range=50

bullet_attack=200
count=0
turtles=[]
enermy=[]
selected_turtles=[]
bullet=[]
memery=0
value1=50
value2=100
value3=200
enermy_speed=5
bullet_speed=6
speed1=10
speed2=5
speed3=7
attack1=5
attack2=20
attack3=100
attack4=5000
healthy1=100
healthy2=2000
healthy3=300
healthy4=100000
def select_same():
    selected_turtles=[]
    for i in range(len(turtles)):
            if turtles[i][0].fillcolor()=='red':
                selected_turtles.append(turtles[i])
    for i in range(len(selected_turtles)):
        for j in range(len(turtles)):
            if selected_turtles[i][4]==turtles[j][4]:
                turtles[j][0].color("red")
def generate_bullet():
    ###sound2.play()
    h=turtle.Turtle()
    h.shape("circle")
    h.shapesize(0.3,0.3)
    h.color('green')
    h.up()
    h.goto(defend.xcor(),defend.ycor())
    xx=defend.xcor()
    yy=defend.ycor()
    bullet.append([h,xx,yy])
def attack():
    global memery
    if len(bullet)==0:
        for i in range(len(enermy)-1):
            if defend.distance(enermy[i][0])<=defend_range:
                memery=i
                generate_bullet()
                break
def gameover(a):
    label.clear()
    label.write("Money:"+str(int(money))+" Unit:"+str(len(turtles))+"\nEnermy Unit: "+str(len(enermy)),align="center", font=("Large", 15, "bold"))
    gameturtle=turtle.Turtle()
    gameturtle.hideturtle()
    gameturtle.color("Red")
    gameturtle.write(a,align="center", font=("Large", 25, "bold") )                       
    turtle.update()
    ###sound1.stop()
    ###sound.play(-1)
def select_all():
    for i in range(len(turtles)):
        turtles[i][0].color("red")
def selecting():
    result=False
    for i in range(len(turtles)):
        if turtles[i][0].fillcolor()=='red':
            result=True
    return result
def select_area(x,y):
    turtle.ondrag(None)
    x1=x
    y1=y
    turtle.clear()
    turtle.up()
    turtle.goto(x0,y0)
    turtle.down()
    turtle.sety(y1)
    turtle.setx(x1)
    turtle.up()
    turtle.goto(x0,y0)
    turtle.down()
    turtle.setx(x1)
    turtle.sety(y1)
    for i in range(len(turtles)):
        if x0<turtles[i][0].xcor()<x1 and y0<turtles[i][0].ycor()<y1 or x0<turtles[i][0].xcor()<x1 and y0>turtles[i][0].ycor()>y1 or x0>turtles[i][0].xcor()>x1 and y0<turtles[i][0].ycor()<y1 or x0>turtles[i][0].xcor()>x1 and y0>turtles[i][0].ycor()>y1:
            turtles[i][0].color('red')
        else:
            turtles[i][0].color('black')
    turtle.update()

    turtle.ondrag(select_area)
def click(x,y):
    global x0,y0,x1,y1
    if not selecting():
        turtle.up()
        turtle.goto(x,y)
        x0=x
        y0=y
        x1=x
        y1=y
        turtle.onclick(select_area)
    else:
        if button1.distance(x,y)<base_size*10 or button2.distance(x,y)<base_size*10 or button3.distance(x,y)<base_size*10:
            pass
        else:
            for i in range(len(turtles)):
                    if turtles[i][0].fillcolor()=='red':
                        turtles[i][1]=x
                        turtles[i][2]=y
def antiselect(x,y):
    for i in range(len(turtles)):
        turtles[i][0].color('black')
def selectedturtles():
    selected_turtles=[]
    for i in range(len(turtles)):
            if turtles[i][0].fillcolor()=='red':
                selected_turtles.append(turtles[i])
    return selected_turtles
def noKing():
    for i in range(len(enermy)):
        if enermy[i][4]==4:
            return False
    return True
def clear(x,y):
    turtle.clear()
    turtle.update()
def generate_1(x,y):
    global money
    if money-value1>=0:
        h=turtle.Turtle()
        h.up()
        h.goto(button1.xcor(),button1.ycor())
        
        xx=lacation_turtle.xcor()
        yy=lacation_turtle.ycor()
        turtles.append([h,xx,yy,healthy1,1,speed1,attack1])
        money-=value1
def generate_2(x,y):
    global money
    if money-value2>=0:
        h=turtle.Turtle()
        h.shape("turtle")
        h.shapesize(1,1)
        h.up()
        h.goto(button2.xcor(),button2.ycor())
        
        xx=lacation_turtle.xcor()
        yy=lacation_turtle.ycor()
        turtles.append([h,xx,yy,healthy2,2,speed2,attack2])
        money-=value2
def generate_3(x,y):
    global money
    if money-value3>=0:
        h=turtle.Turtle()
        h.shape("turtle")
        h.shapesize(0.5,0.5)
        h.up()
        h.goto(button3.xcor(),button3.ycor())
        h.shape("circle")
        xx=lacation_turtle.xcor()
        yy=lacation_turtle.ycor()
        turtles.append([h,xx,yy,healthy3,3,speed3,attack3])
        money-=value3
def generate1():
    global money
    if money-value1>=0:
        h=turtle.Turtle()
        h.up()
        h.goto(button1.xcor(),button1.ycor())
        
        xx=lacation_turtle.xcor()
        yy=lacation_turtle.ycor()
        turtles.append([h,xx,yy,healthy1,1,speed1,attack1])
        money-=value1
def generate2():
    global money
    if money-value2>=0:
        h=turtle.Turtle()
        h.shape("turtle")
        h.shapesize(1,1)
        h.up()
        h.goto(button2.xcor(),button2.ycor())
        
        xx=lacation_turtle.xcor()
        yy=lacation_turtle.ycor()
        turtles.append([h,xx,yy,healthy2,2,speed2,attack2])
        money-=value2

def generate3():
    global money
    if money-value3>=0:
        h=turtle.Turtle()
        h.shape("turtle")
        h.shapesize(0.5,0.5)
        h.up()
        h.goto(button3.xcor(),button3.ycor())
        h.shape("circle")
        xx=lacation_turtle.xcor()
        yy=lacation_turtle.ycor()
        turtles.append([h,xx,yy,healthy3,3,speed3,attack3])
        money-=value3
def x():
    for i in range(len(selectedturtles())):
        selectedturtles()[i][1]=selectedturtles()[i][0].xcor()+random.uniform(-70,70)
        selectedturtles()[i][2]=selectedturtles()[i][0].ycor()+random.uniform(-70,70)
def xx(a):   
    a[1]=a[0].xcor()+random.uniform(-70,70)
    a[2]=a[0].ycor()+random.uniform(-70,70)
def generate_enermy1():
    if len(enermy)==0:
        return
    if len(enermy)<=max_enermy_number:
        h=turtle.Turtle()
        h.up()
        h.left(180)
        h.color("blue")
        h.goto(enermy_base.xcor(),enermy_base.ycor())
        
        xx=random.uniform(-350,350)
        yy=random.uniform(-300,300)
        enermy.append([h,xx,yy,healthy1,1,enermy_speed,attack1])
    turtle.ontimer(generate_enermy1,generate_speed1)
def generate_enermy2():
    if len(enermy)==0:
        return
    if len(enermy)<=max_enermy_number:
        h=turtle.Turtle()
        h.up()
        h.left(180)
        h.color("blue")
        h.goto(enermy_base1.xcor(),enermy_base1.ycor())
        h.shape("turtle")
        xx=random.uniform(-350,350)
        yy=random.uniform(-300,300)
        enermy.append([h,xx,yy,healthy2,2,enermy_speed,attack2])
    turtle.ontimer(generate_enermy2,generate_speed2)
def generate_enermy3():
    if len(enermy)==0:
        return
    if len(enermy)<=max_enermy_number:
        h=turtle.Turtle()
        h.up()
        h.left(180)
        h.color("blue")
        h.goto(enermy_base2.xcor(),enermy_base2.ycor())
        h.shape("circle")
        h.shapesize(0.5,0.5)
        xx=random.uniform(-350,350)
        yy=random.uniform(-300,300)
        enermy.append([h,xx,yy,healthy3,3,enermy_speed,attack3])
    turtle.ontimer(generate_enermy3,generate_speed3)
def stop():
    for i in range(len(selectedturtles())):
        selectedturtles()[i][1]=selectedturtles()[i][0].xcor()
        selectedturtles()[i][2]=selectedturtles()[i][0].ycor()
def shaw_health():
    for i in range(len(turtles)):
        turtles[i][0].write(str(turtles[i][3]))
def antishaw_health():
    for i in range(len(turtles)):
        turtles[i][0].clear()
def SL(x,y):
    lacation_turtle.ondrag(None)
    lacation_turtle.goto(x,y)
    lacation_turtle.ondrag(SL)
def setLocation():
    lacation_turtle.showturtle()
    turtle.onscreenclick(SL)
def antisetLocation():
    turtle.onscreenclick(click)
    lacation_turtle.hideturtle()
def show_defend(x,y): 
    defend.right(90)
    defend.forward(defend_range)
    defend.left(90)
    defend.down()
    defend.circle(defend_range)
    defend.up()
    defend.left(90)
    defend.forward(defend_range)
    defend.right(90)
    turtle.update()
def clear_circle(x,y):
    defend.clear()
def defend_move(x,y):
    defend.ondrag(None)
    defend.clear()
    if x<=0:
        defend.goto(x,y)
    else:
        defend.goto(0,y)
    defend.right(90)
    defend.forward(defend_range)
    defend.left(90)
    defend.down()
    defend.circle(defend_range)
    defend.up()
    defend.left(90)
    defend.forward(defend_range)
    defend.right(90)
    defend.ondrag(defend_move)
def updatescreen1():
    global money,count
    label.clear()
    label.goto(0,300)
    label.write("Money:"+str(int(money))+" Unit:"+str(len(turtles)),align="center", font=("Large", 15, "bold"))
    label.goto(0,280)
    label.write("Enermy Unit: "+str(len(enermy)),align="center", font=("Large", 15, "bold"))
    label.goto(0,260)
    label.write("Selected Units: "+str(len(selectedturtles())),align="center", font=("Large", 15, "bold"))
    attack()
    if len(bullet)<=0:
        pass
    else:
        try:
            if 0<=bullet[0][0].xcor()-enermy[memery][0].xcor()<=kill_range/3 and 0<=bullet[0][0].ycor()-enermy[memery][0].ycor()<=kill_range/3\
            or 0<=bullet[0][0].xcor()-enermy[memery][0].xcor()<=kill_range/3and -kill_range/3<=bullet[0][0].ycor()-enermy[memery][0].ycor()<=0\
            or -kill_range/3<=bullet[0][0].xcor()-enermy[memery][0].xcor()<=0 and -kill_range/3<=bullet[0][0].ycor()-enermy[memery][0].ycor()<=0\
            or -kill_range/3<=bullet[0][0].xcor()-enermy[memery][0].xcor()<=0 and 0<=bullet[0][0].ycor()-enermy[memery][0].ycor()<=kill_range/3:                                             
                enermy[memery][0].hideturtle()
                bullet[0][0].hideturtle()
                del bullet[0]
                enermy[memery][0].hideturtle()
                del enermy[memery]
                
            else:
                bullet[0][1]=enermy[memery][0].xcor()
                bullet[0][2]=enermy[memery][0].ycor()
        except (BaseException):
            bullet[0][0].hideturtle()
            del bullet[0]
    if len(selectedturtles())>1:
        for i in range(len(turtles)):
            if 0<turtles[i][0].xcor()-turtles[i][1]<control and 0<turtles[i][0].ycor()-turtles[i][2]<control \
               or 0>turtles[i][0].xcor()-turtles[i][1]>-control and 0<turtles[i][0].ycor()-turtles[i][2]<control \
               or 0<turtles[i][0].xcor()-turtles[i][1]<control and 0>turtles[i][0].ycor()-turtles[i][2]>-control\
               or 0>turtles[i][0].xcor()-turtles[i][1]>-control and 0>turtles[i][0].ycor()-turtles[i][2]>-control:
                    pass
            else:
                turtles[i][1]=turtles[i][1]+random.uniform(-4,4)
                turtles[i][2]=turtles[i][2]+random.uniform(-4,4)
                if turtles[i][1]-turtles[i][0].xcor()==0:
                    a=turtles[i][0].heading()
                else:
                    if turtles[i][2]>=turtles[i][0].ycor()and turtles[i][1]>=turtles[i][0].xcor():
                        a=(math.atan((turtles[i][2]-turtles[i][0].ycor())/(turtles[i][1]-turtles[i][0].xcor())))/math.pi*180
                    elif turtles[i][2]>=turtles[i][0].ycor()and turtles[i][1]<turtles[i][0].xcor():
                        a=180+(math.atan((turtles[i][2]-turtles[i][0].ycor())/(turtles[i][1]-turtles[i][0].xcor())))/math.pi*180
                    elif turtles[i][2]<turtles[i][0].ycor()and turtles[i][1]>=turtles[i][0].xcor():
                        a=(math.atan((turtles[i][2]-turtles[i][0].ycor())/(turtles[i][1]-turtles[i][0].xcor())))/math.pi*180-360
                    elif turtles[i][2]<turtles[i][0].ycor()and turtles[i][1]<turtles[i][0].xcor():
                        a=(math.atan((turtles[i][2]-turtles[i][0].ycor())/(turtles[i][1]-turtles[i][0].xcor())))/math.pi*180+180
                turtles[i][0].setheading(a)
                turtles[i][0].forward(turtles[i][5])
    else:
        for i in range(len(turtles)):
            if 0<turtles[i][0].xcor()-turtles[i][1]<1 and 0<turtles[i][0].ycor()-turtles[i][2]<1 \
               or 0>turtles[i][0].xcor()-turtles[i][1]>-1 and 0<turtles[i][0].ycor()-turtles[i][2]<1 \
               or 0<turtles[i][0].xcor()-turtles[i][1]<1 and 0>turtles[i][0].ycor()-turtles[i][2]>-1\
               or 0>turtles[i][0].xcor()-turtles[i][1]>-1 and 0>turtles[i][0].ycor()-turtles[i][2]>-1:
                    pass
            else:
                if turtles[i][1]-turtles[i][0].xcor()==0:
                    a=turtles[i][0].heading()
                else:
                    if turtles[i][2]>=turtles[i][0].ycor()and turtles[i][1]>=turtles[i][0].xcor():
                        a=(math.atan((turtles[i][2]-turtles[i][0].ycor())/(turtles[i][1]-turtles[i][0].xcor())))/math.pi*180
                    elif turtles[i][2]>=turtles[i][0].ycor()and turtles[i][1]<turtles[i][0].xcor():
                        a=180+(math.atan((turtles[i][2]-turtles[i][0].ycor())/(turtles[i][1]-turtles[i][0].xcor())))/math.pi*180
                    elif turtles[i][2]<turtles[i][0].ycor()and turtles[i][1]>=turtles[i][0].xcor():
                        a=(math.atan((turtles[i][2]-turtles[i][0].ycor())/(turtles[i][1]-turtles[i][0].xcor())))/math.pi*180-360
                    elif turtles[i][2]<turtles[i][0].ycor()and turtles[i][1]<turtles[i][0].xcor():
                        a=(math.atan((turtles[i][2]-turtles[i][0].ycor())/(turtles[i][1]-turtles[i][0].xcor())))/math.pi*180+180
                turtles[i][0].setheading(a)
                turtles[i][0].forward(turtles[i][5])
    for i in range(len(enermy)):
        if 0<enermy[i][0].xcor()-enermy[i][1]<control and 0<enermy[i][0].ycor()-enermy[i][2]<control \
               or 0>enermy[i][0].xcor()-enermy[i][1]>-control and 0<enermy[i][0].ycor()-enermy[i][2]<control \
               or 0<enermy[i][0].xcor()-enermy[i][1]<control and 0>enermy[i][0].ycor()-enermy[i][2]>-control\
               or 0>enermy[i][0].xcor()-enermy[i][1]>-control and 0>enermy[i][0].ycor()-enermy[i][2]>-control:
                    pass
        else:
            enermy[i][1]=enermy[i][1]+random.uniform(-4,4)
            enermy[i][2]=enermy[i][2]+random.uniform(-4,4)
            if enermy[i][1]-enermy[i][0].xcor()==0:
                a=enermy[i][0].heading()
            else:
                if enermy[i][2]>=enermy[i][0].ycor()and enermy[i][1]>=enermy[i][0].xcor():
                    a=(math.atan((enermy[i][2]-enermy[i][0].ycor())/(enermy[i][1]-enermy[i][0].xcor())))/math.pi*180
                elif enermy[i][2]>=enermy[i][0].ycor()and enermy[i][1]<enermy[i][0].xcor():
                    a=180+(math.atan((enermy[i][2]-enermy[i][0].ycor())/(enermy[i][1]-enermy[i][0].xcor())))/math.pi*180
                elif enermy[i][2]<enermy[i][0].ycor()and enermy[i][1]>=enermy[i][0].xcor():
                    a=(math.atan((enermy[i][2]-enermy[i][0].ycor())/(enermy[i][1]-enermy[i][0].xcor())))/math.pi*180-360
                elif enermy[i][2]<enermy[i][0].ycor()and enermy[i][1]<enermy[i][0].xcor():
                    a=(math.atan((enermy[i][2]-enermy[i][0].ycor())/(enermy[i][1]-enermy[i][0].xcor())))/math.pi*180+180
            enermy[i][0].setheading(a)
            enermy[i][0].forward(enermy[i][5])
    for i in range(len(bullet)):
        if bullet[i][1]-bullet[i][0].xcor()==0:
                    a=bullet[i][0].heading()
        else:
            if bullet[i][2]>=bullet[i][0].ycor()and bullet[i][1]>=bullet[i][0].xcor():
                a=(math.atan((bullet[i][2]-bullet[i][0].ycor())/(bullet[i][1]-bullet[i][0].xcor())))/math.pi*180
            elif bullet[i][2]>=bullet[i][0].ycor()and bullet[i][1]<bullet[i][0].xcor():
                a=180+(math.atan((bullet[i][2]-bullet[i][0].ycor())/(bullet[i][1]-bullet[i][0].xcor())))/math.pi*180
            elif bullet[i][2]<bullet[i][0].ycor()and bullet[i][1]>=bullet[i][0].xcor():
                a=(math.atan((bullet[i][2]-bullet[i][0].ycor())/(bullet[i][1]-bullet[i][0].xcor())))/math.pi*180-360
            elif bullet[i][2]<bullet[i][0].ycor()and bullet[i][1]<bullet[i][0].xcor():
                a=(math.atan((bullet[i][2]-bullet[i][0].ycor())/(bullet[i][1]-bullet[i][0].xcor())))/math.pi*180+180
        bullet[i][0].setheading(a)
        bullet[i][0].forward(bullet_speed)
    
    if len(enermy)==0:
        gameover("You are the Winner!")
        return
    if len(turtles)==0 and money<value1:
        gameover("You lose!")
        return
    if len(enermy)>=10 and 0<len(turtles):
        if 0<len(turtles)<10:
            for i in range(len(enermy)):
                enermy[i][1]=turtles[0][0].xcor()
                enermy[i][2]=turtles[0][0].ycor()
        elif 10<=len(turtles)<20:
            for i in range(int(len(enermy)/2)):
                enermy[i][1]=turtles[0][0].xcor()
                enermy[i][2]=turtles[0][0].ycor()
            for i in range(int(len(enermy)/2),int(len(enermy))):
                enermy[i][1]=turtles[-1][0].xcor()
                enermy[i][2]=turtles[-1][0].ycor()
        elif 30>len(turtles)>=20:
            for i in range(int(len(enermy)/3)):
                enermy[i][1]=turtles[0][0].xcor()
                enermy[i][2]=turtles[0][0].ycor()
            for i in range(int(len(enermy)/3),int(len(enermy)*2/3)):
                enermy[i][1]=turtles[-1][0].xcor()
                enermy[i][2]=turtles[-1][0].ycor()
            for i in range(int(len(enermy)*2/3),int(len(enermy))):
                enermy[i][1]=turtles[15][0].xcor()
                enermy[i][2]=turtles[15][0].ycor()
        elif 30<=len(turtles)<50:
            for i in range(int(len(enermy)/4)):
                enermy[i][1]=turtles[0][0].xcor()
                enermy[i][2]=turtles[0][0].ycor()
            for i in range(int(len(enermy)/4),int(len(enermy)*2/4)):
                enermy[i][1]=turtles[-1][0].xcor()
                enermy[i][2]=turtles[-1][0].ycor()
            for i in range(int(len(enermy)*2/4),int(len(enermy)*3/4)):
                enermy[i][1]=turtles[25][0].xcor()
                enermy[i][2]=turtles[25][0].ycor()
            for i in range(int(len(enermy)*3/4),int(len(enermy))):
                enermy[i][1]=turtles[15][0].xcor()
                enermy[i][2]=turtles[15][0].ycor()
        elif len(turtles)>=50:
            if len(enermy)<=len(turtles):
                for i in range(len(enermy)):
                    enermy[i][1]=turtles[25][0].xcor()
                    enermy[i][2]=turtles[25][0].ycor()
            else:
                for i in range(int(len(enermy)/5)):
                    enermy[i][1]=turtles[0][0].xcor()
                    enermy[i][2]=turtles[0][0].ycor()
                for i in range(int(len(enermy)/5),int(len(enermy)*2/5)):
                    enermy[i][1]=turtles[-1][0].xcor()
                    enermy[i][2]=turtles[-1][0].ycor()
                for i in range(int(len(enermy)*2/5),int(len(enermy)*3/5)):
                    enermy[i][1]=turtles[25][0].xcor()
                    enermy[i][2]=turtles[25][0].ycor()
                for i in range(int(len(enermy)*3/5),int(len(enermy)*4/5)):
                    enermy[i][1]=turtles[15][0].xcor()
                    enermy[i][2]=turtles[15][0].ycor()
                for i in range(int(len(enermy)*4/5),int(len(enermy))):
                    enermy[i][1]=turtles[35][0].xcor()
                    enermy[i][2]=turtles[35][0].ycor()
    '''if len(enermy)<10 or len(enermy)*3<len(turtles):
        for i in range(len(enermy)):
                enermy[i][1]=-400
                enermy[i][2]=400'''
    if (len(enermy)<10 or len(enermy)*3<len(turtles))and noKing():
        h=turtle.Turtle()
        h.shapesize(8,8,8)
        h.up()
        h.left(180)
        h.color("blue")
        h.goto(enermy_base.xcor(),enermy_base.ycor())
        
        xx=random.uniform(-350,350)
        yy=random.uniform(-300,300)
        enermy.append([h,xx,yy,healthy4,4,enermy_speed,attack4])
        hh=turtle.Turtle()
        hh.shapesize(5,5,5)
        hh.shape("turtle")
        hh.up()
        hh.left(180)
        hh.color("green")
        hh.goto(enermy_base1.xcor(),enermy_base1.ycor())
        
        xx=random.uniform(-350,350)
        yy=random.uniform(-300,300)
        enermy.append([hh,xx,yy,healthy4,4,enermy_speed,attack4])
        hhh=turtle.Turtle()
        hhh.shapesize(3,3,3)
        hhh.shape("circle")
        hhh.up()
        hhh.left(180)
        hhh.color("orange")
        hhh.goto(enermy_base2.xcor(),enermy_base2.ycor())
        
        xx=random.uniform(-350,350)
        yy=random.uniform(-300,300)
        enermy.append([hhh,xx,yy,healthy4,4,enermy_speed,attack4])

    if len(turtles)==0:
        for i in range(int(len(enermy)/5)):
                enermy[i][1]=button1.xcor()
                enermy[i][2]=button1.ycor()
                
        for i in range(int(len(enermy)/5),int(2*len(enermy)/5)):
                enermy[i][1]=button2.xcor()
                enermy[i][2]=button2.ycor()
                
        for i in range(int(2*len(enermy)/5),int(3*len(enermy)/5)):
                enermy[i][1]=button3.xcor()
                enermy[i][2]=button3.ycor()
                
        for i in range(int(3*len(enermy)/5),int(4*len(enermy)/5)):
                enermy[i][1]=0
                enermy[i][2]=0
        for i in range(int(4**len(enermy)/5),int(len(enermy)/5)):
                enermy[i][1]=0
                enermy[i][2]=0
    
    turtle.update()
    count+=1
    for i in range(len(enermy)):
        for j in range(len(turtles)):
            if enermy[i][0].distance(turtles[j][0])<kill_range and turtles[j][3]>0:
                turtles[j][3]-=enermy[i][6]
                break
    for i in range(len(turtles)):
        for j in range(len(enermy)):
            if enermy[j][0].distance(turtles[i][0])<kill_range and enermy[j][3]>0:
                enermy[j][3]-=turtles[i][6]
                break    
    turtle.update()
    turtle.ontimer(updatescreen1,25)
def updatescreen2():
    global money
    for i in range(len(enermy)):
        if enermy[i][3]<=0:
            money+=(earn1[enermy[i][4]])
            enermy[i][0].hideturtle()
            del enermy[i][0]
            enermy.remove(enermy[i])
            break  
    for i in range(len(turtles)):
        if turtles[i][3]<=0:
            turtles[i][0].hideturtle()
            money+=(earn2[turtles[i][4]])
            turtles[i][0].clear()
            del turtles[i][0]
            turtles.remove(turtles[i])
            break
    turtle.ontimer(updatescreen2,10)
enermy_base=turtle.Turtle()
enermy_base.color('pink')
enermy_base.up()
enermy_base.goto(350,0)
enermy_base.shape("circle")
enermy_base.shapesize(enermy_base_size,enermy_base_size)

enermy_base1=turtle.Turtle()
enermy_base1.color('pink')
enermy_base1.up()
enermy_base1.goto(350,200)
enermy_base1.shape("circle")
enermy_base1.shapesize(enermy_base_size,enermy_base_size)

enermy_base2=turtle.Turtle()
enermy_base2.color('pink')
enermy_base2.up()
enermy_base2.goto(350,-200)
enermy_base2.shape("circle")
enermy_base2.shapesize(enermy_base_size,enermy_base_size)

button1=turtle.Turtle()
button1.up()
button1.color("pink")
button1.goto(-350,0)
button1.shape("circle")
button1.shapesize(base_size,base_size)
button1.onclick(generate_1)

button2=turtle.Turtle()
button2.up()
button2.color("yellow")
button2.goto(-350,200)
button2.shape("circle")
button2.shapesize(base_size,base_size)
button2.onclick(generate_2)

button3=turtle.Turtle()
button3.up()
button3.color("yellow")
button3.goto(-350,-200)
button3.shape("circle")
button3.shapesize(base_size,base_size)
button3.onclick(generate_3)

label=turtle.Turtle()
label.up()
label.goto(0,290)
label.hideturtle()

lacation_turtle=turtle.Turtle()
lacation_turtle.up()
lacation_turtle.shape("turtle")
lacation_turtle.shapesize(3,3)
lacation_turtle.hideturtle()

defend=turtle.Turtle()
defend.shape("triangle")

defend.shapesize(1,1)
defend.up()
defend.goto(-300,200)
defend.onclick(show_defend)
defend.onrelease(clear_circle)
#_________________________________
for i in range(original_number):
    h=turtle.Turtle()
    h.up()
    h.goto(-300,10*i)
    
    xx=h.xcor()-1
    yy=h.ycor()-1
    turtles.append([h,xx,yy,health,1,speed1,attack1])
    


for i in range(original_enermy):
    h=turtle.Turtle()
    h.up()
    h.left(180)
    h.color("blue")
    h.goto(300,10*i)
    
    xx=0
    yy=0
    enermy.append([h,xx,yy,health,1,enermy_speed,attack2])
##sound1.play(-1)
turtle.onscreenclick(click)
turtle.onscreenclick(antiselect,3)
turtle.ondrag(select_area)
turtle.onrelease(clear)
#turtle.onkeypress(antiselect,'q')
turtle.onkeypress(shaw_health,'w')
turtle.onkeyrelease(antishaw_health,'w')
turtle.ontimer(updatescreen1,25)
turtle.ontimer(updatescreen2,10)
turtle.onkeypress(select_same,'z')
turtle.onkeypress(select_all,'a')
turtle.onkeypress(stop,'s')
turtle.onkeypress(setLocation,'e')
turtle.onkeyrelease(antisetLocation,'e')
turtle.onkeypress(generate1,'1')
turtle.onkeypress(generate2,'2')
turtle.onkeypress(generate3,'3')
turtle.onkeypress(x,'x')
defend.ondrag(defend_move)
turtle.ontimer(generate_enermy1,generate_speed1)
turtle.ontimer(generate_enermy2,generate_speed2)
turtle.ontimer(generate_enermy3,generate_speed3)
turtle.listen()
turtle.done()

                
